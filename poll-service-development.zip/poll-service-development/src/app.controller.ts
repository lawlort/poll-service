import { Controller, Get } from '@nestjs/common';
import { AppService } from './app.service';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { CMD_CHECK_MICRO_SERVICE_HEALTH } from './utils/constants/commands';

@Controller()
export class AppController {
    constructor(private readonly appService: AppService) {}

    @Get()
    getHello(): string {
        return this.appService.getHello();
    }

    @Get('health')
    @MessagePattern({ cmd: CMD_CHECK_MICRO_SERVICE_HEALTH })
    checkMicroServiceHealth(@Payload() payload): any {
        return this.appService.checkMicroServiceHealth(payload);
    }
}
