import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'reported_polls', versionKey: false })
export class ReportedPoll {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    reportedBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    pollId: string;

    @Prop({ type: String, required: true })
    reason: string;

    @Prop({ type: Date, default: Date.now })
    reportedAt: Date;

    @Prop({ default: false })
    isDeleted: boolean;
}

export const ReportedPollSchema = SchemaFactory.createForClass(ReportedPoll);

// Indexes to ensure uniqueness and optimize queries
ReportedPollSchema.index({ reportedBy: 1, pollId: 1 }, { unique: true });
ReportedPollSchema.index({ pollId: 1 });
ReportedPollSchema.index({ reportedBy: 1 });
ReportedPollSchema.index({ reportedAt: 1 });

export type ReportedPollDocument = HydratedDocument<ReportedPoll>;

export default ReportedPollSchema;
