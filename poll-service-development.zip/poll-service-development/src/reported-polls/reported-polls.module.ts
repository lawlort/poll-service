import { Module } from '@nestjs/common';
import { ReportedPollsService } from './reported-polls.service';
import { ReportedPollsController } from './reported-polls.controller';
import { MongooseModule } from '@nestjs/mongoose';
import ReportedPollSchema, { ReportedPoll } from './schemas/reported-poll.schema';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';
import { PollsModule } from 'src/polls/polls.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: ReportedPoll.name, schema: ReportedPollSchema },
            { name: Poll.name, schema: PollSchema }
        ]),
        PollsModule
    ],
    controllers: [ReportedPollsController],
    providers: [ReportedPollsService]
})
export class ReportedPollsModule {}
