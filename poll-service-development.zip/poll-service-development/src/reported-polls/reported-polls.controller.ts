import { Controller, Body } from '@nestjs/common';
import { ReportedPollsService } from './reported-polls.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_REPORT_POLL } from 'src/utils/constants/commands';

@Controller()
export class ReportedPollsController {
    constructor(private readonly reportedPollsService: ReportedPollsService) {}

    @MessagePattern({ cmd: CMD_REPORT_POLL })
    async create(@Body() payload) {
        const { body = {}, userId, pollId } = payload;
        return await this.reportedPollsService.create(body, userId, pollId);
    }
}
