import { Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ReportedPoll } from './schemas/reported-poll.schema';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreateReportedPollJoiSchema } from './dto/CreateReportedPollSchema';
import { Poll } from 'src/polls/schemas/poll.schema';
import { PollsService } from 'src/polls/polls.service';

@Injectable()
export class ReportedPollsService {
    constructor(
        @InjectModel(ReportedPoll.name) private reportedPollModel: Model<ReportedPoll>,
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        private pollService: PollsService
    ) {}

    async create(createReportedPollDto, userId, pollId) {
        try {
            const payload = {
                ...createReportedPollDto,
                reportedBy: userId,
                pollId
            };
            validateSchema(CreateReportedPollJoiSchema, payload);

            const poll: any = await this.pollService.findPollById(pollId);
            if (!poll?._id || poll?.isDeleted) {
                throw new NotFoundException('Poll not found');
            }

            const existingReportedPoll = await this.reportedPollModel.findOne({
                pollId,
                reportedBy: userId,
                isDeleted: false
            });
            if (existingReportedPoll?._id) {
                throw new UnprocessableEntityException('You have already reported this poll');
            }

            const createdReportedPoll = await this.reportedPollModel.create(payload);
            return { success: !!createdReportedPoll?._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
