import { Module } from '@nestjs/common';
import { EventQueuesService } from './event-queues.service';

@Module({
    providers: [EventQueuesService],
    exports: [EventQueuesService]
})
export class EventQueuesModule {}
