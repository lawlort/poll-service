import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { SQSClient, SendMessageCommand, SendMessageCommandInput } from '@aws-sdk/client-sqs'; // v3 SDK imports
import * as dotenv from 'dotenv';
import {
    EVENT_TYPE_DELETE_ACCOUNT,
    EVENT_TYPE_DELETE_GROUP,
    EVENT_TYPE_DELETE_POLL_FROM_GROUP,
    EVENT_TYPE_REMOVE_USER_FROM_GROUP,
    EVENT_TYPE_UPDATE_GENDER
} from 'src/utils/constants/events';

dotenv.config();

@Injectable()
export class EventQueuesService {
    private sqsClient: SQSClient;

    // Map of event types to corresponding queue URLs
    private eventQueueUrls = {
        [EVENT_TYPE_REMOVE_USER_FROM_GROUP]: process.env.REMOVE_MEMBER_FROM_GROUP_QUEUE_URL,
        [EVENT_TYPE_UPDATE_GENDER]: process.env.UPDATE_GENDER_QUEUE_URL,
        [EVENT_TYPE_DELETE_POLL_FROM_GROUP]: process.env.DELETE_POLL_FROM_GROUP_QUEUE_URL,
        [EVENT_TYPE_DELETE_ACCOUNT]: process.env.DELETE_ACCOUNT_QUEUE_URL,
        [EVENT_TYPE_DELETE_GROUP]: process.env.DELETE_GROUP_QUEUE_URL
    };

    constructor() {
        // Initialize a single SQSClient instance for reuse
        this.sqsClient = new SQSClient({
            region: process.env.RESPONSE_QUEUE_REGION,
            credentials: {
                accessKeyId: process.env.RESPONSE_QUEUE_ACCESS_KEY_ID,
                secretAccessKey: process.env.RESPONSE_QUEUE_SECRET_KEY
            }
        });
    }

    // Function to add a job to the appropriate queue based on the event type
    async addJobToQueue(payload: any, eventType: string, messageGroupId: string) {
        try {
            console.log('addJobToQueue evebnt:', payload, eventType, messageGroupId);
            const queueUrl = this.eventQueueUrls[eventType];

            // Check if the event type has a corresponding queue URL
            if (!queueUrl) {
                throw new RpcException(`Invalid event type: ${eventType}`);
            }

            // Check if the queue is FIFO
            const isFifoQueue = queueUrl.endsWith('.fifo');

            // Build the parameters for the SQS message
            const params: SendMessageCommandInput = {
                QueueUrl: queueUrl,
                MessageBody: JSON.stringify({ ...payload, MessageGroupId: messageGroupId })
            };

            // If FIFO queue, add MessageGroupId and MessageDeduplicationId
            if (isFifoQueue) {
                params.MessageGroupId = messageGroupId;
                params.MessageDeduplicationId = new Date().getTime().toString(); // Unique deduplication ID
            }

            // console.log('Sending message to SQS:', params);

            // Send the message to SQS
            const command = new SendMessageCommand(params);
            const result = await this.sqsClient.send(command);

            console.log('Message sent successfully:', result);
            return { status: 'Message is being sent', result };
        } catch (error) {
            console.error('Error sending message to SQS:', error);
            throw new RpcException(error);
        }
    }
}
