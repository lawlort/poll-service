import { Controller, Body } from '@nestjs/common';
import { BookmarkedPollsService } from './bookmarked-polls.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_BOOKMARK_POLL, CMD_REMOVE_POLL_BOOKMARK } from 'src/utils/constants/commands';

@Controller('bookmarked-polls')
export class BookmarkedPollsController {
    constructor(private readonly bookmarkedPollsService: BookmarkedPollsService) {}

    @MessagePattern({ cmd: CMD_BOOKMARK_POLL })
    async create(@Body() payload) {
        return await this.bookmarkedPollsService.create(payload);
    }

    @MessagePattern({ cmd: CMD_REMOVE_POLL_BOOKMARK })
    async removePollBookmark(@Body() payload) {
        return await this.bookmarkedPollsService.removePollBookmark(payload);
    }
}
