import * as Joi from 'joi';

// Custom validation function for MongoDB ObjectId format
const objectId = Joi.string().regex(/^[0-9a-fA-F]{24}$/);

// Define the Joi schema
export const CreateBookmarkedPollSchema = Joi.object({
    bookmarkedBy: objectId.required().messages({
        'string.pattern.base': 'bookmarkedBy must be a valid MongoDB ObjectId',
        'any.required': 'bookmarkedBy is a required field'
    }),
    pollId: objectId.required().messages({
        'string.pattern.base': 'pollId must be a valid MongoDB ObjectId',
        'any.required': 'pollId is a required field'
    }),
    bookmarkedAt: Joi.date().optional()
});
