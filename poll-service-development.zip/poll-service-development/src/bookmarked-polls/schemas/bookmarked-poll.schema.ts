import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'bookmarked_polls', versionKey: false })
export class BookmarkedPoll {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    bookmarkedBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    pollId: string;

    @Prop({ type: Date, default: Date.now })
    bookmarkedAt: Date;

    @Prop({ default: false })
    isDeleted: boolean;
}

export const BookmarkedPollSchema = SchemaFactory.createForClass(BookmarkedPoll);

BookmarkedPollSchema.index({ bookmarkedBy: 1, pollId: 1 }, { unique: true });
BookmarkedPollSchema.index({ pollId: 1 });
BookmarkedPollSchema.index({ bookmarkedBy: 1 });
BookmarkedPollSchema.index({ commentedAt: 1 });

export type BookmarkedPollDocument = HydratedDocument<BookmarkedPoll>;

export default BookmarkedPollSchema;
