import { Module } from '@nestjs/common';
import { BookmarkedPollsService } from './bookmarked-polls.service';
import { BookmarkedPollsController } from './bookmarked-polls.controller';
import { MongooseModule } from '@nestjs/mongoose';
import BookmarkedPollSchema, { BookmarkedPoll } from './schemas/bookmarked-poll.schema';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';
import { PollsModule } from 'src/polls/polls.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: BookmarkedPoll.name, schema: BookmarkedPollSchema },
            { name: Poll.name, schema: PollSchema }
        ]),
        PollsModule
    ],
    controllers: [BookmarkedPollsController],
    providers: [BookmarkedPollsService]
})
export class BookmarkedPollsModule {}
