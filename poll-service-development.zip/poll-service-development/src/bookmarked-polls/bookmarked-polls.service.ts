import { Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { BookmarkedPoll } from './schemas/bookmarked-poll.schema';
import { Model } from 'mongoose';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreateBookmarkedPollSchema } from './dto/createBookmarkPollSchema';
import { Poll } from 'src/polls/schemas/poll.schema';
import { PollsService } from 'src/polls/polls.service';

@Injectable()
export class BookmarkedPollsService {
    constructor(
        @InjectModel(BookmarkedPoll.name) private bookmarkedPollModel: Model<BookmarkedPoll>,
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        private pollService: PollsService
    ) {}

    async create(createBookmarkedPollData) {
        try {
            const payload = {
                pollId: createBookmarkedPollData?.pollId,
                bookmarkedBy: createBookmarkedPollData?.userId
            };
            validateSchema(CreateBookmarkedPollSchema, payload);

            const poll: any = await this.pollService.findPollById(payload?.pollId);
            if (!poll?._id || poll?.isDeleted) {
                throw new NotFoundException('Poll not found');
            }

            const currentBookmark = await this.bookmarkedPollModel.findOne({ ...payload, isDeleted: false });
            if (currentBookmark) {
                throw new UnprocessableEntityException('Poll already bookmarked');
            }

            const bookmarkedPoll = await this.bookmarkedPollModel.create(payload);
            if (bookmarkedPoll) {
                return { success: true };
            } else {
                return { success: false };
            }
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async removePollBookmark(removePollBookmarkData) {
        try {
            const payload = {
                pollId: removePollBookmarkData?.pollId,
                bookmarkedBy: removePollBookmarkData?.userId
            };
            validateSchema(CreateBookmarkedPollSchema, payload);

            const poll: any = await this.pollService.findPollById(payload?.pollId);
            if (!poll?._id || poll?.isDeleted) {
                throw new NotFoundException('Poll not found');
            }

            const currentBookmark = await this.bookmarkedPollModel.findOne({ ...payload, isDeleted: false });
            if (!currentBookmark?._id) {
                throw new UnprocessableEntityException('Poll not bookmarked');
            }

            const removedBookmark = await this.bookmarkedPollModel.findByIdAndDelete(currentBookmark._id);
            return { success: !!removedBookmark };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
