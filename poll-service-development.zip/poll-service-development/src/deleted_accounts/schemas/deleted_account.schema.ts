import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'deleted_accounts', versionKey: false })
export class DeletedAccount {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    userId: string;

    @Prop({ type: String, required: true })
    reason: string;
}

export const DeletedAccountSchema = SchemaFactory.createForClass(DeletedAccount);

// Indexes to ensure uniqueness and optimize queries
DeletedAccountSchema.index({ userId: 1 });
DeletedAccountSchema.index({ reason: 1 });
DeletedAccountSchema.index({ reason: 1, userId: 1 });

export type DeletedAccountDocument = HydratedDocument<DeletedAccount>;

export default DeletedAccountSchema;
