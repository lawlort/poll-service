import { Controller } from '@nestjs/common';
import { DeletedAccountsService } from './deleted_accounts.service';

@Controller('deleted-accounts')
export class DeletedAccountsController {
    constructor(private readonly deletedAccountsService: DeletedAccountsService) {}
}
