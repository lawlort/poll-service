import { Module } from '@nestjs/common';
import { DeletedAccountsService } from './deleted_accounts.service';
import { DeletedAccountsController } from './deleted_accounts.controller';
import { MongooseModule } from '@nestjs/mongoose';
import DeletedAccountSchema, { DeletedAccount } from './schemas/deleted_account.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: DeletedAccount.name, schema: DeletedAccountSchema }])],
    controllers: [DeletedAccountsController],
    providers: [DeletedAccountsService]
})
export class DeletedAccountsModule {}
