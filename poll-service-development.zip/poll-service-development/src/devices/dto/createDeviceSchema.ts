import * as Joi from 'joi';

export const CreateDeviceSchema = Joi.object({
    deviceId: Joi.string().max(50).required(),
    os: Joi.string().max(50),
    osVersion: Joi.string().max(20),
    deviceToken: Joi.string().max(100).required()
}).options({ abortEarly: true });
