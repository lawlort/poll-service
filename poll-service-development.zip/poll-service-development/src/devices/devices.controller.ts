import { Controller, Post, Body } from '@nestjs/common';
import { DevicesService } from './devices.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_CREATE_DEVICE } from '../utils/constants/commands';

@Controller('devices')
export class DevicesController {
    constructor(private readonly devicesService: DevicesService) {}

    @MessagePattern({ cmd: CMD_CREATE_DEVICE })
    @Post()
    async create(@Body() payload) {
        const { body = {}, userId = '' } = payload;
        return await this.devicesService.create(body, userId);
    }
}
