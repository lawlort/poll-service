import { Module } from '@nestjs/common';
import { DevicesService } from './devices.service';
import { DevicesController } from './devices.controller';
import { MongooseModule } from '@nestjs/mongoose';
import DeviceSchema, { Device } from './schemas/device.schema';
import { UsersModule } from 'src/users/users.module';

@Module({
    imports: [MongooseModule.forFeature([{ name: Device.name, schema: DeviceSchema }]), UsersModule],
    controllers: [DevicesController],
    providers: [DevicesService]
})
export class DevicesModule {}
