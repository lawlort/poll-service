import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Device, DeviceDocument } from './schemas/device.schema';
import { validateSchema } from '../utils/joi/schemaValidation';
import { CreateDeviceSchema } from './dto/createDeviceSchema';
import { RpcException } from '@nestjs/microservices';
import { UsersService } from '../users/users.service';

@Injectable()
export class DevicesService {
    constructor(
        @InjectModel(Device.name)
        private readonly deviceModel: Model<DeviceDocument>,
        private readonly usersService: UsersService
    ) {}

    async create(deviceData: any, currentUserId: any) {
        try {
            validateSchema(CreateDeviceSchema, deviceData);
            await this.usersService.getUserById(currentUserId);

            deviceData.user = currentUserId;
            const createdDevice = new this.deviceModel(deviceData);
            const savedDevice: any = await createdDevice.save();

            const transformedDevice = savedDevice.toClient();

            return transformedDevice;
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
