import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true })
export class Device {
    @Prop({ required: true, maxlength: 50 })
    deviceId: string;

    @Prop({ required: true, type: mongooseSchema.Types.ObjectId })
    user: string;

    @Prop({ maxlength: 15 })
    ip: string;

    @Prop({ maxlength: 50 })
    os: string;

    @Prop({ maxlength: 20 })
    osVersion: string;

    @Prop({ maxlength: 100, required: true })
    deviceToken: string;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    createdBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    updatedBy: string;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;
}

export const DeviceSchema = SchemaFactory.createForClass(Device);

DeviceSchema.index({ deviceId: 1 });

DeviceSchema.set('toJSON', { getters: true, virtuals: true });

DeviceSchema.method('toClient', function () {
    const obj: any = this.toObject();

    //Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type DeviceDocument = Document & Device;

export default DeviceSchema;
