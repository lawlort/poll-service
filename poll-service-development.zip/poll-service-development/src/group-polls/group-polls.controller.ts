import { Controller } from '@nestjs/common';
import { GroupPollsService } from './group-polls.service';

@Controller('group-polls')
export class GroupPollsController {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor(private readonly groupPollsService: GroupPollsService) {}
}
