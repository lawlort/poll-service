import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { GroupPoll } from './schemas/group-polls.schema';
import { Model } from 'mongoose';
import { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import { GroupMember } from 'src/group-members/schemas/group-members.schema';
import { RpcException } from '@nestjs/microservices';
import { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';

@Injectable()
export class GroupPollsService {
    constructor(
        @InjectModel(GroupPoll.name) private groupPollModel: Model<GroupPoll>,
        @InjectModel(SharedPoll.name) private sharedPollModel: Model<SharedPoll>,
        @InjectModel(GroupMember.name) private groupMemberModel: Model<GroupMember>,
        @InjectModel(FollowRequest.name) private followRequestModel: Model<FollowRequest>
    ) {}

    async sharePollWithGroups(pollId: string, sharedBy: string, groupPollIds: string[] = []) {
        const groupPolls = [];
        for (let i = 0; i < groupPollIds.length; i++) {
            const groupPoll = {
                pollId,
                sharedBy,
                groupId: groupPollIds[i]
            };
            groupPolls.push(groupPoll);
        }
        await this.groupPollModel.insertMany(groupPolls);
    }

    async sharePollWithUniqueUsers(pollId: string, sharedBy: string, sharedWithUserIds: string[] = []) {
        try {
            const sharedPolls = [];
            // Filter valid user IDs
            const validUserIds = sharedWithUserIds.filter((userId) => userId !== undefined && userId !== null);

            // Prepare shared polls
            for (let i = 0; i < validUserIds.length; i++) {
                const sharedPoll = {
                    pollId,
                    sharedBy,
                    sharedWith: validUserIds[i]
                };
                sharedPolls.push(sharedPoll);
            }

            // Insert shared polls in bulk
            if (sharedPolls.length > 0) {
                try {
                    await this.sharedPollModel.insertMany(sharedPolls, { ordered: false });
                } catch (bulkError) {
                    console.log('Error inserting shared polls:', bulkError);
                }
            }
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
