import { Module } from '@nestjs/common';
import { GroupPollsService } from './group-polls.service';
import { GroupPollsController } from './group-polls.controller';
import GroupPollSchema, { GroupPoll } from './schemas/group-polls.schema';
import { MongooseModule } from '@nestjs/mongoose';
import SharedPollSchema, { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import GroupMemberSchema, { GroupMember } from 'src/group-members/schemas/group-members.schema';
import FollowRequestSchema, { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: GroupPoll.name, schema: GroupPollSchema },
            { name: SharedPoll.name, schema: SharedPollSchema },
            { name: GroupMember.name, schema: GroupMemberSchema },
            { name: FollowRequest.name, schema: FollowRequestSchema }
        ])
    ],
    controllers: [GroupPollsController],
    providers: [GroupPollsService],
    exports: [GroupPollsService]
})
export class GroupPollsModule {}
