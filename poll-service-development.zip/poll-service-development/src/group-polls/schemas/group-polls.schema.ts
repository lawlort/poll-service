import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';
import { Group } from 'src/groups/schemas/group.schema';
import { Poll } from 'src/polls/schemas/poll.schema';
import { User } from 'src/users/schemas/user.schema';

@Schema({ timestamps: true, collection: 'group_polls', versionKey: false })
export class GroupPoll {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true, ref: Group.name })
    groupId: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true, ref: Poll.name })
    pollId: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true, ref: User.name })
    sharedBy: string;

    @Prop({ default: false })
    isDeleted: boolean;
}

export const GroupPollSchema = SchemaFactory.createForClass(GroupPoll);

GroupPollSchema.index({ groupId: 1, pollId: 1 });
GroupPollSchema.index({ pollId: 1 });
GroupPollSchema.index({ groupId: 1 });

export type GroupPollDocument = HydratedDocument<GroupPoll>;

export default GroupPollSchema;
