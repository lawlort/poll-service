import { Module } from '@nestjs/common';
import { DeleteAccountReasonsService } from './delete-account-reasons.service';
import { DeleteAccountReasonsController } from './delete-account-reasons.controller';
import { MongooseModule } from '@nestjs/mongoose';
import DeleteAccountReasonSchema, { DeleteAccountReason } from './schemas/delete-account-reasons.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: DeleteAccountReason.name, schema: DeleteAccountReasonSchema }])],
    controllers: [DeleteAccountReasonsController],
    providers: [DeleteAccountReasonsService]
})
export class DeleteAccountReasonsModule {}
