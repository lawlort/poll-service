import { Controller } from '@nestjs/common';
import { DeleteAccountReasonsService } from './delete-account-reasons.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_DELETE_ACCOUNT_REASONS } from 'src/utils/constants/commands';

@Controller('delete-account-reasons')
export class DeleteAccountReasonsController {
    constructor(private readonly deleteAccountReasonsService: DeleteAccountReasonsService) {}

    @MessagePattern({ cmd: CMD_GET_DELETE_ACCOUNT_REASONS })
    async findAll() {
        return await this.deleteAccountReasonsService.findAll();
    }
}
