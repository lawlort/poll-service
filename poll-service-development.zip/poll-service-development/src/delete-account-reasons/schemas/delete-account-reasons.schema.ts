import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, versionKey: false, collection: 'delete_account_reasons' })
export class DeleteAccountReason {
    @Prop({ required: true })
    reason: string;

    @Prop({ type: Boolean, default: true })
    isActive: boolean;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    createdBy: mongooseSchema.Types.ObjectId;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    updatedBy: mongooseSchema.Types.ObjectId;
}

const DeleteAccountReasonSchema = SchemaFactory.createForClass(DeleteAccountReason);

DeleteAccountReasonSchema.index({ reason: 1 }, { unique: true });

DeleteAccountReasonSchema.method('toClient', function () {
    const obj: any = this.toObject();

    // Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type DeleteAccountReasonDocument = HydratedDocument<DeleteAccountReason>;

export default DeleteAccountReasonSchema;
