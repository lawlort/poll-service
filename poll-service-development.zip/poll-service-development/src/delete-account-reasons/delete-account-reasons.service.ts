import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { DeleteAccountReason } from './schemas/delete-account-reasons.schema';
import { Model } from 'mongoose';

@Injectable()
export class DeleteAccountReasonsService {
    constructor(
        @InjectModel(DeleteAccountReason.name)
        private deleteAccountReasonModel: Model<DeleteAccountReason>
    ) {}

    async findAll() {
        try {
            const res = await this.deleteAccountReasonModel.find({ isActive: true, isDeleted: false }).exec();
            return (res || []).map((item) => {
                return {
                    id: item._id,
                    reason: item.reason
                };
            });
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
