import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { ReportCommentReason } from './schemas/report-comment-reasons.schema';
import { Model } from 'mongoose';

@Injectable()
export class ReportCommentReasonsService {
    constructor(
        @InjectModel(ReportCommentReason.name)
        private reportCommentReasonModel: Model<ReportCommentReason>
    ) {}

    async findAll() {
        try {
            const res = await this.reportCommentReasonModel.find({ isActive: true, isDeleted: false }).exec();
            return (res || []).map((item) => {
                return {
                    id: item._id,
                    reason: item.reason
                };
            });
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
