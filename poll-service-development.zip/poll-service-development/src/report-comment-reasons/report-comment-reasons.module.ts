import { Module } from '@nestjs/common';
import { ReportCommentReasonsService } from './report-comment-reasons.service';
import { ReportCommentReasonsController } from './report-comment-reasons.controller';
import { MongooseModule } from '@nestjs/mongoose';
import ReportCommentReasonSchema, { ReportCommentReason } from './schemas/report-comment-reasons.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: ReportCommentReason.name, schema: ReportCommentReasonSchema }])],
    controllers: [ReportCommentReasonsController],
    providers: [ReportCommentReasonsService]
})
export class ReportCommentReasonsModule {}
