import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, versionKey: false, collection: 'report_comment_reasons' })
export class ReportCommentReason {
    @Prop({ required: true })
    reason: string;

    @Prop({ type: Boolean, default: true })
    isActive: boolean;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    createdBy: mongooseSchema.Types.ObjectId;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    updatedBy: mongooseSchema.Types.ObjectId;
}

const ReportCommentReasonSchema = SchemaFactory.createForClass(ReportCommentReason);

ReportCommentReasonSchema.index({ reason: 1 }, { unique: true });

ReportCommentReasonSchema.method('toClient', function () {
    const obj: any = this.toObject();

    //Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type ReportCommentReasonDocument = HydratedDocument<ReportCommentReason>;

export default ReportCommentReasonSchema;
