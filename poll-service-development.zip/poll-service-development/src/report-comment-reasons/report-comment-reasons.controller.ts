import { Controller } from '@nestjs/common';
import { ReportCommentReasonsService } from './report-comment-reasons.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_REPORT_COMMENT_REASONS } from 'src/utils/constants/commands';

@Controller('report-comment-reasons')
export class ReportCommentReasonsController {
    constructor(private readonly reportCommentReasonsService: ReportCommentReasonsService) {}

    @MessagePattern({ cmd: CMD_GET_REPORT_COMMENT_REASONS })
    async findAll() {
        return await this.reportCommentReasonsService.findAll();
    }
}
