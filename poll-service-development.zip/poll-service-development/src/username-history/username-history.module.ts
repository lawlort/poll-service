import { Module } from '@nestjs/common';
import { UsernameHistoryService } from './username-history.service';
import { UsernameHistoryController } from './username-history.controller';
import { MongooseModule } from '@nestjs/mongoose';
import UsernameHistorySchema, { UsernameHistory } from './schema/username-history.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: UsernameHistory.name, schema: UsernameHistorySchema }])],
    controllers: [UsernameHistoryController],
    providers: [UsernameHistoryService]
})
export class UsernameHistoryModule {}
