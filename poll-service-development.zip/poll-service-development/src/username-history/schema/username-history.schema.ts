import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'username_history' }) // Automatically adds updatedAt timestamp
export class UsernameHistory {
    @Prop({ required: true, type: mongooseSchema.Types.ObjectId })
    userId: string; // Storing user ID

    @Prop({ required: true })
    username: string; // Storing username

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;
}

export const UsernameHistorySchema = SchemaFactory.createForClass(UsernameHistory);

// Create an index on userId and username to optimize lookups
UsernameHistorySchema.index({ userId: 1, username: 1 });

export type UsernameHistoryDocument = HydratedDocument<UsernameHistory>;

export default UsernameHistorySchema;
