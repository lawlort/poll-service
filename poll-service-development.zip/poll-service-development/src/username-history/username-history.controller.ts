import { Controller } from '@nestjs/common';
import { UsernameHistoryService } from './username-history.service';

@Controller('username-history')
export class UsernameHistoryController {
    constructor(private readonly usernameHistoryService: UsernameHistoryService) {}
}
