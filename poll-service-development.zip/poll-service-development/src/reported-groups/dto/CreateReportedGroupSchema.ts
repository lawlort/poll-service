import * as Joi from 'joi';

// Define a common pattern for ObjectId validation
const objectIdPattern = /^[0-9a-fA-F]{24}$/;

// Define Joi schema for ReportedPoll
export const CreateReportedGroupJoiSchema = Joi.object({
    reportedBy: Joi.string().pattern(objectIdPattern).required().messages({
        'string.pattern.base': 'ReportedBy must be a valid ObjectId',
        'any.required': 'ReportedBy is required'
    }),

    groupId: Joi.string().pattern(objectIdPattern).required().messages({
        'string.pattern.base': 'groupId must be a valid ObjectId',
        'any.required': 'groupId is required'
    }),

    reason: Joi.string()
        .required()
        .messages({
            'any.required': 'Reason is required'
        })
        .max(255),

    reportedAt: Joi.date().optional()
});
