import { Module } from '@nestjs/common';
import { ReportedGroupsService } from './reported-groups.service';
import { ReportedGroupsController } from './reported-groups.controller';
import { MongooseModule } from '@nestjs/mongoose';
import ReportedGroupSchema, { ReportedGroup } from './schema/reported-group.schema';
import GroupSchema, { Group } from 'src/groups/schemas/group.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: ReportedGroup.name, schema: ReportedGroupSchema },
            { name: Group.name, schema: GroupSchema }
        ])
    ],
    controllers: [ReportedGroupsController],
    providers: [ReportedGroupsService]
})
export class ReportedGroupsModule {}
