import { Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreateReportedGroupJoiSchema } from './dto/CreateReportedGroupSchema';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { ReportedGroup } from './schema/reported-group.schema';
import { Model } from 'mongoose';
import { Group } from 'src/groups/schemas/group.schema';

@Injectable()
export class ReportedGroupsService {
    constructor(
        @InjectModel(ReportedGroup.name) private reportedGroupModel: Model<ReportedGroup>,
        @InjectModel(Group.name) private groupModel: Model<Group>
    ) {}

    async create(createReportedGroupDto, userId, groupId) {
        try {
            const payload = {
                ...createReportedGroupDto,
                reportedBy: userId,
                groupId
            };
            validateSchema(CreateReportedGroupJoiSchema, payload);

            const group = await this.groupModel.findOne({ _id: groupId });
            if (!group?._id || group?.isDeleted || !group?.isActive) {
                throw new NotFoundException('Group not found');
            }

            const existingReportedGroup = await this.reportedGroupModel.findOne({
                groupId,
                reportedBy: userId
            });
            if (existingReportedGroup?._id) {
                throw new UnprocessableEntityException('You have already reported this poll');
            }

            const createdReportedPoll = await this.reportedGroupModel.create(payload);
            return { success: !!createdReportedPoll?._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
