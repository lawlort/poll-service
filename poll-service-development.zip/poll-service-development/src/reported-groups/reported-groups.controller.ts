import { Body, Controller } from '@nestjs/common';
import { ReportedGroupsService } from './reported-groups.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_REPORT_GROUP } from 'src/utils/constants/commands';

@Controller('reported-groups')
export class ReportedGroupsController {
    constructor(private readonly reportedGroupsService: ReportedGroupsService) {}

    @MessagePattern({ cmd: CMD_REPORT_GROUP })
    async create(@Body() payload) {
        const { body = {}, userId, groupId } = payload;
        return await this.reportedGroupsService.create(body, userId, groupId);
    }
}
