import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'reported_groups', versionKey: false })
export class ReportedGroup {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    reportedBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    groupId: string;

    @Prop({ type: String, required: true })
    reason: string;

    @Prop({ type: Date, default: Date.now })
    reportedAt: Date;
}

export const ReportedGroupSchema = SchemaFactory.createForClass(ReportedGroup);

// Indexes to ensure uniqueness and optimize queries
ReportedGroupSchema.index({ reportedBy: 1, groupId: 1 }, { unique: true });
ReportedGroupSchema.index({ groupId: 1 });
ReportedGroupSchema.index({ reportedBy: 1 });
ReportedGroupSchema.index({ reportedAt: 1 });

export type ReportedGroupDocument = HydratedDocument<ReportedGroup>;

export default ReportedGroupSchema;
