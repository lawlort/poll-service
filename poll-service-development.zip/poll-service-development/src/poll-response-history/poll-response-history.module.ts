import { Module } from '@nestjs/common';
import { PollResponseHistoryService } from './poll-response-history.service';
import { PollResponseHistoryController } from './poll-response-history.controller';
import { MongooseModule } from '@nestjs/mongoose';
import PollResponseHistorySchema, { PollResponseHistory } from './schemas/poll-response-history.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: PollResponseHistory.name, schema: PollResponseHistorySchema }])],
    controllers: [PollResponseHistoryController],
    providers: [PollResponseHistoryService]
})
export class PollResponseHistoryModule {}
