import { Controller } from '@nestjs/common';
import { PollResponseHistoryService } from './poll-response-history.service';

@Controller('poll-response-history')
export class PollResponseHistoryController {
    constructor(private readonly pollResponseHistoryService: PollResponseHistoryService) {}
}
