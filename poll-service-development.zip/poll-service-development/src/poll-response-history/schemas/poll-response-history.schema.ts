import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'poll_responses_history' })
export class PollResponseHistory {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    userId: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    pollId: string;

    @Prop({ required: true, default: Date.now })
    respondedAt: Date;

    @Prop({ default: false })
    isDeleted: boolean;
}

export const PollResponseHistorySchema = SchemaFactory.createForClass(PollResponseHistory);

// Define indexes to optimize query performance
PollResponseHistorySchema.index({ pollId: 1, userId: 1 });
PollResponseHistorySchema.index({ userId: 1 });
PollResponseHistorySchema.index({ pollId: 1 });

export type PollResponseHistoryDocument = HydratedDocument<PollResponseHistory>;

export default PollResponseHistorySchema;
