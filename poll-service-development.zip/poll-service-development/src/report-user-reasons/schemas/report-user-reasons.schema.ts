import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, versionKey: false, collection: 'report_user_reasons' })
export class ReportUserReason {
    @Prop({ required: true })
    reason: string;

    @Prop({ type: Boolean, default: true })
    isActive: boolean;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    createdBy: mongooseSchema.Types.ObjectId;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    updatedBy: mongooseSchema.Types.ObjectId;
}

const ReportUserReasonSchema = SchemaFactory.createForClass(ReportUserReason);

ReportUserReasonSchema.index({ reason: 1 }, { unique: true });

ReportUserReasonSchema.method('toClient', function () {
    const obj: any = this.toObject();

    //Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type ReportUserReasonDocument = HydratedDocument<ReportUserReason>;

export default ReportUserReasonSchema;
