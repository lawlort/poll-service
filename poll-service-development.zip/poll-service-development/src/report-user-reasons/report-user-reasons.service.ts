import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { ReportUserReason } from './schemas/report-user-reasons.schema';
import { Model } from 'mongoose';

@Injectable()
export class ReportUserReasonsService {
    constructor(
        @InjectModel(ReportUserReason.name)
        private reportUserReasonModel: Model<ReportUserReason>
    ) {}

    async findAll() {
        try {
            const res = await this.reportUserReasonModel.find({ isActive: true, isDeleted: false }).exec();
            return (res || []).map((item) => {
                return {
                    id: item._id,
                    reason: item.reason
                };
            });
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
