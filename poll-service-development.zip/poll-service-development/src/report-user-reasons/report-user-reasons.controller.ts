import { Controller } from '@nestjs/common';
import { ReportUserReasonsService } from './report-user-reasons.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_REPORT_USER_REASONS } from 'src/utils/constants/commands';

@Controller('report-user-reasons')
export class ReportUserReasonsController {
    constructor(private readonly reportUserReasonsService: ReportUserReasonsService) {}

    @MessagePattern({ cmd: CMD_GET_REPORT_USER_REASONS })
    async findAll() {
        return await this.reportUserReasonsService.findAll();
    }
}
