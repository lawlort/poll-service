import { Module } from '@nestjs/common';
import { ReportUserReasonsService } from './report-user-reasons.service';
import { ReportUserReasonsController } from './report-user-reasons.controller';
import { MongooseModule } from '@nestjs/mongoose';
import ReportUserReasonSchema, { ReportUserReason } from './schemas/report-user-reasons.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: ReportUserReason.name, schema: ReportUserReasonSchema }])],
    controllers: [ReportUserReasonsController],
    providers: [ReportUserReasonsService]
})
export class ReportUserReasonsModule {}
