import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model } from 'mongoose';
import { BookmarkedPoll } from 'src/bookmarked-polls/schemas/bookmarked-poll.schema';
import { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import { PollComment } from 'src/poll-comments/schemas/poll-comment.schema';
import { PollResponseHistory } from 'src/poll-response-history/schemas/poll-response-history.schema';
import { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
import { Poll, QuestionTypes, VisibilityTypes } from 'src/polls/schemas/poll.schema';
import { TRUE_STRING } from 'src/utils/constants/string';

@Injectable()
export class FeedService {
    constructor(
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        @InjectModel(PollResponse.name) private pollResponseModel: Model<PollResponse>,
        @InjectModel(PollComment.name) private pollCommentModel: Model<PollComment>,
        @InjectModel(PollResponseHistory.name) private pollResponseHistoryModel: Model<PollResponseHistory>,
        @InjectModel(BookmarkedPoll.name) private bookmarkPollModel: Model<BookmarkedPoll>,
        @InjectModel(GroupPoll.name) private groupPollModel: Model<GroupPoll>
    ) {}

    async findAll(userId, paginateOptions, queryParams) {
        try {
            const currentDate = new Date();

            const queryConditions = { isDeleted: false, isActive: true };

            // show live polls only
            if (queryParams.liveOnly === TRUE_STRING) {
                queryConditions['endDate'] = { $gt: currentDate };
            }

            // if only private polls are requested
            if (queryParams.privateOnly === TRUE_STRING) {
                queryConditions['visibility'] = VisibilityTypes.PRIVATE;
            }

            if (queryParams.lastPollId) {
                queryConditions['_id'] = { $gt: mongoose.Types.ObjectId.createFromHexString(queryParams.lastPollId) }; // Fetch polls with ID greater than the last poll ID
            }

            // Find polls that are not deleted and not expired
            let query = this.pollModel.find(queryConditions);

            // Sort by `createdAt` in ascending order
            query = query.sort({ createdAt: -1 });

            // Limit the number of results
            query = query.limit(500); // Adjust this number based on your needs and performance

            // Select specific fields
            query = query
                .select({
                    visibility: 1,
                    isAnonymous: 1,
                    allowComments: 1,
                    bgImageUrl: 1,
                    convertedMediaUrl: 1,
                    thumbnailUrl: 1,
                    mediaType: 1,
                    endDate: 1,
                    status: 1,
                    createdByUsername: 1,
                    createdByUserId: 1,
                    createdByUserProfilePicUrl: 1,
                    interests: 1,
                    questions: 1,
                    displayResultMode: 1,
                    createdAt: 1,
                    isDeleted: 1,
                    updatedBy: 1,
                    isClosed: 1
                })
                .populate({
                    path: 'interests', // Populate the interests field
                    select: 'name' // Specify fields to include from the Interest model
                });

            let skipCount = (paginateOptions.page - 1) * paginateOptions.limit;
            if (queryParams.skip) {
                skipCount = parseInt(queryParams.skip);
            }

            if (paginateOptions.paginate) {
                const count = await query.clone().countDocuments();
                const results = await query.skip(skipCount).limit(paginateOptions.limit).exec();

                const remainingDocuments = count - skipCount;

                // Ensure the remaining documents is not negative
                const adjustedRemainingDocuments = remainingDocuments > 0 ? remainingDocuments : 0;

                // Calculate total pages based on remaining documents and limit
                const totalPages = Math.ceil(adjustedRemainingDocuments / paginateOptions.limit);

                const voterImages = [
                    'https://www.shutterstock.com/image-photo/image-handsome-smiling-young-african-260nw-722913181.jpg',
                    'https://t4.ftcdn.net/jpg/02/32/98/33/360_F_232983351_z5CAl79bHkm6eMPSoG7FggQfsJLxiZjY.jpg',
                    'https://st2.depositphotos.com/4431055/7492/i/950/depositphotos_74925449-stock-photo-men-human-face-smiling.jpg'
                ];

                const temp = results.map((res) => {
                    const temp1 = res.toJSON();

                    if (temp1?.isAnonymous) {
                        temp1.createdByUsername = '';
                        temp1.createdByUserProfilePicUrl = '';
                    }

                    temp1['voterImages'] = voterImages;
                    temp1['votes'] = 0;
                    return temp1;
                });

                const pollIds = temp.map((poll) => poll._id);

                const polls = await this.pollModel.find({ _id: { $in: pollIds } });

                const pollIdObj: any = {};
                polls.forEach((poll: any) => {
                    pollIdObj[poll._id] = poll;
                });

                // Loop through pollIds and fetch poll responses for each poll
                const pollResponsesObj: any = {}; // Object to store poll responses by pollId
                const pollResponseHistory: any = {};

                // Using Promise.all to fetch responses concurrently
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponses = await this.pollResponseModel.find({ pollId, userId });
                        pollResponsesObj[pollId.toString()] = pollResponses; // Store responses for each pollId
                    })
                );

                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                            pollId,
                            userId,
                            isDeleted: false
                        });
                        pollResponseHistory[pollId.toString()] = pollResponseHistoryCount; // Store responses for each pollId
                    })
                );

                const pollCommentObj: any = {}; // Object to store poll comments by pollId
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollComments = await this.pollCommentModel.countDocuments({ pollId, isDeleted: false });
                        pollCommentObj[pollId.toString()] = pollComments; // Store comments for each pollId
                    })
                );

                const bookmarkedPollObj: any = {};
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const bookmarkedPoll = await this.bookmarkPollModel.findOne({ pollId, bookmarkedBy: userId });
                        bookmarkedPollObj[pollId.toString()] = bookmarkedPoll?._id ? true : false;
                    })
                );

                const pollResponseCountObj: any = {}; // Object to store poll responses count by pollId

                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const count = await this.pollResponseModel.countDocuments({ pollId });

                        // Store the response count for each poll
                        pollResponseCountObj[pollId.toString()] = count;
                    })
                );

                // loop through each poll and manage responded flag
                for (const poll of temp) {
                    const pollResponses = pollResponsesObj[poll._id.toString()]; // Poll responses for this pollId
                    poll['isAnswered'] = pollResponses.length > 0;
                    poll['commentCount'] = pollCommentObj[poll._id.toString()];
                    poll['isSaved'] = bookmarkedPollObj[poll._id.toString()];
                    poll['votes'] = pollResponseCountObj[poll._id.toString()];
                    poll['allowChangeMyMind'] = pollResponseHistory[poll._id.toString()] < 2;
                    if (poll?.questions?.length) {
                        poll.questions = poll.questions.map((question: any) => {
                            const options = question?.options || [];

                            // If poll type is SINGLE_CHOICE or THIS_THAT
                            if (
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.THIS_THAT
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionId = pollResponse?.optionId;

                                // Map options to add isSelected field
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: option.id === optionId
                                }));
                            }

                            // If poll type is MULTIPLE_CHOICE or DATE
                            if (
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionIds = pollResponse?.optionIds || [];

                                // Map options to add isSelected field for multiple choice
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: optionIds.includes(option.id)
                                }));
                            }

                            // If poll type is SLIDER or LIGHT_METER
                            if (
                                question?.type === QuestionTypes.SLIDER ||
                                question?.type === QuestionTypes.LIGHT_METER
                            ) {
                                pollResponses?.length &&
                                    pollResponses[0] &&
                                    (question.sliderValue = pollResponses[0]?.sliderValue || 0);
                            }

                            // If poll type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                question.options = options.map((option) => {
                                    const pollResponse = pollResponses.find(
                                        (response) => response.optionId === option.id
                                    );
                                    return {
                                        ...option,
                                        selectedRank: pollResponse?.order || null
                                    };
                                });
                            }

                            return question;
                        });
                    }
                }

                const pollResponsesPromises = temp.map(async (poll) => {
                    const pollId = poll._id;
                    const pollResponses = await this.getPollVotersProfilePicUrls(pollId);
                    poll['voterImages'] = pollResponses;
                    if (poll?.interests) {
                        poll.interests = (poll.interests || []).map((interest: any) => interest.name);
                    }
                    return poll; // Return poll with added voterImages
                });

                // Wait for all the promises to resolve
                const pollsWithVoterImages = await Promise.all(pollResponsesPromises);
                return {
                    docs: pollsWithVoterImages,
                    page: paginateOptions.page,
                    limit: paginateOptions.limit,
                    totalPages,
                    totalResults: count
                };
            } else {
                return query.exec();
            }
        } catch (err) {
            throw new RpcException(err);
        }
    }

    async getPollVotersProfilePicUrls(pollId) {
        try {
            const pollResponses = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId // First, filter by pollId
                    }
                },
                {
                    $sort: { createdAt: -1 } // Sort responses by creation date in descending order
                },
                {
                    $limit: 1000 // Limit the result to the last 1000 responses
                },
                {
                    $lookup: {
                        from: 'users', // Join with the 'users' collection
                        localField: 'userId',
                        foreignField: '_id',
                        as: 'user'
                    }
                },
                {
                    $unwind: '$user' // Unwind the user data
                },
                {
                    $match: {
                        'user.profilePicUrl': { $exists: true, $ne: '' } // Ensure profilePicUrl exists and is not empty
                    }
                },
                {
                    $group: {
                        _id: { pollId: '$pollId', userId: '$userId' }, // Group by pollId and userId
                        responses: { $push: '$$ROOT' }, // Push entire document into an array
                        profilePicUrl: { $first: '$user.profilePicUrl' } // Keep the profilePicUrl from the first (latest) response
                    }
                },
                {
                    $project: {
                        pollId: '$_id.pollId',
                        userId: '$_id.userId',
                        responses: { $slice: ['$responses', 3] }, // Limit to the last 3 responses
                        profilePicUrl: 1 // Include the profilePicUrl field
                    }
                }
            ]);

            return pollResponses.map((response) => response.profilePicUrl);
        } catch (err) {
            throw new RpcException(err);
        }
    }
}
