import { Inject, Injectable, forwardRef } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model } from 'mongoose';
// import { share } from 'rxjs';
import { BookmarkedPoll } from 'src/bookmarked-polls/schemas/bookmarked-poll.schema';
import { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';
import { GroupMember } from 'src/group-members/schemas/group-members.schema';
import { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
// import { PollComment } from 'src/poll-comments/schemas/poll-comment.schema';
import { PollResponseHistory } from 'src/poll-response-history/schemas/poll-response-history.schema';
import { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
// import { PollView } from 'src/poll-views/schemas/poll-view.schema';
import { Poll, QuestionTypes, VisibilityTypes } from 'src/polls/schemas/poll.schema';
import { RedisService } from 'src/redis/redis.service';
import { SharedPollWithUsers } from 'src/shared-poll-with-users/schemas/shared-poll-with-users.schema';
import { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
// import { User } from 'src/users/schemas/user.schema';
import { UsersService } from 'src/users/users.service';
import { FollowRequestStatus, TRUE_STRING } from 'src/utils/constants/string';
// import { UsersService } from 'src/users/users.service';

@Injectable()
export class FeedServiceV3 {
    constructor(
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        // @InjectModel(PollView.name) private pollViewModel: Model<PollView>,
        @InjectModel(PollResponse.name) private pollResponseModel: Model<PollResponse>,
        // @InjectModel(PollComment.name) private pollCommentModel: Model<PollComment>,
        @InjectModel(BookmarkedPoll.name) private bookmarkPollModel: Model<BookmarkedPoll>,
        @InjectModel(PollResponseHistory.name) private pollResponseHistoryModel: Model<PollResponseHistory>,
        @InjectModel(GroupMember.name) private groupMemberModel: Model<GroupMember>,
        @InjectModel(GroupPoll.name) private groupPollModel: Model<GroupPoll>,
        @InjectModel(SharedPoll.name) private sharedPollModel: Model<SharedPoll>,
        @InjectModel(SharedPollWithUsers.name) private sharedPollWithUsersModel: Model<SharedPollWithUsers>,
        @InjectModel(FollowRequest.name) private followRequestModel: Model<FollowRequest>,
        @Inject(forwardRef(() => UsersService)) private userService: UsersService,
        private redisService: RedisService
    ) {}

    async findAll(userId, paginateOptions, queryParams) {
        try {
            this.prepareUserFeed(userId);
            //TODO: if user created anonymously then do not send created by username and created by profile pic
            //TODO: add group array

            const currentDate = new Date();
            // Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate())

            const queryConditions = { isDeleted: false, isActive: true };

            // show live polls only
            if (queryParams.liveOnly === TRUE_STRING) {
                queryConditions['endDate'] = { $gt: currentDate };
            }

            // if only private polls are requested
            if (queryParams.privateOnly === TRUE_STRING) {
                queryConditions['visibility'] = VisibilityTypes.PRIVATE;
            }

            // Find polls that are not deleted and not expired
            let query = this.pollModel.find(queryConditions);

            // Sort by `createdAt` in ascending order
            query = query.sort({ createdAt: -1 });

            // Limit the number of results
            query = query.limit(500); // Adjust this number based on your needs and performance

            // Select specific fields
            query = query
                .select({
                    visibility: 1,
                    isAnonymous: 1,
                    bgImageUrl: 1,
                    convertedMediaUrl: 1,
                    thumbnailUrl: 1,
                    mediaType: 1,
                    endDate: 1,
                    status: 1,
                    createdByUsername: 1,
                    createdByUserId: 1,
                    createdByUserProfilePicUrl: 1,
                    interests: 1,
                    questions: 1,
                    displayResultMode: 1,
                    createdAt: 1,
                    updatedBy: 1,
                    isClosed: 1
                })
                .populate({
                    path: 'interests', // Populate the interests field
                    select: 'name' // Specify fields to include from the Interest model
                });

            if (paginateOptions.paginate) {
                const count = await query.clone().countDocuments();
                const results = await query
                    .skip((paginateOptions.page - 1) * paginateOptions.limit)
                    .limit(paginateOptions.limit)
                    .exec();

                const user = await this.userService.getUserById(userId);
                const userInterests = (user?.interests || []).map((interest) => interest.name);

                const initialFeed = results.map((res) => {
                    const poll = res.toJSON();

                    if (poll?.isAnonymous) {
                        poll.createdByUsername = '';
                        poll.createdByUserProfilePicUrl = '';
                    }

                    poll['interests'] = (poll.interests || []).filter((interest: any) =>
                        userInterests.includes(interest.name)
                    );
                    return poll;
                });

                const pollIds = initialFeed.map((poll) => poll._id);

                const polls = await this.pollModel.find({ _id: { $in: pollIds } });

                const pollIdObj: any = {};
                polls.forEach((poll: any) => {
                    pollIdObj[poll._id] = poll;
                });

                // Loop through pollIds and fetch poll responses for each poll
                const pollResponsesObj: any = {}; // Object to store poll responses by pollId
                const pollResponseHistory: any = {};

                // Using Promise.all to fetch responses concurrently
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponsesCount = await this.pollResponseModel.countDocuments({ pollId, userId });
                        pollResponsesObj[pollId.toString()] = pollResponsesCount; // Store responses for each pollId
                    })
                );

                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                            pollId,
                            userId,
                            isDeleted: false
                        });
                        pollResponseHistory[pollId.toString()] = pollResponseHistoryCount; // Store responses for each pollId
                    })
                );

                const bookmarkedPollObj: any = {};
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const bookmarkedPoll = await this.bookmarkPollModel.findOne({ pollId, bookmarkedBy: userId });
                        bookmarkedPollObj[pollId.toString()] = bookmarkedPoll?._id ? true : false;
                    })
                );

                const pollResponseCountObj: any = {}; // Object to store poll responses count by pollId

                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const poll = pollIdObj[pollId.toString()];
                        let count = 0;

                        if (poll?.questions?.length) {
                            for (const question of poll.questions) {
                                if (question.type === QuestionTypes.RANKING) {
                                    // Perform the aggregation for RANKING type questions
                                    const rankingResults = await this.pollResponseModel.aggregate([
                                        {
                                            $match: {
                                                pollId,
                                                questionId: question.id
                                            }
                                        },
                                        {
                                            $group: {
                                                _id: { pollId: '$pollId', userId: '$userId', questionId: '$questionId' }
                                            }
                                        },
                                        { $count: 'distinctResponses' }
                                    ]);
                                    count += rankingResults.length > 0 ? rankingResults[0].distinctResponses : 0;
                                } else {
                                    // Perform the aggregation for other question types
                                    const nonRankingResults = await this.pollResponseModel.aggregate([
                                        {
                                            $match: {
                                                pollId,
                                                questionId: question.id
                                            }
                                        },
                                        { $count: 'totalResponses' }
                                    ]);
                                    count += nonRankingResults.length > 0 ? nonRankingResults[0].totalResponses : 0;
                                }
                            }
                        }

                        // Store the response count for each poll
                        pollResponseCountObj[pollId.toString()] = count;
                    })
                );

                // loop through each poll and manage responded flag
                for (const poll of initialFeed) {
                    // const pollResponses = pollResponsesObj[poll._id.toString()]; // Poll responses for this pollId
                    poll['isAnswered'] = pollResponsesObj[poll._id.toString()] > 0;
                    poll['isSaved'] = bookmarkedPollObj[poll._id.toString()];
                    poll['votes'] = pollResponseCountObj[poll._id.toString()];
                    poll['allowChangeMyMind'] = pollResponseHistory[poll._id.toString()] < 2;
                }

                const pollResponsesPromises = initialFeed.map(async (poll) => {
                    if (poll?.interests) {
                        poll.interests = (poll.interests || []).map((interest: any) => interest.name);
                    }
                    return poll; // Return poll with added voterImages
                });

                // Wait for all the promises to resolve
                const pollsWithVoterImages = await Promise.all(pollResponsesPromises);
                return {
                    docs: pollsWithVoterImages,
                    page: paginateOptions.page,
                    limit: paginateOptions.limit,
                    totalPages: Math.ceil(count / paginateOptions.limit),
                    totalResults: count
                };
            } else {
                return query.exec();
            }
        } catch (err) {
            throw new RpcException(err);
        }
    }

    setFeedCache(userId, feedIds) {
        this.redisService.setWithExpiry(`${userId}:feed`, feedIds, 60 * 15);
    }

    async findAllV2(userId, paginateOptions, queryParams) {
        try {
            const feedIds: any = await this.redisService.get(`${userId}:feed`);
            let pollIds = [];
            if (feedIds) {
                const feedCache = JSON.parse(feedIds);
                const { data = [], createdAt = '' } = feedCache;
                pollIds = data;

                const cacheAgeInMilliseconds = new Date().getTime() - new Date(createdAt).getTime();
                const cacheAgeInMinutes = cacheAgeInMilliseconds / (1000 * 60);
                if (cacheAgeInMinutes > 10) {
                    this.prepareUserFeed(userId);
                }
            } else if (!feedIds) {
                pollIds = await this.prepareUserFeed(userId);
            }

            const currentDate = new Date();
            // Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate())

            const queryConditions = { isDeleted: false, isActive: true };

            // show live polls only
            if (queryParams.liveOnly === TRUE_STRING) {
                queryConditions['endDate'] = { $gt: currentDate };
            }

            // if only private polls are requested
            if (queryParams.privateOnly === TRUE_STRING) {
                queryConditions['visibility'] = VisibilityTypes.PRIVATE;
            }

            queryConditions['_id'] = { $in: pollIds };

            // Find polls that are not deleted and not expired
            let query = this.pollModel.find(queryConditions);

            // Sort by `createdAt` in ascending order
            query = query.sort({ createdAt: -1 });

            // Limit the number of results
            query = query.limit(100); // Adjust this number based on your needs and performance

            // Select specific fields
            query = query
                .select({
                    visibility: 1,
                    isAnonymous: 1,
                    bgImageUrl: 1,
                    convertedMediaUrl: 1,
                    thumbnailUrl: 1,
                    mediaType: 1,
                    endDate: 1,
                    status: 1,
                    createdByUsername: 1,
                    createdByUserId: 1,
                    createdByUserProfilePicUrl: 1,
                    interests: 1,
                    questions: 1,
                    displayResultMode: 1,
                    createdAt: 1,
                    updatedBy: 1,
                    isClosed: 1
                })
                .populate({
                    path: 'interests', // Populate the interests field
                    select: 'name' // Specify fields to include from the Interest model
                });

            if (paginateOptions.paginate) {
                const count = await query.clone().countDocuments();
                const results = await query
                    .skip((paginateOptions.page - 1) * paginateOptions.limit)
                    .limit(paginateOptions.limit)
                    .exec();

                // const user = await this.userService.getUserById(userId);
                // const userInterests = (user?.interests || []).map((interest) => interest.name);

                const pollIds = results.map((poll) => poll._id);

                // get poll shared in group data
                const groupSharedPolls = await this.groupPollModel
                    .find({ pollId: { $in: pollIds }, isDeleted: false })
                    .populate({
                        path: 'groupId'
                    })
                    .exec();

                const privatePollIds = [];

                const initialFeed = results.map((res) => {
                    const poll = res.toJSON();

                    if (poll?.visibility === VisibilityTypes.PRIVATE) {
                        privatePollIds.push(poll._id.toString());
                    }

                    if (poll?.isAnonymous) {
                        poll.createdByUsername = '';
                        poll.createdByUserProfilePicUrl = '';
                    }

                    const groupDetails: any = (
                        groupSharedPolls.filter((groupPoll) => groupPoll.pollId.toString() === poll._id.toString()) ||
                        []
                    ).map((groupPoll) => groupPoll.groupId);

                    poll['groups'] = groupDetails || [];

                    // poll['interests'] = (poll.interests || []).filter((interest: any) =>
                    //     userInterests.includes(interest.name)
                    // );
                    return poll;
                });

                // get unique users and groups with whom poll is shared
                // const uniqueUsersWithWhomPollIsShared = await this.sharedPollModel.aggregate([
                //     {
                //         $match: {
                //             pollId: { $in: privatePollIds },
                //             isDeleted: false
                //         }
                //     },
                //     {
                //         $group: {
                //             _id: '$userId' // Group by userId to get unique users
                //         }
                //     },
                //     {
                //         $count: 'uniqueUserCount' // Count the number of unique users
                //     }
                // ]);

                // const userCount = uniqueUsersWithWhomPollIsShared.length
                //     ? uniqueUsersWithWhomPollIsShared[0].uniqueUserCount
                //     : 0;

                // const uniqueGroupsWithWhomPollIsShared = await this.groupPollModel.aggregate([
                //     {
                //         $match: {
                //             pollId: { $in: privatePollIds }
                //         }
                //     },
                //     {
                //         $group: {
                //             _id: '$groupId' // Group by groupId to get unique groups
                //         }
                //     },
                //     {
                //         $count: 'uniqueGroupCount' // Count the number of unique groups
                //     }
                // ]);

                // const groupCount = uniqueGroupsWithWhomPollIsShared.length
                //     ? uniqueGroupsWithWhomPollIsShared[0].uniqueGroupCount
                //     : 0;

                // const totalUniqueCount = userCount + groupCount;

                // get unique users who voted on private polls
                // const uniqueUserVoteCount = await this.pollResponseModel.aggregate([
                //     {
                //         $match: {
                //             pollId: { $in: privatePollIds } // Match votes on the private polls
                //         }
                //     },
                //     {
                //         $group: {
                //             _id: '$userId' // Group by userId to get unique users
                //         }
                //     },
                //     {
                //         $count: 'uniqueVoterCount' // Count the unique user votes
                //     }
                // ]);

                // const voterCount = uniqueUserVoteCount.length ? uniqueUserVoteCount[0].uniqueVoterCount : 0;

                const polls = await this.pollModel.find({ _id: { $in: pollIds } });

                const pollIdObj: any = {};
                polls.forEach((poll: any) => {
                    pollIdObj[poll._id] = poll;
                });

                // Loop through pollIds and fetch poll responses for each poll
                const pollResponsesObj: any = {}; // Object to store poll responses by pollId
                const pollResponseHistory: any = {};

                // Using Promise.all to fetch responses concurrently
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponsesCount = await this.pollResponseModel.countDocuments({ pollId, userId });
                        pollResponsesObj[pollId.toString()] = pollResponsesCount; // Store responses for each pollId
                    })
                );

                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                            pollId,
                            userId,
                            isDeleted: false
                        });
                        pollResponseHistory[pollId.toString()] = pollResponseHistoryCount; // Store responses for each pollId
                    })
                );

                const bookmarkedPollObj: any = {};
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const bookmarkedPoll = await this.bookmarkPollModel.findOne({ pollId, bookmarkedBy: userId });
                        bookmarkedPollObj[pollId.toString()] = bookmarkedPoll?._id ? true : false;
                    })
                );

                const pollResponseCountObj: any = {}; // Object to store poll responses count by pollId

                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const poll = pollIdObj[pollId.toString()];
                        let count = 0;

                        if (poll?.questions?.length) {
                            for (const question of poll.questions) {
                                if (question.type === QuestionTypes.RANKING) {
                                    // Perform the aggregation for RANKING type questions
                                    const rankingResults = await this.pollResponseModel.aggregate([
                                        {
                                            $match: {
                                                pollId,
                                                questionId: question.id
                                            }
                                        },
                                        {
                                            $group: {
                                                _id: { pollId: '$pollId', userId: '$userId', questionId: '$questionId' }
                                            }
                                        },
                                        { $count: 'distinctResponses' }
                                    ]);
                                    count += rankingResults.length > 0 ? rankingResults[0].distinctResponses : 0;
                                } else {
                                    // Perform the aggregation for other question types
                                    const nonRankingResults = await this.pollResponseModel.aggregate([
                                        {
                                            $match: {
                                                pollId,
                                                questionId: question.id
                                            }
                                        },
                                        { $count: 'totalResponses' }
                                    ]);
                                    count += nonRankingResults.length > 0 ? nonRankingResults[0].totalResponses : 0;
                                }
                            }
                        }

                        // Store the response count for each poll
                        pollResponseCountObj[pollId.toString()] = count;
                    })
                );

                // loop through each poll and manage responded flag
                for (const poll of initialFeed) {
                    // const pollResponses = pollResponsesObj[poll._id.toString()]; // Poll responses for this pollId
                    poll['isAnswered'] = pollResponsesObj[poll._id.toString()] > 0;
                    poll['isSaved'] = bookmarkedPollObj[poll._id.toString()];
                    poll['votes'] = pollResponseCountObj[poll._id.toString()];
                    poll['allowChangeMyMind'] = pollResponseHistory[poll._id.toString()] < 2;
                }

                const pollResponsesPromises = initialFeed.map(async (poll) => {
                    if (poll?.interests) {
                        poll.interests = (poll.interests || []).map((interest: any) => interest.name);
                    }
                    return poll; // Return poll with added voterImages
                });

                // Wait for all the promises to resolve
                const pollsWithVoterImages = await Promise.all(pollResponsesPromises);
                return {
                    docs: pollsWithVoterImages,
                    page: paginateOptions.page,
                    limit: paginateOptions.limit,
                    totalPages: Math.ceil(count / paginateOptions.limit),
                    totalResults: count
                };
            } else {
                query.exec();
            }
        } catch (err) {
            throw new RpcException(err);
        }
    }
    async findAllV3(userId, paginateOptions, queryParams) {
        try {
            const feedIds: any = await this.redisService.get(`${userId}:feed`);
            let pollIds = [];
            if (feedIds) {
                const feedCache = JSON.parse(feedIds);
                const { data = [], createdAt = '' } = feedCache;
                pollIds = data;

                const cacheAgeInMilliseconds = new Date().getTime() - new Date(createdAt).getTime();
                const cacheAgeInMinutes = cacheAgeInMilliseconds / (1000 * 60);
                if (cacheAgeInMinutes > 10) {
                    this.prepareUserFeed(userId);
                }
            } else if (!feedIds) {
                pollIds = await this.prepareUserFeed(userId);
            }

            const currentDate = new Date();
            // Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate())

            const queryConditions = { isDeleted: false, isActive: true };

            // show live polls only
            if (queryParams.liveOnly === TRUE_STRING) {
                queryConditions['endDate'] = { $gt: currentDate };
            }

            // if only private polls are requested
            if (queryParams.privateOnly === TRUE_STRING) {
                queryConditions['visibility'] = VisibilityTypes.PRIVATE;
            }

            queryConditions['_id'] = { $in: pollIds };

            // if (queryParams?.lastPollId) {
            //     queryConditions['_id'] = {
            //         ...queryConditions['_id'],
            //         $gt: mongoose.Types.ObjectId.createFromHexString(queryParams.lastPollId)
            //     };
            // }

            // Find polls that are not deleted and not expired
            let query = this.pollModel.find(queryConditions);

            // Sort by `createdAt` in ascending order
            query = query.sort({ createdAt: -1 });

            // Limit the number of results
            // query = query.limit(100); // Adjust this number based on your needs and performance

            // Select specific fields
            query = query
                .select({
                    visibility: 1,
                    isAnonymous: 1,
                    bgImageUrl: 1,
                    convertedMediaUrl: 1,
                    thumbnailUrl: 1,
                    mediaType: 1,
                    endDate: 1,
                    status: 1,
                    createdByUsername: 1,
                    createdByUserId: 1,
                    createdByUserProfilePicUrl: 1,
                    interests: 1,
                    questions: 1,
                    displayResultMode: 1,
                    createdAt: 1,
                    updatedBy: 1,
                    isClosed: 1,
                    votes: 1,
                    votersCount: 1,
                    sharedWithUsersCount: 1
                })
                .populate({
                    path: 'interests', // Populate the interests field
                    select: 'name' // Specify fields to include from the Interest model
                });

            let skipCount = (paginateOptions.page - 1) * paginateOptions.limit;
            if (queryParams?.skip) {
                skipCount = parseInt(queryParams.skip);
            }

            if (paginateOptions.paginate) {
                const count = await query.clone().countDocuments();
                const results = await query.skip(skipCount).limit(paginateOptions.limit).exec();

                // const user = await this.userService.getUserById(userId);
                // const userInterests = (user?.interests || []).map((interest) => interest.name);

                const pollIds = results.map((poll) => poll._id);

                // First, find all the group memberships for the user
                const userGroups = await this.groupMemberModel
                    .find({ userId: userId, isActive: true, isDeleted: false }) // Ensure user is active and not deleted
                    .select('groupId') // Select only the groupId field
                    .exec();

                // Extract the group IDs that the user is a member of
                const userGroupIds = userGroups.map((membership) => membership.groupId);
                const userGroupIdsString = userGroupIds.map((id) => id.toString());

                // Then, find the polls shared with those groups
                const groupSharedPolls = await this.groupPollModel
                    .find({ pollId: { $in: pollIds }, isDeleted: false }) // Filter by pollId and user's groupIds
                    .populate({
                        path: 'groupId',
                        populate: {
                            path: 'groupInterests',
                            select: '_id name'
                        }
                    })
                    .exec();

                // Filter out the groups that are undefined/null and extract the valid group information
                // const groups = groupSharedPolls
                //     .filter((group) => group?.groupId) // Ensure groupId is valid
                //     .map((group) => group.groupId); // Extract the groupId details

                const privatePollIds = [];

                const initialFeed = results.map((res) => {
                    const poll = res.toJSON();

                    if (poll?.visibility === VisibilityTypes.PRIVATE) {
                        privatePollIds.push(poll._id.toString());
                    }

                    if (poll?.isAnonymous) {
                        poll.createdByUsername = '';
                        poll.createdByUserProfilePicUrl = '';
                    }

                    const groupDetails: any = (
                        groupSharedPolls.filter(
                            (groupPoll) => groupPoll?.pollId?.toString() === poll?._id?.toString()
                        ) || []
                    )
                        .map((groupPoll) => groupPoll?.groupId)
                        .filter((group) => group)
                        .map((group: any) => {
                            return {
                                ...group.toObject(),
                                isGroupMember: userGroupIdsString.includes(group?._id?.toString())
                            };
                        })
                        .sort((a, b) => {
                            // Sort by isGroupMember with `true` values first
                            return a.isGroupMember === b.isGroupMember ? 0 : a.isGroupMember ? -1 : 1;
                        });

                    poll['groups'] = groupDetails || [];

                    return poll;
                });

                const polls = await this.pollModel.find({ _id: { $in: pollIds } });

                const pollIdObj: any = {};
                polls.forEach((poll: any) => {
                    pollIdObj[poll._id] = poll;
                });

                // Loop through pollIds and fetch poll responses for each poll
                const pollResponsesObj: any = {}; // Object to store poll responses by pollId
                const pollResponseHistory: any = {};

                // TODO: remove selected options from poll responses --> start
                const allPollResponses: any = {};
                // Using Promise.all to fetch responses concurrently
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponses = await this.pollResponseModel.find({ pollId, userId });
                        allPollResponses[pollId.toString()] = pollResponses; // Store responses for each pollId
                    })
                );
                // TODO: remove selected options from poll responses --> end

                // Using Promise.all to fetch responses concurrently
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponsesCount = await this.pollResponseModel.countDocuments({ pollId, userId });
                        pollResponsesObj[pollId.toString()] = pollResponsesCount; // Store responses for each pollId
                    })
                );

                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                            pollId,
                            userId,
                            isDeleted: false
                        });
                        pollResponseHistory[pollId.toString()] = pollResponseHistoryCount; // Store responses for each pollId
                    })
                );

                const bookmarkedPollObj: any = {};
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const bookmarkedPoll = await this.bookmarkPollModel.findOne({ pollId, bookmarkedBy: userId });
                        bookmarkedPollObj[pollId.toString()] = bookmarkedPoll?._id ? true : false;
                    })
                );

                // loop through each poll and manage responded flag
                for (const poll of initialFeed) {
                    // const pollResponses = pollResponsesObj[poll._id.toString()]; // Poll responses for this pollId
                    poll['isAnswered'] = pollResponsesObj[poll._id.toString()] > 0;
                    poll['isSaved'] = bookmarkedPollObj[poll._id.toString()];
                    // poll['votes'] = pollResponseCountObj[poll._id.toString()];
                    poll['allowChangeMyMind'] = pollResponseHistory[poll._id.toString()] < 2;
                    if (!poll['votes']) {
                        poll['votes'] = 0;
                    }
                    if (!poll['votersCount']) {
                        poll['votersCount'] = 0;
                    }
                    if (!poll['sharedWithUsersCount']) {
                        poll['sharedWithUsersCount'] = 0;
                    }
                    // TODO: remove selected options from poll responses --> start
                    const pollResponses = allPollResponses[poll._id.toString()];
                    if (poll?.questions?.length) {
                        poll.questions = poll.questions.map((question: any) => {
                            const options = question?.options || [];

                            // If poll type is SINGLE_CHOICE or THIS_THAT
                            if (
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.THIS_THAT
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionId = pollResponse?.optionId;

                                // Map options to add isSelected field
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: option.id === optionId
                                }));
                            }

                            // If poll type is MULTIPLE_CHOICE or DATE
                            if (
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const optionIds = pollResponses.map((response) => response?.optionId);

                                // Map options to add isSelected field for multiple choice
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: optionIds.includes(option.id)
                                }));
                            }

                            // If poll type is SLIDER or LIGHT_METER
                            if (
                                question?.type === QuestionTypes.SLIDER ||
                                question?.type === QuestionTypes.LIGHT_METER
                            ) {
                                pollResponses?.length &&
                                    pollResponses[0] &&
                                    (question.sliderValue = pollResponses[0]?.sliderValue || 0);
                            }

                            // If poll type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                question.options = options.map((option) => {
                                    const pollResponse = pollResponses.find(
                                        (response) => response.optionId === option.id
                                    );
                                    return {
                                        ...option,
                                        selectedRank: pollResponse?.order || null
                                    };
                                });
                            }

                            return question;
                        });
                    }
                    poll['commentCount'] = 0;
                    poll['voterImages'] = [
                        'https://www.shutterstock.com/image-photo/image-handsome-smiling-young-african-260nw-722913181.jpg',
                        'https://t4.ftcdn.net/jpg/02/32/98/33/360_F_232983351_z5CAl79bHkm6eMPSoG7FggQfsJLxiZjY.jpg',
                        'https://st2.depositphotos.com/4431055/7492/i/950/depositphotos_74925449-stock-photo-men-human-face-smiling.jpg'
                    ];
                    // TODO: remove selected options from poll responses --> end
                }

                const pollResponsesPromises = initialFeed.map(async (poll) => {
                    if (poll?.interests) {
                        poll.interests = (poll.interests || []).map((interest: any) => interest.name);
                    }
                    return poll; // Return poll with added voterImages
                });

                // Wait for all the promises to resolve
                const pollsWithVoterImages = await Promise.all(pollResponsesPromises);
                return {
                    docs: pollsWithVoterImages,
                    page: paginateOptions.page,
                    limit: paginateOptions.limit,
                    totalPages: Math.ceil(count / paginateOptions.limit),
                    totalResults: count
                };
            } else {
                query.exec();
            }
        } catch (err) {
            throw new RpcException(err);
        }
    }

    async prepareUserFeed(userId) {
        try {
            // isActive, isDeleted, sort by latest created first
            // step 1: get polls share with user
            // step 2: get polls which are shared with public or private groups where user is member of those group
            // step 3: get public polls which are of same interest of user
            // setp 4: get public polls which are created by following users
            // step 5: distinct array of step 1 to 4
            // step 6: polls which are not part of above steps and user has not responded yet
            // step 7: distinct array

            // if poll creaetd within last 5 mins then display first
            const now = new Date();
            const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);

            const recentPolls = await this.pollModel
                .find({ createdAt: { $gte: fiveMinutesAgo }, createdByUserId: userId, isDeleted: false }) // Filters for polls created in the last 10 mins
                .sort({ createdAt: -1 }) // Sorts by creation time, latest first
                .limit(1)
                .exec();

            const recentPollIds = recentPolls.map((poll) => poll._id.toString());

            // 1. check for shared poll
            const sharedPolls = await this.sharedPollWithUsersModel
                .find({ sharedWith: userId, pollId: { $nin: [...recentPollIds] }, isDeleted: false })
                .sort({ createdAt: -1 });
            const sharedPollIds = sharedPolls.map((poll) => poll.pollId.toString());

            // 2. check for group polls and not shared with user
            const groupMembers = await this.groupMemberModel.aggregate([
                {
                    $match: {
                        userId: mongoose.Types.ObjectId.createFromHexString(userId) // specify the userId here
                    }
                },
                {
                    $sort: { createdAt: -1 } // Sort by `createdAt` in descending order
                },
                {
                    $group: {
                        _id: '$groupId', // Group by `groupId`
                        latestEntry: { $first: '$$ROOT' } // Select the latest document for each `groupId`
                    }
                },
                {
                    $match: {
                        'latestEntry.isActive': true,
                        'latestEntry.isDeleted': false
                    }
                },
                {
                    $replaceRoot: { newRoot: '$latestEntry' } // Replace root to keep only the document data
                }
            ]);

            const groupIds = groupMembers.map((group) => group?.groupId?.toString());
            const groupPolls = await this.groupPollModel
                .find({
                    groupId: { $in: groupIds },
                    pollId: { $nin: [...recentPollIds, ...sharedPollIds] },
                    isDeleted: false
                })
                .sort({ createdAt: -1 });
            const groupPollIds = groupPolls.map((poll) => poll.pollId.toString());

            // console.log({ groupPollIds });

            // 3. check for public polls with same interest and not part of shared and group polls
            // get user
            const user = await this.userService.getUserById(userId);
            const userInterests = (user?.interests || []).map((interest) =>
                mongoose.Types.ObjectId.createFromHexString((interest?.id || '').toString())
            );

            // 4. loop through all polls and check that user has interest in poll
            const polls = await this.pollModel
                .find({
                    visibility: VisibilityTypes.PUBLIC,
                    _id: { $nin: [...recentPollIds, ...sharedPollIds, ...groupPollIds] },
                    interests: { $in: userInterests },
                    isActive: true,
                    isDeleted: false
                })
                .sort({ createdAt: -1 });

            const userInterestsPollIds = polls.map((poll) => poll._id.toString());
            // console.log({ userInterestsPollIds });

            // 5. get polls created by following users
            // get following users
            const followingUsers = await this.followRequestModel.find({
                senderId: userId,
                status: FollowRequestStatus.ACCEPTED,
                isDeleted: false
            });
            const followingUsersIds = followingUsers.map((user) => user.receiverId.toString());
            const followingUsersPolls = await this.pollModel
                .find({
                    createdByUserId: { $in: followingUsersIds },
                    _id: { $nin: [...recentPollIds, ...userInterestsPollIds, ...sharedPollIds, ...groupPollIds] },
                    isActive: true,
                    isDeleted: false,
                    visibility: VisibilityTypes.PUBLIC
                })
                .sort({ createdAt: -1 });
            const followingUsersPollIds = followingUsersPolls.map((poll) => poll._id.toString());
            // console.log({ followingUsersPollIds });

            // 5. distinct array of step 1 to 4
            const allPollIds = [
                ...recentPollIds,
                ...sharedPollIds,
                ...groupPollIds,
                ...userInterestsPollIds,
                ...followingUsersPollIds
            ];

            console.log({ allPollIds });

            // 6. get polls which are not part of above steps and user has not responded yet
            const userPollResponses = await this.pollResponseModel.find({ userId });
            const userPollResponsePollIds = userPollResponses.map((poll) => poll.pollId.toString());

            let limit = 100;

            const uniquePollIds = [...allPollIds, ...userPollResponsePollIds];

            if (uniquePollIds?.length < 100) {
                limit = 1900;
            } else if (uniquePollIds?.length < 500) {
                limit = 1500;
            } else if (uniquePollIds?.length < 750) {
                limit = 1250;
            } else if (uniquePollIds?.length < 999) {
                limit = 1100;
            } else {
                limit = 50;
            }

            const nonRespondedPolls = await this.pollModel
                .find({
                    _id: { $nin: [...allPollIds, ...userPollResponsePollIds] },
                    visibility: VisibilityTypes.PUBLIC,
                    isActive: true,
                    isDeleted: false
                })
                .sort({ createdAt: -1 })
                .limit(limit);

            // 7. distinct array
            const nonRespondedPollIds = nonRespondedPolls.map((poll) => poll._id.toString());
            const nonRespondedPollIdsSet = new Set();
            nonRespondedPollIds.forEach((pollId) => nonRespondedPollIdsSet.add(pollId));
            const nonRespondedPollIdsArray = Array.from(nonRespondedPollIdsSet);
            // console.log({ nonRespondedPollIdsArray });

            // Combine both arrays in the desired order
            const combinedPollIds = [...allPollIds, ...nonRespondedPollIdsArray];
            console.log({ combinedPollIds });

            // Use a Set to track unique IDs while maintaining insertion order
            const seenPollIds = new Set();
            const orderedUniquePollIds = [];

            combinedPollIds.forEach((pollId) => {
                if (!seenPollIds.has(pollId)) {
                    seenPollIds.add(pollId); // Mark as seen
                    orderedUniquePollIds.push(pollId); // Add to result in order
                }
            });

            // Convert each unique poll ID to ObjectId format in preserved order
            const uniquePollObjectIds = orderedUniquePollIds.map((pollId) =>
                mongoose.Types.ObjectId.createFromHexString(pollId)
            );

            console.log({ uniquePollObjectIds });

            const uniquePolls = await this.pollModel.aggregate([
                // TODO: add poll status published
                { $match: { _id: { $in: uniquePollObjectIds }, isDeleted: false, isActive: true } },
                {
                    $addFields: {
                        customOrder: { $indexOfArray: [uniquePollObjectIds, '$_id'] }
                    }
                },
                { $sort: { customOrder: 1 } },
                {
                    $project: {
                        visibility: 1,
                        endDate: 1,
                        isClosed: 1
                    }
                }
            ]);

            const cacheObj = {
                data: orderedUniquePollIds,
                createdAt: new Date().toISOString(),
                polls: uniquePolls
            };

            this.setFeedCache(userId, cacheObj);
            return orderedUniquePollIds;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    // function to get voters profile pic urls if profile pic exists and not anonymous
    async getPollVotersProfilePicUrls(pollId) {
        try {
            const pollResponses = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId // First, filter by pollId
                    }
                },
                {
                    $sort: { createdAt: -1 } // Sort responses by creation date in descending order
                },
                {
                    $limit: 1000 // Limit the result to the last 1000 responses
                },
                {
                    $lookup: {
                        from: 'users', // Join with the 'users' collection
                        localField: 'userId',
                        foreignField: '_id',
                        as: 'user'
                    }
                },
                {
                    $unwind: '$user' // Unwind the user data
                },
                {
                    $match: {
                        'user.profilePicUrl': { $exists: true, $ne: '' } // Ensure profilePicUrl exists and is not empty
                    }
                },
                {
                    $group: {
                        _id: { pollId: '$pollId', userId: '$userId' }, // Group by pollId and userId
                        responses: { $push: '$$ROOT' }, // Push entire document into an array
                        profilePicUrl: { $first: '$user.profilePicUrl' } // Keep the profilePicUrl from the first (latest) response
                    }
                },
                {
                    $project: {
                        pollId: '$_id.pollId',
                        userId: '$_id.userId',
                        responses: { $slice: ['$responses', 3] }, // Limit to the last 3 responses
                        profilePicUrl: 1 // Include the profilePicUrl field
                    }
                }
            ]);

            return pollResponses.map((response) => response.profilePicUrl);
        } catch (err) {
            throw new RpcException(err);
        }
    }
}
