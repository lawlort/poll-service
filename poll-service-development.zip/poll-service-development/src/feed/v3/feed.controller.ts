import { Controller, Body } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_FEED_V3 } from 'src/utils/constants/commands';
import { FeedServiceV3 } from './feed.service';

@Controller('feed')
export class FeedControllerV3 {
    constructor(private readonly feedService: FeedServiceV3) {}

    @MessagePattern({ cmd: CMD_GET_FEED_V3 })
    async create(@Body() payload) {
        const { userId, paginateOptions, query = {} } = payload;
        return await this.feedService.findAllV3(userId, paginateOptions, query);
    }
}
