import { Controller, Body } from '@nestjs/common';
import { FeedService } from './feed.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_FEED } from 'src/utils/constants/commands';

@Controller('feed')
export class FeedController {
    constructor(private readonly feedService: FeedService) {}

    @MessagePattern({ cmd: CMD_GET_FEED })
    async create(@Body() payload) {
        const { userId, paginateOptions, query = {} } = payload;
        return await this.feedService.findAll(userId, paginateOptions, query);
    }
}
