import { Module, forwardRef } from '@nestjs/common';
import { FeedService } from './feed.service';
import { FeedController } from './feed.controller';
import { MongooseModule } from '@nestjs/mongoose';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';
import { UsersModule } from 'src/users/users.module';
import PollViewSchema, { PollView } from 'src/poll-views/schemas/poll-view.schema';
import PollResponseSchema, { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
import PollCommentSchema, { PollComment } from 'src/poll-comments/schemas/poll-comment.schema';
import BookmarkedPollSchema, { BookmarkedPoll } from 'src/bookmarked-polls/schemas/bookmarked-poll.schema';
import { FeedControllerV2 } from './v2/feed.controller';
import { FeedServiceV2 } from './v2/feed.service';
import PollResponseHistorySchema, {
    PollResponseHistory
} from 'src/poll-response-history/schemas/poll-response-history.schema';
import GroupMemberSchema, { GroupMember } from 'src/group-members/schemas/group-members.schema';
import GroupPollSchema, { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import SharedPollSchema, { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import FollowRequestSchema, { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';
import { FeedControllerV3 } from './v3/feed.controller';
import { FeedServiceV3 } from './v3/feed.service';
import SharedPollWithUsersSchema, {
    SharedPollWithUsers
} from 'src/shared-poll-with-users/schemas/shared-poll-with-users.schema';
import { FeedControllerV4 } from './v4/feed.controller';
import { FeedServiceV4 } from './v4/feed.service';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: Poll.name, schema: PollSchema },
            { name: PollView.name, schema: PollViewSchema },
            { name: PollResponse.name, schema: PollResponseSchema },
            { name: PollComment.name, schema: PollCommentSchema },
            { name: BookmarkedPoll.name, schema: BookmarkedPollSchema },
            { name: PollResponseHistory.name, schema: PollResponseHistorySchema },
            { name: GroupMember.name, schema: GroupMemberSchema },
            { name: GroupPoll.name, schema: GroupPollSchema },
            { name: SharedPoll.name, schema: SharedPollSchema },
            { name: FollowRequest.name, schema: FollowRequestSchema },
            { name: SharedPollWithUsers.name, schema: SharedPollWithUsersSchema }
        ]),
        forwardRef(() => UsersModule)
    ],
    controllers: [FeedController, FeedControllerV2, FeedControllerV3, FeedControllerV4],
    providers: [FeedService, FeedServiceV2, FeedServiceV3, FeedServiceV4],
    exports: [FeedServiceV3, FeedServiceV4]
})
export class FeedModule {}
