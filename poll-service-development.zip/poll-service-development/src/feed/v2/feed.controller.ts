import { Controller, Body } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_FEED_V2 } from 'src/utils/constants/commands';
import { FeedServiceV2 } from './feed.service';

@Controller('feed')
export class FeedControllerV2 {
    constructor(private readonly feedService: FeedServiceV2) {}

    @MessagePattern({ cmd: CMD_GET_FEED_V2 })
    async create(@Body() payload) {
        const { userId, paginateOptions, query = {} } = payload;
        return await this.feedService.findAllV2(userId, paginateOptions, query);
    }
}
