import { Controller, Body } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_FEED_V4 } from 'src/utils/constants/commands';
import { FeedServiceV4 } from './feed.service';

@Controller('feed')
export class FeedControllerV4 {
    constructor(private readonly feedService: FeedServiceV4) {}

    @MessagePattern({ cmd: CMD_GET_FEED_V4 })
    async create(@Body() payload) {
        const { userId, paginateOptions, query = {} } = payload;
        return await this.feedService.findAllV4(userId, paginateOptions, query);
    }
}
