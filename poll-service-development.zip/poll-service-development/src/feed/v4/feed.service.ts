import { Inject, Injectable, forwardRef } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model } from 'mongoose';
// import { share } from 'rxjs';
import { BookmarkedPoll } from 'src/bookmarked-polls/schemas/bookmarked-poll.schema';
import { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';
import { GroupMember } from 'src/group-members/schemas/group-members.schema';
import { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
// import { PollComment } from 'src/poll-comments/schemas/poll-comment.schema';
import { PollResponseHistory } from 'src/poll-response-history/schemas/poll-response-history.schema';
import { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
// import { PollView } from 'src/poll-views/schemas/poll-view.schema';
import { Poll, QuestionTypes, VisibilityTypes } from 'src/polls/schemas/poll.schema';
import { RedisService } from 'src/redis/redis.service';
import { SharedPollWithUsers } from 'src/shared-poll-with-users/schemas/shared-poll-with-users.schema';
import { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
// import { User } from 'src/users/schemas/user.schema';
import { UsersService } from 'src/users/users.service';
import { FollowRequestStatus, TRUE_STRING } from 'src/utils/constants/string';
// import { UsersService } from 'src/users/users.service';

@Injectable()
export class FeedServiceV4 {
    constructor(
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        // @InjectModel(PollView.name) private pollViewModel: Model<PollView>,
        @InjectModel(PollResponse.name) private pollResponseModel: Model<PollResponse>,
        // @InjectModel(PollComment.name) private pollCommentModel: Model<PollComment>,
        @InjectModel(BookmarkedPoll.name) private bookmarkPollModel: Model<BookmarkedPoll>,
        @InjectModel(PollResponseHistory.name) private pollResponseHistoryModel: Model<PollResponseHistory>,
        @InjectModel(GroupMember.name) private groupMemberModel: Model<GroupMember>,
        @InjectModel(GroupPoll.name) private groupPollModel: Model<GroupPoll>,
        @InjectModel(SharedPoll.name) private sharedPollModel: Model<SharedPoll>,
        @InjectModel(SharedPollWithUsers.name) private sharedPollWithUsersModel: Model<SharedPollWithUsers>,
        @InjectModel(FollowRequest.name) private followRequestModel: Model<FollowRequest>,
        @Inject(forwardRef(() => UsersService)) private userService: UsersService,
        private redisService: RedisService
    ) {}

    setFeedCache(userId, feedIds) {
        this.redisService.setWithExpiry(`${userId}:feed`, feedIds, 60 * 10);
    }

    async findAllV4(userId, paginateOptions, queryParams) {
        try {
            paginateOptions['paginate'] = true;
            const feedIds: any = await this.redisService.get(`${userId}:feed`);
            let pollIds = [];
            let feedPolls = [];
            if (feedIds) {
                const feedCache = JSON.parse(feedIds);
                const { data = [], createdAt = '', polls = [] } = feedCache;
                pollIds = data;
                feedPolls = polls;

                const cacheAgeInMilliseconds = new Date().getTime() - new Date(createdAt).getTime();
                const cacheAgeInMinutes = cacheAgeInMilliseconds / (1000 * 60);
                if (cacheAgeInMinutes > 5) {
                    this.prepareUserFeed(userId);
                }
                console.log('from cache');
            } else if (!feedIds) {
                console.log('prepare feed -----------------');
                const { uniquePollIdsArray = [], polls = [] } = await this.prepareUserFeed(userId);

                pollIds = uniquePollIdsArray;
                feedPolls = polls;
            }
            console.log('from cache');
            console.log(pollIds);

            const currentDate = new Date();

            // show live polls only
            if (queryParams.liveOnly === TRUE_STRING) {
                feedPolls = feedPolls.filter((poll) => {
                    const endDate = typeof poll.endDate === 'string' ? new Date(poll.endDate) : poll.endDate;
                    return endDate > currentDate;
                });
                // feedPolls = feedPolls.filter((poll) => poll.isClosed === false);
            }

            // if only private polls are requested
            if (queryParams.privateOnly === TRUE_STRING) {
                feedPolls = feedPolls.filter((poll) => poll.visibility === VisibilityTypes.PRIVATE);
            }

            let skipCount = (paginateOptions.page - 1) * paginateOptions.limit;
            if (queryParams?.skip) {
                skipCount = parseInt(queryParams.skip);
            }
            if (queryParams?.lastPollId) {
                const lastPollIndex = feedPolls.findIndex((poll) => poll._id.toString() === queryParams.lastPollId);
                if (lastPollIndex !== -1) {
                    // Get the next 10 polls after `lastPollId`
                    feedPolls = feedPolls.slice(lastPollIndex + 1);
                } else {
                    feedPolls = feedPolls.slice(skipCount);
                }
            } else {
                feedPolls = feedPolls.slice(skipCount);
            }

            const count = feedPolls.length;

            feedPolls = feedPolls.slice(0, paginateOptions.limit);
            // console.log('after', feedPolls);

            const feedPollIds = feedPolls.map((poll) => {
                if (mongoose.Types.ObjectId.isValid(poll._id) && poll._id instanceof mongoose.Types.ObjectId) {
                    return poll._id;
                }
                return mongoose.Types.ObjectId.createFromHexString(poll._id);
            });

            if (paginateOptions.paginate) {
                // const count = await query.clone().countDocuments();
                // const results = await query.skip(skipCount).limit(paginateOptions.limit).exec();

                const results = await this.pollModel.aggregate([
                    // TODO: add poll status published
                    { $match: { _id: { $in: feedPollIds } } },
                    {
                        $addFields: {
                            customOrder: { $indexOfArray: [feedPollIds, '$_id'] }
                        }
                    },
                    { $sort: { customOrder: 1 } },
                    {
                        // Lookup to populate `interests` field
                        $lookup: {
                            from: 'interests', // Target collection name
                            localField: 'interests', // Field in poll collection
                            foreignField: '_id', // Field in interests collection
                            as: 'interests' // Name for the populated array
                        }
                    },
                    {
                        $project: {
                            visibility: 1,
                            isAnonymous: 1,
                            bgImageUrl: 1,
                            convertedMediaUrl: 1,
                            thumbnailUrl: 1,
                            mediaType: 1,
                            endDate: 1,
                            status: 1,
                            createdByUsername: 1,
                            createdByUserId: 1,
                            createdByUserProfilePicUrl: 1,
                            interests: 1,
                            questions: 1,
                            displayResultMode: 1,
                            createdAt: 1,
                            updatedBy: 1,
                            isClosed: 1,
                            votes: 1,
                            votersCount: 1,
                            sharedWithUsersCount: 1,
                            allowComments: 1,
                            isPromoted: 1
                        }
                    }
                ]);

                const pollIds = results.map((poll) => poll._id);

                // First, find all the group memberships for the user
                const userGroups = await this.groupMemberModel
                    .find({ userId: userId, isActive: true, isDeleted: false }) // Ensure user is active and not deleted
                    .select('groupId') // Select only the groupId field
                    .exec();

                // Extract the group IDs that the user is a member of
                const userGroupIds = userGroups.map((membership) => membership.groupId);
                const userGroupIdsString = userGroupIds.map((id) => id.toString());

                // Then, find the polls shared with those groups
                const groupSharedPolls = await this.groupPollModel
                    .find({ pollId: { $in: pollIds }, isDeleted: false }) // Filter by pollId and user's groupIds
                    .populate({
                        path: 'groupId',
                        populate: {
                            path: 'groupInterests',
                            select: '_id name'
                        }
                    })
                    .exec();

                const privatePollIds = [];

                const initialFeed = results.map((res) => {
                    const poll = res;

                    if (poll?.visibility === VisibilityTypes.PRIVATE) {
                        privatePollIds.push(poll._id.toString());
                    }

                    if (poll?.isAnonymous) {
                        poll.createdByUsername = '';
                        poll.createdByUserProfilePicUrl = '';
                    }

                    const groupDetails: any = (
                        groupSharedPolls.filter(
                            (groupPoll) => groupPoll?.pollId?.toString() === poll?._id?.toString()
                        ) || []
                    )
                        .map((groupPoll) => groupPoll?.groupId)
                        .filter((group) => group)
                        .map((group: any) => {
                            return {
                                ...group.toObject(),
                                isGroupMember: userGroupIdsString.includes(group?._id?.toString()),
                                id: group?._id
                            };
                        })
                        .sort((a, b) => {
                            // Sort by isGroupMember with `true` values first
                            return a.isGroupMember === b.isGroupMember ? 0 : a.isGroupMember ? -1 : 1;
                        });

                    poll['groups'] = groupDetails || [];

                    return poll;
                });

                console.log({ privatePollIds });

                const polls = await this.pollModel.find({ _id: { $in: pollIds } });

                const pollIdObj: any = {};
                polls.forEach((poll: any) => {
                    pollIdObj[poll._id] = poll;
                });

                // Loop through pollIds and fetch poll responses for each poll
                const pollResponsesObj: any = {}; // Object to store poll responses by pollId
                const pollResponseHistory: any = {};

                // TODO: remove selected options from poll responses --> start
                const allPollResponses: any = {};
                // Using Promise.all to fetch responses concurrently
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponses = await this.pollResponseModel.find({ pollId, userId });
                        allPollResponses[pollId.toString()] = pollResponses; // Store responses for each pollId
                    })
                );
                // TODO: remove selected options from poll responses --> end

                // Using Promise.all to fetch responses concurrently
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponsesCount = await this.pollResponseModel.countDocuments({ pollId, userId });
                        pollResponsesObj[pollId.toString()] = pollResponsesCount; // Store responses for each pollId
                    })
                );

                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                            pollId,
                            userId,
                            isDeleted: false
                        });
                        pollResponseHistory[pollId.toString()] = pollResponseHistoryCount; // Store responses for each pollId
                    })
                );

                const bookmarkedPollObj: any = {};
                await Promise.all(
                    pollIds.map(async (pollId) => {
                        const bookmarkedPoll = await this.bookmarkPollModel.findOne({ pollId, bookmarkedBy: userId });
                        bookmarkedPollObj[pollId.toString()] = bookmarkedPoll?._id ? true : false;
                    })
                );

                // loop through each poll and manage responded flag
                for (const poll of initialFeed) {
                    // const pollResponses = pollResponsesObj[poll._id.toString()]; // Poll responses for this pollId
                    poll['id'] = poll?._id;
                    poll['isAnswered'] = pollResponsesObj[poll._id.toString()] > 0;
                    poll['isSaved'] = bookmarkedPollObj[poll._id.toString()];
                    // poll['votes'] = pollResponseCountObj[poll._id.toString()];
                    poll['allowChangeMyMind'] = pollResponseHistory[poll._id.toString()] < 2;
                    if (!poll['votes']) {
                        poll['votes'] = 0;
                    }
                    if (!poll['votersCount']) {
                        poll['votersCount'] = 0;
                    }
                    if (!poll['sharedWithUsersCount']) {
                        poll['sharedWithUsersCount'] = 0;
                    }
                    // TODO: remove selected options from poll responses --> start
                    const pollResponses = allPollResponses[poll._id.toString()];
                    if (poll?.questions?.length) {
                        poll.questions = poll.questions.map((question: any) => {
                            const options = question?.options || [];

                            // If poll type is SINGLE_CHOICE or THIS_THAT
                            if (
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.THIS_THAT
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionId = pollResponse?.optionId;

                                // Map options to add isSelected field
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: option.id === optionId
                                }));
                            }

                            // If poll type is MULTIPLE_CHOICE or DATE
                            if (
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const optionIds = pollResponses.map((response) => response?.optionId);

                                // Map options to add isSelected field for multiple choice
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: optionIds.includes(option.id)
                                }));
                            }

                            // If poll type is SLIDER or LIGHT_METER
                            if (
                                question?.type === QuestionTypes.SLIDER ||
                                question?.type === QuestionTypes.LIGHT_METER
                            ) {
                                pollResponses?.length &&
                                    pollResponses[0] &&
                                    (question.sliderValue = pollResponses[0]?.sliderValue || 0);
                            }

                            // If poll type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                question.options = options.map((option) => {
                                    const pollResponse = pollResponses.find(
                                        (response) => response.optionId === option.id
                                    );
                                    return {
                                        ...option,
                                        selectedRank: pollResponse?.order || null
                                    };
                                });
                            }

                            return question;
                        });
                    }
                    poll['commentCount'] = 0;
                    // poll['voterImages'] = [
                    //     'https://www.shutterstock.com/image-photo/image-handsome-smiling-young-african-260nw-722913181.jpg',
                    //     'https://t4.ftcdn.net/jpg/02/32/98/33/360_F_232983351_z5CAl79bHkm6eMPSoG7FggQfsJLxiZjY.jpg',
                    //     'https://st2.depositphotos.com/4431055/7492/i/950/depositphotos_74925449-stock-photo-men-human-face-smiling.jpg'
                    // ];
                    // TODO: remove selected options from poll responses --> end
                }

                const currentUser = await this.userService.getUserById(userId);
                const userInterests = currentUser?.interests || [];
                const userInterestNames = userInterests.map((interest: any) => interest.name); // Get user interest names

                const pollResponsesPromises = initialFeed.map(async (poll) => {
                    poll['interests'] = (poll['interests'] || [])
                        .map((interest) => {
                            return {
                                id: interest._id,
                                name: interest.name,
                                isUserInterest: userInterestNames.includes(interest.name)
                            };
                        })
                        .sort((a, b) => {
                            // Sort by isGroupMember with `true` values first
                            return a.isUserInterest === b.isUserInterest ? 0 : a.isUserInterest ? -1 : 1;
                        });
                    return poll;
                });

                // Wait for all the promises to resolve
                const pollsWithVoterImages = await Promise.all(pollResponsesPromises);
                return {
                    docs: pollsWithVoterImages,
                    page: paginateOptions.page,
                    limit: paginateOptions.limit,
                    totalPages: Math.ceil(count / paginateOptions.limit),
                    totalResults: count
                };
            } else {
                // query.exec();
                return [];
            }
        } catch (err) {
            console.log(err);
            throw new RpcException(err);
        }
    }

    async prepareUserFeed(userId) {
        try {
            // isActive, isDeleted, sort by latest created first
            // step 1: get polls share with user
            // step 2: get polls which are shared with public or private groups where user is member of those group
            // step 3: get public polls which are of same interest of user
            // setp 4: get public polls which are created by following users
            // step 5: distinct array of step 1 to 4
            // step 6: polls which are not part of above steps and user has not responded yet
            // step 7: distinct array

            // if poll creaetd within last 5 mins then display first
            const now = new Date();
            const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);

            const recentPolls = await this.pollModel
                .find({ createdAt: { $gte: fiveMinutesAgo }, createdByUserId: userId, isDeleted: false }) // Filters for polls created in the last 10 mins
                .sort({ createdAt: -1 }) // Sorts by creation time, latest first
                .limit(1)
                .exec();

            const recentPollIds = recentPolls.map((poll) => poll._id.toString());

            // 1. check for shared poll
            const sharedPolls = await this.sharedPollWithUsersModel
                .find({ sharedWith: userId, pollId: { $nin: [...recentPollIds] }, isDeleted: false })
                .sort({ createdAt: -1 });
            const sharedPollIds = sharedPolls.map((poll) => poll.pollId.toString());

            // 2. check for group polls and not shared with user
            const groupMembers = await this.groupMemberModel.aggregate([
                {
                    $match: {
                        userId: mongoose.Types.ObjectId.createFromHexString(userId) // specify the userId here
                    }
                },
                {
                    $sort: { createdAt: -1 } // Sort by `createdAt` in descending order
                },
                {
                    $group: {
                        _id: '$groupId', // Group by `groupId`
                        latestEntry: { $first: '$$ROOT' } // Select the latest document for each `groupId`
                    }
                },
                {
                    $match: {
                        'latestEntry.isActive': true,
                        'latestEntry.isDeleted': false
                    }
                },
                {
                    $replaceRoot: { newRoot: '$latestEntry' } // Replace root to keep only the document data
                }
            ]);

            const groupIds = groupMembers.map((group) => group?.groupId?.toString());
            const groupPolls = await this.groupPollModel
                .find({
                    groupId: { $in: groupIds },
                    pollId: { $nin: [...recentPollIds, ...sharedPollIds] },
                    isDeleted: false
                })
                .sort({ createdAt: -1 });
            const groupPollIds = groupPolls.map((poll) => poll.pollId.toString());

            // console.log({ groupPollIds });

            // 3. check for public polls with same interest and not part of shared and group polls
            // get user
            const user = await this.userService.getUserById(userId);
            const userInterests = (user?.interests || []).map((interest) =>
                mongoose.Types.ObjectId.createFromHexString((interest?.id || '').toString())
            );

            // 4. loop through all polls and check that user has interest in poll
            const polls = await this.pollModel
                .find({
                    visibility: VisibilityTypes.PUBLIC,
                    _id: { $nin: [...recentPollIds, ...sharedPollIds, ...groupPollIds] },
                    interests: { $in: userInterests },
                    isActive: true,
                    isDeleted: false
                })
                .sort({ createdAt: -1 });

            const userInterestsPollIds = polls.map((poll) => poll._id.toString());
            // console.log({ userInterestsPollIds });

            // 5. get polls created by following users
            // get following users
            const followingUsers = await this.followRequestModel.find({
                senderId: userId,
                status: FollowRequestStatus.ACCEPTED,
                isDeleted: false
            });
            const followingUsersIds = followingUsers.map((user) => user.receiverId.toString());
            const followingUsersPolls = await this.pollModel
                .find({
                    createdByUserId: { $in: followingUsersIds },
                    _id: { $nin: [...recentPollIds, ...userInterestsPollIds, ...sharedPollIds, ...groupPollIds] },
                    isActive: true,
                    isDeleted: false,
                    visibility: VisibilityTypes.PUBLIC
                })
                .sort({ createdAt: -1 });
            const followingUsersPollIds = followingUsersPolls.map((poll) => poll._id.toString());
            // console.log({ followingUsersPollIds });

            // 5. distinct array of step 1 to 4
            const allPollIds = [
                ...recentPollIds,
                ...sharedPollIds,
                ...groupPollIds,
                ...userInterestsPollIds,
                ...followingUsersPollIds
            ];

            console.log({ allPollIds });

            // 6. get polls which are not part of above steps and user has not responded yet
            const userPollResponses = await this.pollResponseModel.find({ userId });
            const userPollResponsePollIds = userPollResponses.map((poll) => poll.pollId.toString());

            let limit = 100;

            const uniquePollIds = [...allPollIds, ...userPollResponsePollIds];

            if (uniquePollIds?.length < 100) {
                limit = 1900;
            } else if (uniquePollIds?.length < 500) {
                limit = 1500;
            } else if (uniquePollIds?.length < 750) {
                limit = 1250;
            } else if (uniquePollIds?.length < 999) {
                limit = 1100;
            } else {
                limit = 50;
            }

            const nonRespondedPolls = await this.pollModel
                .find({
                    _id: { $nin: [...allPollIds, ...userPollResponsePollIds] },
                    visibility: VisibilityTypes.PUBLIC,
                    isActive: true,
                    isDeleted: false
                })
                .sort({ createdAt: -1 })
                .limit(limit);

            // 7. distinct array
            const nonRespondedPollIds = nonRespondedPolls.map((poll) => poll._id.toString());
            const nonRespondedPollIdsSet = new Set();
            nonRespondedPollIds.forEach((pollId) => nonRespondedPollIdsSet.add(pollId));
            const nonRespondedPollIdsArray = Array.from(nonRespondedPollIdsSet);
            // console.log({ nonRespondedPollIdsArray });

            // Combine both arrays in the desired order
            const combinedPollIds = [...allPollIds, ...nonRespondedPollIdsArray];
            console.log({ combinedPollIds });

            // Use a Set to track unique IDs while maintaining insertion order
            const seenPollIds = new Set();
            const orderedUniquePollIds = [];

            combinedPollIds.forEach((pollId) => {
                if (!seenPollIds.has(pollId)) {
                    seenPollIds.add(pollId); // Mark as seen
                    orderedUniquePollIds.push(pollId); // Add to result in order
                }
            });

            // Convert each unique poll ID to ObjectId format in preserved order
            const uniquePollObjectIds = orderedUniquePollIds.map((pollId) =>
                mongoose.Types.ObjectId.createFromHexString(pollId)
            );

            console.log({ uniquePollObjectIds });

            const uniquePolls = await this.pollModel.aggregate([
                // TODO: add poll status published
                { $match: { _id: { $in: uniquePollObjectIds }, isDeleted: false, isActive: true } },
                {
                    $addFields: {
                        customOrder: { $indexOfArray: [uniquePollObjectIds, '$_id'] }
                    }
                },
                { $sort: { customOrder: 1 } },
                {
                    $project: {
                        visibility: 1,
                        endDate: 1,
                        isClosed: 1
                    }
                }
            ]);

            const cacheObj = {
                data: orderedUniquePollIds,
                createdAt: new Date().toISOString(),
                polls: uniquePolls
            };

            this.setFeedCache(userId, cacheObj);
            return { uniquePollIdsArray: orderedUniquePollIds, polls: uniquePolls };
        } catch (error) {
            console.log('error', error);
            throw new RpcException(error);
        }
    }
}
