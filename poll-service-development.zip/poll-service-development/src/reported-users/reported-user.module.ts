import { Module } from '@nestjs/common';
import { ReportedUsersService } from './reported-user.service';
import { ReportedUsersController } from './reported-user.controller';
import { MongooseModule } from '@nestjs/mongoose';
import ReportedUserSchema, { ReportedUser } from './schemas/reported-user.schema';
import UserSchema, { User } from 'src/users/schemas/user.schema';
import { UsersModule } from 'src/users/users.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: ReportedUser.name, schema: ReportedUserSchema },
            { name: User.name, schema: UserSchema }
        ]),
        UsersModule
    ],
    controllers: [ReportedUsersController],
    providers: [ReportedUsersService]
})
export class ReportedUsersModule {}
