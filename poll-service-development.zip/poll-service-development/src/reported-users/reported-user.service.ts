import { Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ReportedUser } from './schemas/reported-user.schema';
import { User } from 'src/users/schemas/user.schema';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreateReportedUserJoiSchema } from './dto/CreateReportedUserSchema';
import { UsersService } from 'src/users/users.service';

@Injectable()
export class ReportedUsersService {
    constructor(
        @InjectModel(ReportedUser.name) private reportedUserModel: Model<ReportedUser>,
        @InjectModel(User.name) private userModel: Model<User>,
        private userService: UsersService
    ) {}

    async create(createReportedUserDto, userId, reportedUserId) {
        try {
            const payload = {
                ...createReportedUserDto,
                reportedBy: userId,
                userId: reportedUserId
            };
            validateSchema(CreateReportedUserJoiSchema, payload);

            if (userId === reportedUserId) {
                throw new UnprocessableEntityException('You cannot report yourself');
            }

            // Check if the reported user exists
            const user = await this.userService.getUserById(reportedUserId);

            if (!user?.id) {
                throw new NotFoundException('User not found');
            }

            // Check if the user has already reported the same user
            const existingReport = await this.reportedUserModel.findOne({
                userId: reportedUserId,
                reportedBy: userId
            });

            if (existingReport?._id) {
                throw new UnprocessableEntityException('You have already reported this user');
            }

            // Create a new reported user entry
            await this.reportedUserModel.create(payload);

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
