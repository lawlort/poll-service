import { Controller, Body } from '@nestjs/common';
import { ReportedUsersService } from './reported-user.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_REPORT_USER } from 'src/utils/constants/commands';

@Controller()
export class ReportedUsersController {
    constructor(private readonly reportedUsersService: ReportedUsersService) {}

    @MessagePattern({ cmd: CMD_REPORT_USER })
    async create(@Body() payload) {
        const { body = {}, userId, id } = payload;
        return await this.reportedUsersService.create(body, userId, id);
    }
}
