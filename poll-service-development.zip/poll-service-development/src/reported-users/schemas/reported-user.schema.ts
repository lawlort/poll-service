import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'reported_users', versionKey: false })
export class ReportedUser {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    reportedBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    userId: string;

    @Prop({ type: String, required: true })
    reason: string;

    @Prop({ type: Date, default: Date.now })
    reportedAt: Date;
}

export const ReportedUserSchema = SchemaFactory.createForClass(ReportedUser);

// Indexes to ensure uniqueness and optimize queries
ReportedUserSchema.index({ reportedBy: 1, userId: 1, commentId: 1 }, { unique: true });
ReportedUserSchema.index({ userId: 1 });
ReportedUserSchema.index({ reportedBy: 1 });
ReportedUserSchema.index({ reportedAt: 1 });

export type ReportedUserDocument = HydratedDocument<ReportedUser>;

export default ReportedUserSchema;
