import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { UserInsightsService } from './user-insights.service';
import { CreateUserInsightDto } from './dto/create-user-insight.dto';
import { UpdateUserInsightDto } from './dto/update-user-insight.dto';

@Controller('user-insights')
export class UserInsightsController {
    constructor(private readonly userInsightsService: UserInsightsService) {}

    @Post()
    create(@Body() createUserInsightDto: CreateUserInsightDto) {
        return this.userInsightsService.create(createUserInsightDto);
    }

    @Get()
    findAll() {
        return this.userInsightsService.findAll();
    }

    @Get(':id')
    findOne(@Param('id') id: string) {
        return this.userInsightsService.findOne(+id);
    }

    @Patch(':id')
    update(@Param('id') id: string, @Body() updateUserInsightDto: UpdateUserInsightDto) {
        return this.userInsightsService.update(+id, updateUserInsightDto);
    }

    @Delete(':id')
    remove(@Param('id') id: string) {
        return this.userInsightsService.remove(+id);
    }
}
