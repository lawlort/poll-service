import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

@Schema({ timestamps: true, collection: 'user_insights', versionKey: false })
export class UserInsight {
    @Prop()
    ageData: any[];

    @Prop()
    genderData: any[];
}

const UserInsightsSchema = SchemaFactory.createForClass(UserInsight);

export type UserInsightsDocument = HydratedDocument<UserInsight>;

export default UserInsightsSchema;
