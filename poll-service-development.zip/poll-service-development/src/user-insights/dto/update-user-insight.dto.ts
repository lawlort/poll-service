import { PartialType } from '@nestjs/mapped-types';
import { CreateUserInsightDto } from './create-user-insight.dto';

export class UpdateUserInsightDto extends PartialType(CreateUserInsightDto) {}
