export class CreateUserInsightDto {}
