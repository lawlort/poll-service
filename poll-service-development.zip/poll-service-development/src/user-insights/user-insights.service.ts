import { Injectable } from '@nestjs/common';
import { CreateUserInsightDto } from './dto/create-user-insight.dto';
import { UpdateUserInsightDto } from './dto/update-user-insight.dto';

@Injectable()
export class UserInsightsService {
    create(createUserInsightDto: CreateUserInsightDto) {
        console.log(createUserInsightDto);
        return 'This action adds a new userInsight';
    }

    findAll() {
        return `This action returns all userInsights`;
    }

    findOne(id: number) {
        return `This action returns a #${id} userInsight`;
    }

    update(id: number, updateUserInsightDto: UpdateUserInsightDto) {
        console.log(updateUserInsightDto);
        return `This action updates a #${id} userInsight`;
    }

    remove(id: number) {
        return `This action removes a #${id} userInsight`;
    }
}
