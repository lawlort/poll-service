import { Module } from '@nestjs/common';
import { UserInsightsService } from './user-insights.service';
import { UserInsightsController } from './user-insights.controller';

@Module({
    controllers: [UserInsightsController],
    providers: [UserInsightsService]
})
export class UserInsightsModule {}
