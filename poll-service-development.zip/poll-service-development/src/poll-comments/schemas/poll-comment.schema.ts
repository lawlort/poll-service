import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'poll_comments', versionKey: false })
export class PollComment {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    commentBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    pollId: string;

    @Prop({ type: String, required: true })
    comment: string;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;

    @Prop({ type: Date, default: Date.now })
    commentedAt: Date;
}

export const PollCommentSchema = SchemaFactory.createForClass(PollComment);

PollCommentSchema.index({ commentBy: 1, pollId: 1 });
PollCommentSchema.index({ pollId: 1 });
PollCommentSchema.index({ commentBy: 1 });
PollCommentSchema.index({ commentedAt: 1 });

export type PollCommentDocument = HydratedDocument<PollComment>;

export default PollCommentSchema;
