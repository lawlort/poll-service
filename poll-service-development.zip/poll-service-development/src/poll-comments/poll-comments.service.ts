import { Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model } from 'mongoose';
import { Poll } from 'src/polls/schemas/poll.schema';
import { PollComment } from './schemas/poll-comment.schema';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreatePollCommentSchema } from './dto/CreatePollCommentSchema';
import { GetPollCommentSchema } from './dto/GetPollCommentSchema';
import { UpdatePollCommentSchema } from './dto/UpdatePollComment';
import { DeletePollCommentSchema } from './dto/DeletePollCommentSchema';
import { PollsService } from 'src/polls/polls.service';

@Injectable()
export class PollCommentsService {
    constructor(
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        @InjectModel(PollComment.name) private pollCommentModel: Model<PollComment>,
        private pollService: PollsService
    ) {}

    async create(commentData: any, userId: string, pollId: string) {
        try {
            const createPollCommentPayload = {
                commentBy: userId,
                pollId,
                comment: (commentData?.comment || '').trim(),
                commentedAt: commentData?.commentedAt || new Date()
            };

            validateSchema(CreatePollCommentSchema, createPollCommentPayload);

            const poll: any = await this.pollService.findPollById(pollId);
            if (!poll?._id || poll?.isDeleted) {
                throw new NotFoundException('Poll not found');
            }

            const pollComment = await this.pollCommentModel.create(createPollCommentPayload);

            return { success: !!pollComment?._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async getPollComments({ paginateOptions, pollId, search }) {
        try {
            // Validate the pollId using a schema
            validateSchema(GetPollCommentSchema, { pollId });

            // Find the poll to ensure it exists and is not deleted
            const poll: any = await this.pollService.findPollById(pollId);

            if (!poll?._id || poll?.isDeleted) {
                throw new NotFoundException('Poll not found');
            }

            // Define the aggregation pipeline
            const pipeline: any[] = [
                {
                    $match: {
                        pollId: mongoose.Types.ObjectId.createFromHexString(pollId),
                        isDeleted: false
                    }
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: 'commentBy',
                        foreignField: '_id',
                        as: 'commenter'
                    }
                },
                {
                    $unwind: '$commenter'
                },
                {
                    $project: {
                        commenter: { username: 1, profilePicUrl: 1 },
                        comment: 1,
                        commentedAt: 1,
                        pollId: 1
                    }
                }
            ];

            // Add search filter to the pipeline if search term is provided
            if (search) {
                pipeline.push({
                    $match: {
                        'commenter.username': { $regex: search, $options: 'i' }
                    }
                });
            }

            // Add pagination stages to the pipeline
            pipeline.push(
                {
                    $skip: (paginateOptions.page - 1) * paginateOptions.limit
                },
                {
                    $limit: paginateOptions.limit
                }
            );

            // Execute the aggregation pipeline
            const results = await this.pollCommentModel.aggregate(pipeline).exec();

            // Get total count (without pagination)
            const countPipeline = pipeline.slice(0, -2);
            const count = await this.pollCommentModel.aggregate(countPipeline).exec();
            const totalResults = count.length;

            const formattedResults = results.map((comment) => ({
                commentId: comment._id || '',
                commenterUsername: comment.commenter.username || '',
                commenterProfilePicUrl: comment.commenter.profilePicUrl || '',
                comment: comment.comment || '',
                commentedAt: comment.commentedAt
            }));

            return {
                docs: formattedResults,
                page: paginateOptions.page,
                limit: paginateOptions.limit,
                totalPages: Math.ceil(totalResults / paginateOptions.limit),
                totalResults: totalResults
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async updatePollComments(commentData: any, userId: string, commentId: string) {
        try {
            const updatePollCommentPayload = {
                comment: (commentData?.comment || '').trim(),
                commentId
            };

            validateSchema(UpdatePollCommentSchema, updatePollCommentPayload);

            // Validate the comment
            const pollComment = await this.pollCommentModel.findOne({
                _id: commentId,
                commentBy: userId,
                isDeleted: false
            });
            if (!pollComment?._id) {
                throw new UnprocessableEntityException('Comment not found or not authorized to update');
            }

            // Update the comment
            const updatedComment = await this.pollCommentModel.findByIdAndUpdate(
                commentId,
                { comment: updatePollCommentPayload.comment },
                {
                    new: true
                }
            );

            return { id: updatedComment?._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async deletePollComments(userId: string, commentId: string) {
        try {
            // Validate the commentId using a schema
            validateSchema(DeletePollCommentSchema, { commentId });

            // Validate the comment
            const result = await this.pollCommentModel.updateOne(
                { _id: commentId, commentBy: userId, isDeleted: false },
                {
                    $set: {
                        isDeleted: true
                    }
                }
            );

            if (result.modifiedCount === 0) {
                throw new UnprocessableEntityException('Comment not found or not authorized to delete');
            }

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
