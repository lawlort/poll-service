import { Module } from '@nestjs/common';
import { PollCommentsService } from './poll-comments.service';
import { PollCommentsController } from './poll-comments.controller';
import { MongooseModule } from '@nestjs/mongoose';
import PollCommentSchema, { PollComment } from './schemas/poll-comment.schema';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';
import { PollsModule } from 'src/polls/polls.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: PollComment.name, schema: PollCommentSchema },
            { name: Poll.name, schema: PollSchema }
        ]),
        PollsModule
    ],
    controllers: [PollCommentsController],
    providers: [PollCommentsService]
})
export class PollCommentsModule {}
