import { Controller, Body } from '@nestjs/common';
import { PollCommentsService } from './poll-comments.service';
import { MessagePattern } from '@nestjs/microservices';
import {
    CMD_CREATE_POLL_COMMENT,
    CMD_DELETE_POLL_COMMENT,
    CMD_GET_POLL_COMMENT,
    CMD_UPDATE_POLL_COMMENT
} from 'src/utils/constants/commands';

@Controller('poll-comments')
export class PollCommentsController {
    constructor(private readonly pollCommentsService: PollCommentsService) {}

    @MessagePattern({ cmd: CMD_CREATE_POLL_COMMENT })
    async create(@Body() payload) {
        const { body = {}, userId, pollId } = payload;
        return await this.pollCommentsService.create(body, userId, pollId);
    }

    @MessagePattern({ cmd: CMD_GET_POLL_COMMENT })
    async getComments(@Body() payload) {
        const { paginateOptions, pollId, search } = payload?.body || {};
        return await this.pollCommentsService.getPollComments({ paginateOptions, pollId, search });
    }

    @MessagePattern({ cmd: CMD_UPDATE_POLL_COMMENT })
    async update(@Body() payload) {
        const { userId = '', commentId = '', body = {} } = payload;
        return await this.pollCommentsService.updatePollComments(body, userId, commentId);
    }

    @MessagePattern({ cmd: CMD_DELETE_POLL_COMMENT })
    async delete(@Body() payload) {
        const { userId = '', commentId = '' } = payload;
        return await this.pollCommentsService.deletePollComments(userId, commentId);
    }
}
