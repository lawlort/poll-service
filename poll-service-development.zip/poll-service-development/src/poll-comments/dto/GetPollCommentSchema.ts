import * as Joi from 'joi';

// Define a common pattern for ObjectId validation
const objectIdPattern = /^[0-9a-fA-F]{24}$/;

export const GetPollCommentSchema = Joi.object({
    pollId: Joi.string().pattern(objectIdPattern).required().messages({
        'string.pattern.base': 'PollId must be a valid ObjectId',
        'any.required': 'PollId is required'
    })
});
