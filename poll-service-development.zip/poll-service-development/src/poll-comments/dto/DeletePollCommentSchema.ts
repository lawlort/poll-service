import * as Joi from 'joi';

// Define a common pattern for ObjectId validation
const objectIdPattern = /^[0-9a-fA-F]{24}$/;

export const DeletePollCommentSchema = Joi.object({
    commentId: Joi.string().pattern(objectIdPattern).required().messages({
        'string.pattern.base': 'CommentId must be a valid ObjectId',
        'any.required': 'CommentId is required'
    })
});
