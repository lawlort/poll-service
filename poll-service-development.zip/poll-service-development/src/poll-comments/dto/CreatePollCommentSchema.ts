import * as Joi from 'joi';

export const CreatePollCommentSchema = Joi.object({
    commentBy: Joi.string()
        .pattern(/^[0-9a-fA-F]{24}$/) // Ensures it's a valid ObjectId
        .required(),

    pollId: Joi.string()
        .pattern(/^[0-9a-fA-F]{24}$/) // Ensures it's a valid ObjectId
        .required(),

    comment: Joi.string()
        .trim()
        .min(1) // Minimum length of 1 character
        .max(500) // Optional: you can define a maximum length
        .required(),

    commentedAt: Joi.date().optional()
});
