import { Module } from '@nestjs/common';
import { PollRangeLabelsService } from './poll-range-labels.service';
import { PollRangeLabelsController } from './poll-range-labels.controller';
import { MongooseModule } from '@nestjs/mongoose';
import PollRangeLabelSchema, { PollRangeLabel } from './schema/poll-range-schema';
import { PollRangeLabelsServiceV2 } from './poll-range-labels-v2/poll-range-labels.service';
import { PollRangeLabelsControllerV2 } from './poll-range-labels-v2/poll-range-labels.controller';
import PollSliderOptionSchema, { PollSliderOption } from './poll-range-labels-v2/schema/poll-range-schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: PollRangeLabel.name, schema: PollRangeLabelSchema },
            { name: PollSliderOption.name, schema: PollSliderOptionSchema }
        ])
    ],
    controllers: [PollRangeLabelsController, PollRangeLabelsControllerV2],
    providers: [PollRangeLabelsService, PollRangeLabelsServiceV2]
})
export class PollRangeLabelsModule {}
