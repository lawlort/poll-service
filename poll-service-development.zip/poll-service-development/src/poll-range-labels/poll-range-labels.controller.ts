import { Controller } from '@nestjs/common';
import { PollRangeLabelsService } from './poll-range-labels.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_POLL_RANGES } from 'src/utils/constants/commands';

@Controller('poll-range-labels')
export class PollRangeLabelsController {
    constructor(private readonly pollRangeLabelsService: PollRangeLabelsService) {}

    @MessagePattern({ cmd: CMD_GET_POLL_RANGES })
    async findAll() {
        return await this.pollRangeLabelsService.findAll();
    }
}
