import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PollRangeLabel } from './schema/poll-range-schema';
import { Model } from 'mongoose';
import { RpcException } from '@nestjs/microservices';

@Injectable()
export class PollRangeLabelsService {
    constructor(
        @InjectModel(PollRangeLabel.name)
        private interestModel: Model<PollRangeLabel>
    ) {}

    async findAll() {
        try {
            const res = await this.interestModel.find({ isActive: true }).exec();

            return (res || []).map((item) => {
                return {
                    id: item._id,
                    positiveLabel: item.positiveLabel,
                    negativeLabel: item.negativeLabel
                };
            });
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
