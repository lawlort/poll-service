import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

@Schema({ timestamps: true, collection: 'poll_slider_options' })
export class PollRangeLabel {
    @Prop({ required: true })
    positiveLabel: string;

    @Prop({ required: true })
    negativeLabel: string;

    @Prop({ required: true, default: true })
    isActive: boolean;
}

const PollRangeLabelSchema = SchemaFactory.createForClass(PollRangeLabel);

PollRangeLabelSchema.index({ positiveLabel: 1, negativeLabel: 1 }, { unique: true });

PollRangeLabelSchema.method('toClient', function () {
    const obj: any = this.toObject();

    //Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type PollRangeLabelDocument = HydratedDocument<PollRangeLabel>;

export default PollRangeLabelSchema;
