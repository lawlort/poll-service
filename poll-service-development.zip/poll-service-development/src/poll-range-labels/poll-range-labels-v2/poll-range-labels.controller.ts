import { Controller } from '@nestjs/common';
import { PollRangeLabelsServiceV2 } from './poll-range-labels.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_POLL_RANGES_V2 } from 'src/utils/constants/commands';

@Controller('poll-range-labels')
export class PollRangeLabelsControllerV2 {
    constructor(private readonly pollRangeLabelsService: PollRangeLabelsServiceV2) {}

    @MessagePattern({ cmd: CMD_GET_POLL_RANGES_V2 })
    async findAll() {
        return await this.pollRangeLabelsService.findAll();
    }
}
