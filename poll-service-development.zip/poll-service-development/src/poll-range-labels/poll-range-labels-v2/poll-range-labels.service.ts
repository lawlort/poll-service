import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PollSliderOption, PollSliderOptionDocument } from './schema/poll-range-schema';
import { Model } from 'mongoose';
import { RpcException } from '@nestjs/microservices';

@Injectable()
export class PollRangeLabelsServiceV2 {
    constructor(
        @InjectModel(PollSliderOption.name)
        private readonly pollSliderOptionModel: Model<PollSliderOptionDocument>
    ) {}

    async findAll() {
        try {
            // Query to find documents where isDeleted is false and isActive is true
            const result = await this.pollSliderOptionModel
                .find(
                    { isDeleted: false, isActive: true },
                    { ranges: 1 } // Only project 'ranges' field
                )
                .lean();

            // Map the result to format the output and ensure ranges are ordered by 'order'
            const formattedResult = result.map((doc) => ({
                id: doc._id,
                ranges: doc.ranges.sort((a, b) => a.order - b.order) // Sort ranges by order
            }));

            return formattedResult;
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
