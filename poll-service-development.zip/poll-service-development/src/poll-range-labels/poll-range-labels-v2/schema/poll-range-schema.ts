import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

@Schema({ timestamps: true, collection: 'poll_slider_options_v2' })
export class PollSliderOption {
    @Prop({
        type: [
            {
                order: { type: Number, required: true },
                min: { type: Number, required: true },
                max: { type: Number, required: true },
                label: { type: String, required: true }
            }
        ],
        required: true
    })
    ranges: {
        order: number;
        min: number;
        max: number;
        label: string;
    }[];

    @Prop({ default: true })
    isActive: boolean;

    @Prop({ default: false })
    isDeleted: boolean;
}

const PollSliderOptionSchema = SchemaFactory.createForClass(PollSliderOption);

// Indexing if required
PollSliderOptionSchema.index({ isActive: 1, isDeleted: 1 });

// Method to transform the object before returning
PollSliderOptionSchema.method('toClient', function () {
    const obj: any = this.toObject();

    // Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type PollSliderOptionDocument = HydratedDocument<PollSliderOption>;

export default PollSliderOptionSchema;
