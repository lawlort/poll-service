import { Module } from '@nestjs/common';
import { ReportGroupReasonsService } from './report-group-reasons.service';
import { ReportGroupReasonsController } from './report-group-reasons.controller';
import { MongooseModule } from '@nestjs/mongoose';
import ReportGroupReasonSchema, { ReportGroupReason } from './schemas/report-group-reasons.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: ReportGroupReason.name, schema: ReportGroupReasonSchema }])],
    controllers: [ReportGroupReasonsController],
    providers: [ReportGroupReasonsService]
})
export class ReportGroupReasonsModule {}
