import { Controller } from '@nestjs/common';
import { ReportGroupReasonsService } from './report-group-reasons.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_REPORT_GROUP_REASONS } from 'src/utils/constants/commands';

@Controller('report-group-reasons')
export class ReportGroupReasonsController {
    constructor(private readonly reportGroupReasonsService: ReportGroupReasonsService) {}

    @MessagePattern({ cmd: CMD_GET_REPORT_GROUP_REASONS })
    async findAll() {
        return await this.reportGroupReasonsService.findAll();
    }
}
