import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ReportGroupReason } from './schemas/report-group-reasons.schema';

@Injectable()
export class ReportGroupReasonsService {
    constructor(
        @InjectModel(ReportGroupReason.name)
        private reportCommentReasonModel: Model<ReportGroupReason>
    ) {}

    async findAll() {
        try {
            const res = await this.reportCommentReasonModel.find({ isActive: true, isDeleted: false }).exec();
            return (res || []).map((item) => {
                return {
                    id: item._id,
                    reason: item.reason
                };
            });
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
