import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { ReportPollReason } from './schemas/report-poll-reasons.schema';
import { Model } from 'mongoose';

@Injectable()
export class ReportPollReasonsService {
    constructor(
        @InjectModel(ReportPollReason.name)
        private reportPollReasonModel: Model<ReportPollReason>
    ) {}

    async findAll() {
        try {
            const res = await this.reportPollReasonModel.find({ isActive: true, isDeleted: false }).exec();
            return (res || []).map((item) => {
                return {
                    id: item._id,
                    reason: item.reason
                };
            });
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
