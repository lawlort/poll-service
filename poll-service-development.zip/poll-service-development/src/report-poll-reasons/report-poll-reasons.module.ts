import { Module } from '@nestjs/common';
import { ReportPollReasonsService } from './report-poll-reasons.service';
import { ReportPollReasonsController } from './report-poll-reasons.controller';
import { MongooseModule } from '@nestjs/mongoose';
import ReportPollReasonSchema, { ReportPollReason } from './schemas/report-poll-reasons.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: ReportPollReason.name, schema: ReportPollReasonSchema }])],
    controllers: [ReportPollReasonsController],
    providers: [ReportPollReasonsService]
})
export class ReportPollReasonsModule {}
