import { Controller } from '@nestjs/common';
import { ReportPollReasonsService } from './report-poll-reasons.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_REPORT_POLL_REASONS } from 'src/utils/constants/commands';

@Controller('report-poll-reasons')
export class ReportPollReasonsController {
    constructor(private readonly reportPollReasonsService: ReportPollReasonsService) {}

    @MessagePattern({ cmd: CMD_GET_REPORT_POLL_REASONS })
    async findAll() {
        return await this.reportPollReasonsService.findAll();
    }
}
