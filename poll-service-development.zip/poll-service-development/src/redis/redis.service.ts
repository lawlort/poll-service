import { Inject, Injectable } from '@nestjs/common';
import { Redis } from 'ioredis';

@Injectable()
export class RedisService {
    constructor(@Inject('REDIS_CLIENT') private readonly redisClient: Redis) {}
    async setWithExpiry(key: string, value: any, expiryInSeconds: number) {
        try {
            await this.redisClient.setex(key, expiryInSeconds, JSON.stringify(value));
        } catch (error) {
            throw error;
        }
    }

    async setWithoutExpiry(key: string, value: any) {
        try {
            await this.redisClient.set(key, JSON.stringify(value));
        } catch (error) {
            throw error;
        }
    }

    async get(key: string) {
        try {
            return await this.redisClient.get(key);
        } catch (error) {
            throw error;
        }
    }
}
