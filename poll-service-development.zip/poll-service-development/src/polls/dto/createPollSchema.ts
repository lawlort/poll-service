import * as Joi from 'joi';
import {
    audioMimeTypes,
    DisplayResultModes,
    imagesMimeTypes,
    PollStatuses,
    QuestionTypes,
    videoMimeTypes,
    VisibilityTypes
} from '../schemas/poll.schema';

// Helper function to determine media type category
const getMediaTypeCategory = (mediaType) => {
    if (imagesMimeTypes.includes(mediaType)) return 'image';
    if (audioMimeTypes.includes(mediaType)) return 'audio';
    if (videoMimeTypes.includes(mediaType)) return 'video';
    return null;
};

// Regex pattern for MongoDB ObjectId
const objectIdRegex = /^[0-9a-fA-F]{24}$/;

// Mapping of MIME types to file extensions
const mimeTypesToExtensions = {
    'image/jpeg': ['.jpeg', '.jpg'],
    'image/jpg': ['.jpg'],
    'image/png': ['.png'],
    'image/heic': ['.heic'],
    'image/heif': ['.heif'],
    'audio/mpeg': ['.mp3'],
    'audio/wav': ['.wav'],
    'audio/aac': ['.aac'],
    'audio/flac': ['.flac'],
    'audio/ogg': ['.ogg'],
    'audio/mp4': ['.m4a'],
    'audio/midi': ['.midi'],
    'audio/x-ms-wma': ['.wma'],
    'audio/webm': ['.webm'],
    'video/mp4': ['.mp4'],
    'video/x-msvideo': ['.avi'],
    'video/quicktime': ['.mov'],
    'video/x-ms-wmv': ['.wmv'],
    'video/x-matroska': ['.mkv'],
    'video/x-flv': ['.flv'],
    'video/webm': ['.webm'],
    'video/mpeg': ['.mpeg'],
    'video/3gpp': ['.3gp']
};

// Function to validate file extension based on mediaType
const validateFileExtension = (mediaUrl, mediaType) => {
    const url = new URL(mediaUrl);
    const extension = url.pathname.split('.').pop().toLowerCase();
    const allowedExtensions = mimeTypesToExtensions[mediaType];

    return allowedExtensions && allowedExtensions.includes(`.${extension}`);
};

// Joi schema for Option
const optionSchema = Joi.object({
    id: Joi.number().min(1).required().messages({
        'number.base': 'Option id must be a number',
        'number.min': 'Option id must be greater than or equal to 1'
    }),
    value: Joi.string().optional().max(120),
    mediaUrl: Joi.string().uri().optional().allow(''),
    thumbnailUrl: Joi.string().uri().optional().allow(''),
    mediaType: Joi.string()
        .optional()
        .valid(...imagesMimeTypes, ...audioMimeTypes, ...videoMimeTypes)
});

// Custom validation to ensure unique IDs, values, mediaUrls within the options array,
// and that all mediaTypes are the same and from a set of allowed types
const uniqueOptionAttributes = (value: any, helpers: any) => {
    const ids = value.map((option: any) => option.id);
    const values = value.map((option: any) => (option.value || '').trim()).filter((value) => value);
    const mediaUrls = value.map((option: any) => option.mediaUrl).filter((url) => url);
    const mediaTypes = value.map((option: any) => option.mediaType).filter((type) => type);

    const uniqueIds = new Set(ids);
    const uniqueValues = new Set(values);
    const uniqueMediaUrls = new Set(mediaUrls);
    const uniqueMediaTypes = new Set(mediaTypes.map(getMediaTypeCategory));

    const trimmedValues = value.map((option: any) => option.value && (option.value || '').trim());

    const allEmpty = trimmedValues.every((value) => value === '');

    // check for all empty string values
    if (allEmpty) {
        return helpers.error('any.custom', { custom: 'Option values must not be empty' });
    }

    if (uniqueIds.size !== ids.length) {
        return helpers.error('any.custom', { custom: 'Option IDs must be unique' });
    }

    if (values?.length && uniqueValues.size !== values.length) {
        return helpers.error('any.custom', { custom: 'Option values must be unique' });
    }

    if (uniqueMediaUrls.size !== mediaUrls.length && mediaUrls.some((url) => url !== '')) {
        return helpers.error('any.custom', { custom: 'Option media URLs must be unique' });
    }

    if (uniqueMediaTypes.size > 1) {
        return helpers.error('any.custom', {
            custom: 'All media types of options must be from the same category image, audio, or video'
        });
    }

    for (const option of value) {
        if (option.mediaUrl && option.mediaType && !validateFileExtension(option.mediaUrl, option.mediaType)) {
            return helpers.error('any.custom', {
                custom: `Media URL ${option.mediaUrl} does not match the specified media type ${option.mediaType}`
            });
        }
    }

    // Ensure that if one mediaUrl is present, it must be present in all options
    if (mediaUrls.length > 0 && mediaUrls.length !== value.length) {
        return helpers.error('any.custom', {
            custom: 'If one option has a media URL, all options must have a media URL'
        });
    }

    // Ensure that if one mediaType is present, it must be present in all options
    if (mediaTypes.length > 0 && mediaTypes.length !== value.length) {
        return helpers.error('any.custom', {
            custom: 'If one option has a media type, all options must have a media type'
        });
    }

    // Ensure that mediaUrl and mediaType lengths are same
    if (mediaUrls.length !== mediaTypes.length) {
        return helpers.error('any.custom', {
            custom: 'Media URL and media type lengths must be the same'
        });
    }

    if (values?.length === 0 && mediaUrls?.length === 0) {
        return helpers.error('any.custom', { custom: 'Option text or media is missing' });
    }

    return value;
};

// Joi schema for Question
const questionSchema = Joi.object({
    id: Joi.number().min(1).required().messages({
        'number.base': 'Question id must be a number',
        'number.min': 'Question id must be greater than or equal to 1'
    }),
    title: Joi.string().required().max(120),
    description: Joi.string().optional().max(200).allow(''),
    isMultiChoice: Joi.boolean()
        .when('type', {
            is: QuestionTypes.DATE,
            then: Joi.required(),
            otherwise: Joi.forbidden()
        })
        .messages({
            'any.required': 'isMultiChoice is required when the question type is "date"',
            'any.unknown': 'isMultiChoice is not allowed when the question type is not "date"'
        }),
    type: Joi.string()
        .required()
        .valid(...Object.values(QuestionTypes)),
    options: Joi.array()
        .items(optionSchema)
        .optional()
        .custom(uniqueOptionAttributes)
        .when('type', {
            switch: [
                { is: QuestionTypes.THIS_THAT, then: Joi.array().length(2).required() },
                { is: QuestionTypes.SINGLE_CHOICE, then: Joi.array().min(3).max(6).required() },
                { is: QuestionTypes.SLIDER, then: Joi.array().length(1).required() },
                { is: QuestionTypes.LIGHT_METER, then: Joi.array().length(0).optional() },
                { is: QuestionTypes.MULTIPLE_CHOICE, then: Joi.array().min(2).max(6).required() },
                { is: QuestionTypes.DATE, then: Joi.array().min(2).max(6).required() },
                { is: QuestionTypes.RANKING, then: Joi.array().min(2).max(6).required() }
            ],
            otherwise: Joi.array().max(6).optional()
        })
});

// Custom validation to ensure unique IDs within the questions array
const uniqueQuestionIds = (value: any, helpers: any) => {
    const ids = value.map((question: any) => question.id);
    const uniqueIds = new Set(ids);
    if (uniqueIds.size !== ids.length) {
        return helpers.error('any.custom', { custom: 'Question IDs must be unique' });
    }
    return value;
};

// // Calculate the end of the 7th day from now in UTC (23:59:59.999)
// const endOf7thDay = new Date();
// endOf7thDay.setUTCDate(endOf7thDay.getUTCDate() + 7);
// endOf7thDay.setUTCHours(23, 59, 59, 999);

// // Convert to ISO string
// const endOf7thDayISO = endOf7thDay.toISOString();

// Get the current date in UTC
const nowUTC = new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate()));

// Calculate the end of the 7th day from now in UTC (23:59:59.999)
const endOf7thDayUTC = new Date(
    Date.UTC(nowUTC.getUTCFullYear(), nowUTC.getUTCMonth(), nowUTC.getUTCDate() + 7, 23, 59, 59, 999)
);

// Convert to ISO string
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const endOf7thDayISO = endOf7thDayUTC.toISOString();

// Joi schema for Poll
export const CreatePollSchema = Joi.object({
    visibility: Joi.string()
        .required()
        .valid(...Object.values(VisibilityTypes)),
    isAnonymous: Joi.boolean().optional(),
    allowComments: Joi.boolean().optional(),
    bgImageUrl: Joi.string().uri().optional(),
    convertedMediaUrl: Joi.string().uri().optional(),
    thumbnailUrl: Joi.string().uri().optional().allow(''),
    mediaType: Joi.string()
        .optional()
        .valid(...imagesMimeTypes, ...audioMimeTypes, ...videoMimeTypes),
    endDate: Joi.date()
        // .max(endOf7thDayISO) // Set max date to the end of the 7th day
        .required(),
    status: Joi.string()
        .optional()
        .valid(...Object.values(PollStatuses)),
    isDeleted: Joi.boolean().optional(),
    updatedBy: Joi.string().optional().allow(''),
    interests: Joi.array().items(Joi.string().pattern(objectIdRegex)).required().min(1).max(3),
    questions: Joi.array().items(questionSchema).required().length(1).custom(uniqueQuestionIds),
    displayResultMode: Joi.string()
        .required()
        .valid(...Object.values(DisplayResultModes))
});
