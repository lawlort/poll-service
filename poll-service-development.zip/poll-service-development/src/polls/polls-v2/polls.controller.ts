import { Controller, Body } from '@nestjs/common';
import { PollsServiceV2 } from './polls.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_CREATE_POLL_V2 } from 'src/utils/constants/commands';

@Controller('polls')
export class PollsControllerV2 {
    constructor(private readonly pollsService: PollsServiceV2) {}

    @MessagePattern({ cmd: CMD_CREATE_POLL_V2 })
    async createV2(@Body() payload) {
        const { body = {}, user = {}, ip = '' } = payload;
        return await this.pollsService.create(body, user, ip);
    }
}
