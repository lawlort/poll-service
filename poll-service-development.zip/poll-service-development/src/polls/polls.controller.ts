import { Controller, Body } from '@nestjs/common';
import { PollsService } from './polls.service';
import { MessagePattern } from '@nestjs/microservices';
import {
    CMD_CLOSE_POLL,
    CMD_CREATE_POLL,
    CMD_DELETE_POLL_BY_ID,
    CMD_GET_MY_POLLS,
    CMD_GET_MY_POLLS_V2,
    CMD_GET_POLL_BY_ID,
    CMD_GET_PROMOTED_POLL,
    CMD_UPDATE_POLL_BY_ID,
    CMD_UPDATE_POLL_IN_CACHE
} from '../utils/constants/commands';

@Controller('polls')
export class PollsController {
    constructor(private readonly pollsService: PollsService) {}

    @MessagePattern({ cmd: CMD_CREATE_POLL })
    async create(@Body() payload) {
        const { body = {}, user = {}, ip = '' } = payload;
        return await this.pollsService.create(body, user, ip);
    }

    @MessagePattern({ cmd: CMD_GET_POLL_BY_ID })
    async findOne(@Body() payload) {
        const { userId = '', pollId = '' } = payload;
        return await this.pollsService.findOne(pollId, userId);
    }

    @MessagePattern({ cmd: CMD_UPDATE_POLL_IN_CACHE })
    async updateUserInCache(@Body() payload) {
        const { id = '' } = payload;
        return await this.pollsService.updatePollInCache(id);
    }

    @MessagePattern({ cmd: CMD_DELETE_POLL_BY_ID })
    async delete(@Body() payload) {
        const { userId = '', pollId = '' } = payload;
        return await this.pollsService.delete(pollId, userId);
    }

    @MessagePattern({ cmd: CMD_UPDATE_POLL_BY_ID })
    async update(@Body() payload) {
        const { userId = '', pollId = '', body = {} } = payload;
        return await this.pollsService.update(body, pollId, userId);
    }

    @MessagePattern({ cmd: CMD_GET_MY_POLLS })
    async myPolls(@Body() payload) {
        const { userId = '', query = {}, currentUserId = '', paginateOptions = {} } = payload;
        return await this.pollsService.myPolls(query, userId, currentUserId, paginateOptions);
    }

    @MessagePattern({ cmd: CMD_GET_MY_POLLS_V2 })
    async myPollsV2(@Body() payload) {
        const { userId = '', query = {}, currentUserId = '', paginateOptions = {} } = payload;
        return await this.pollsService.myPollsV2(query, userId, currentUserId, paginateOptions);
    }

    @MessagePattern({ cmd: CMD_CLOSE_POLL })
    async endPoll(@Body() payload) {
        const { userId = '', pollId = '' } = payload;
        return await this.pollsService.closePoll(pollId, userId);
    }

    @MessagePattern({ cmd: CMD_GET_PROMOTED_POLL })
    async findPromotedPolls(@Body() payload) {
        const { pollId, paginateOptions } = payload?.body || {};
        return await this.pollsService.findPromotedPolls(pollId, paginateOptions);
    }
}
