import { BadRequestException, Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreatePollSchema } from './dto/createPollSchema';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { Poll, PollStatuses, QuestionTypes } from './schemas/poll.schema';
import { isValidObjectId, Model } from 'mongoose';
import { globalErrorObj } from 'src/utils/common/globalErrorRes';
import { UpdatePollSchema } from './dto/updatePollSchema';
import { removeFieldsFromObject } from 'src/utils/common/mongoose/removeFields';
import { LocationsService } from 'src/locations/locations.service';
import { Location, LocationEventType } from 'src/locations/schemas/location.schema';
import mongoose from 'mongoose';
import { Cron } from '@nestjs/schedule';
import { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
import { PollComment } from 'src/poll-comments/schemas/poll-comment.schema';
import { PollInsight } from 'src/poll-insights/schemas/poll-insight.schema';
import { InterestsService } from 'src/interests/interests.service';
import { PollResponseHistory } from 'src/poll-response-history/schemas/poll-response-history.schema';
import { BookmarkedPoll } from 'src/bookmarked-polls/schemas/bookmarked-poll.schema';
import { PollInsightsService } from 'src/poll-insights/poll-insights.service';
import { RedisService } from 'src/redis/redis.service';
import { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import { GroupMember } from 'src/group-members/schemas/group-members.schema';
import { SharedPollWithUsers } from 'src/shared-poll-with-users/schemas/shared-poll-with-users.schema';
import { PollGuidMapping } from 'src/poll-guid-mapping/schemas/poll-guid-mapping.schema';
import { ReportedPollComment } from 'src/reported-poll-comments/schemas/reported-poll-comment.schema';
import { ReportedPoll } from 'src/reported-polls/schemas/reported-poll.schema';
import { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import { VisibilityTypes } from 'src/utils/constants/string';
import { UsersService } from 'src/users/users.service';
import { Group } from 'src/groups/schemas/group.schema';

@Injectable()
export class PollsService {
    constructor(
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        @InjectModel(PollResponse.name) private pollResponseModel: Model<PollResponse>,
        @InjectModel(PollComment.name) private pollCommentModel: Model<PollComment>,
        @InjectModel(PollInsight.name) private pollInsightModel: Model<PollInsight>,
        @InjectModel(PollResponseHistory.name) private pollResponseHistoryModel: Model<PollResponseHistory>,
        @InjectModel(BookmarkedPoll.name) private bookmarkPollModel: Model<BookmarkedPoll>,
        @InjectModel(GroupPoll.name) private groupPollModel: Model<GroupPoll>,
        @InjectModel(GroupMember.name) private groupMemberModel: Model<GroupMember>,
        @InjectModel(SharedPollWithUsers.name) private sharedPollWithUsersModel: Model<SharedPollWithUsers>,
        @InjectModel(Location.name) private locationModel: Model<Location>,
        @InjectModel(PollGuidMapping.name) private pollGuidMapping: Model<Location>,
        @InjectModel(ReportedPollComment.name) private reportedPollCommentModel: Model<ReportedPollComment>,
        @InjectModel(ReportedPoll.name) private reportedPollModel: Model<ReportedPoll>,
        @InjectModel(SharedPoll.name) private sharedPollModel: Model<SharedPoll>,
        @InjectModel(Group.name) private groupModel: Model<Group>,
        private locationService: LocationsService,
        private interstsService: InterestsService,
        private pollInsightsService: PollInsightsService,
        private redisService: RedisService,
        private userService: UsersService
    ) {}

    async updatePollInCache(pollId: string) {
        try {
            const poll: any = await this.pollModel.findById(pollId).populate({ path: 'interests', select: '_id name' });
            const pollObj = poll?.toObject();

            pollObj.interests = (poll.interests || []).map((interest) => {
                return { id: interest._id, name: interest.name };
            });
            this.savePollInCache(pollId);
            return poll;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async savePollInCache(pollId) {
        const strPollId = (pollId || '').toString();
        if (strPollId) {
            const poll: any = await this.pollModel
                .findById(strPollId)
                .populate({ path: 'interests', select: '_id name' });
            if (poll?._id) {
                const pollObj = poll?.toObject();
                pollObj.interests = (poll.interests || []).map((interest) => {
                    return { id: interest._id, name: interest.name };
                });

                const cacheObj = {
                    data: pollObj,
                    createdAt: new Date().toISOString()
                };

                this.redisService.setWithExpiry(`${strPollId}:poll`, cacheObj, 60 * 60 * 24);
            }
        }
    }

    async findPollById(pollId: string) {
        try {
            // const pollFromCache = await this.redisService.get(`${pollId}:poll`);
            const pollFromCache = false;
            if (pollFromCache) {
                const { data = {}, createdAt = '' } = JSON.parse(pollFromCache);
                const cacheAgeInMilliseconds = new Date().getTime() - new Date(createdAt).getTime();
                const cacheAgeInMinutes = cacheAgeInMilliseconds / (1000 * 60);
                if (cacheAgeInMinutes > 10) {
                    this.savePollInCache(pollId);
                }
                return data;
            }
            const poll: any = await this.pollModel.findById(pollId).populate({ path: 'interests', select: '_id name' });
            const pollObj = poll?.toObject();

            if (pollObj) {
                pollObj.interests = (poll.interests || []).map((interest) => {
                    return { id: interest._id, name: interest.name };
                });
            }
            this.savePollInCache(pollId);
            return poll;
        } catch (error) {
            return {};
        }
    }

    async create(createPollData, user: any, ip: string) {
        try {
            // TODO: Manage private poll in later sprint

            if (!user?.id) {
                throw new NotFoundException('User not found');
            }
            validateSchema(CreatePollSchema, createPollData);

            // for date poll check value of all options are valid date
            if (createPollData?.questions?.length) {
                for (const question of createPollData.questions) {
                    if (question?.type === QuestionTypes.DATE) {
                        for (const option of question.options) {
                            if (isNaN(Date.parse(option.value))) {
                                throw new BadRequestException(
                                    globalErrorObj('Invalid option date value', 'value', 'string.pattern.base')
                                );
                            }
                        }
                        // get max id from options
                        if (question?.options?.length) {
                            const maxId = Math.max(...question.options.map((option) => option.id));
                            question.options.push({ id: maxId + 1, value: 'None of these' });
                        }
                    }
                }
            }

            // check interest exists in db
            const allInterests = await this.interstsService.findAll();
            const interests: string[] = allInterests.map((interest) => (interest?.id || '').toString());
            const interestIds = createPollData.interests || [];
            for (const interestId of interestIds) {
                if (!interests.includes(interestId)) {
                    throw new NotFoundException('Interest not found');
                }
            }

            for (const question of createPollData?.questions || []) {
                if (question?.type === QuestionTypes.RANKING) {
                    const optionsLength = question?.options?.length || 0;
                    const optionWeightage = {};
                    if (optionsLength) {
                        for (let i = 1; i <= optionsLength; i++) {
                            optionWeightage[i] = Number(
                                Number((1 / optionsLength) * (optionsLength - i + 1) * 100).toFixed(3)
                            );
                        }
                    }
                    question.optionWeightage = optionWeightage;
                }
            }

            createPollData.createdByUsername = user?.username || '';
            createPollData.createdByUserId = user?.id || '';
            createPollData.createdByUserProfilePicUrl = user?.profilePicUrl || '';
            const poll = await this.pollModel.create(createPollData);
            await poll.save();
            // get location details
            const locationDetails: any = await this.locationService.getLocationDetails(ip);

            if (!(locationDetails?.data?.status === 'fail')) {
                const locationData = locationDetails?.data || {};
                const locationPayload = { eventType: LocationEventType.CREATE_POLL, pollId: poll._id, ...locationData };
                await this.locationService.create(locationPayload);
            }

            this.pollInsightsService.createEmptyPollInsight(poll._id.toString());

            this.savePollInCache(poll._id);
            return { id: poll._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async findOne(pollId: string, userId: string) {
        try {
            if (userId) {
                // TODO: Check user has access to poll when implementing private poll in next sprint
            }

            // Check if pollId is valid
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.pattern.base'));
            }

            const pollDocument: any = await this.pollModel
                .findById(pollId)
                .populate({ path: 'interests', select: '_id name' });

            if (!pollDocument || pollDocument?.isDeleted || !pollDocument?._id) {
                throw new NotFoundException('Poll not found');
            }

            if (!pollDocument?.isActive) {
                throw new UnprocessableEntityException('Poll is not active');
            }

            // Convert Mongoose document to plain object
            const poll = pollDocument.toObject();

            // Get poll responses
            const pollResponses = await this.pollResponseModel.find({ pollId, userId });

            if (poll?.questions?.length) {
                poll.questions = poll.questions.map((question) => {
                    const options = question?.options || [];

                    // If poll type is SINGLE_CHOICE or THIS_THAT
                    if (question?.type === QuestionTypes.SINGLE_CHOICE || question?.type === QuestionTypes.THIS_THAT) {
                        const pollResponse = pollResponses[0];
                        const optionId = pollResponse?.optionId;

                        // Map options to add isSelected field
                        question.options = options.map((option) => ({
                            ...option,
                            isSelected: option.id === optionId
                        }));
                    }

                    // If poll type is MULTIPLE_CHOICE or DATE
                    if (question?.type === QuestionTypes.MULTIPLE_CHOICE || question?.type === QuestionTypes.DATE) {
                        // const pollResponse = pollResponses[0];
                        const optionIds = (pollResponses || []).map((response) => response.optionId);

                        // Map options to add isSelected field for multiple choice
                        question.options = options.map((option) => ({
                            ...option,
                            isSelected: optionIds.includes(option.id)
                        }));
                    }

                    // If poll type is SLIDER or LIGHT_METER
                    if (question?.type === QuestionTypes.SLIDER || question?.type === QuestionTypes.LIGHT_METER) {
                        pollResponses?.length &&
                            pollResponses[0] &&
                            (question.sliderValue = pollResponses[0]?.sliderValue || 0);
                    }

                    // If poll type is RANKING
                    if (question?.type === QuestionTypes.RANKING) {
                        question.options = options.map((option) => {
                            const pollResponse = pollResponses.find((response) => response.optionId === option.id);
                            return {
                                ...option,
                                selectedRank: pollResponse?.order || null
                            };
                        });
                    }

                    return question;
                });
                poll['isAnswered'] = pollResponses.length > 0;
            }
            const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                pollId,
                userId,
                isDeleted: false
            });
            const bookmarkedPoll = await this.bookmarkPollModel.findOne({ pollId, bookmarkedBy: userId });
            poll['allowChangeMyMind'] = pollResponseHistoryCount < 2;
            poll['isSaved'] = !!bookmarkedPoll?._id;

            const count = await this.pollResponseModel.countDocuments({ pollId });

            poll['votes'] = count;

            // get poll comments count
            const pollCommentsCount = await this.pollCommentModel.countDocuments({ pollId, isDeleted: false });
            poll['commentCount'] = pollCommentsCount;

            // First, find all the group memberships for the user
            const userGroups = await this.groupMemberModel
                .find({ userId: userId, isActive: true, isDeleted: false }) // Ensure user is active and not deleted
                .select('groupId') // Select only the groupId field
                .exec();

            // Extract the group IDs that the user is a member of
            const userGroupIds = userGroups.map((membership) => membership?.groupId?.toString());

            // Then, find the polls shared with those groups
            const groupSharedPolls = await this.groupPollModel
                .find({ pollId, isDeleted: false }) // Filter by pollId and user's groupIds
                .populate({
                    path: 'groupId',
                    populate: {
                        path: 'groupInterests',
                        select: '_id name'
                    }
                })
                .exec();

            // Filter out the groups that are undefined/null and extract the valid group information
            const groups = groupSharedPolls
                .filter((group) => group?.groupId) // Ensure groupId is valid
                .map((group) => group.groupId) // Extract the groupId details
                .map((group: any) => {
                    return {
                        ...group.toObject(),
                        isGroupMember: userGroupIds.includes(group?._id?.toString())
                    };
                });

            poll['groups'] = groups || [];

            const user = await this.userService.getUserById(userId);
            const userInterests = user?.interests || [];
            const userInterestNames = userInterests.map((interest: any) => interest.name); // Get user interest names

            poll['interests'] = (poll['interests'] || [])
                .map((interest) => {
                    return {
                        id: interest._id,
                        name: interest.name,
                        isUserInterest: userInterestNames.includes(interest.name)
                    };
                })
                .sort((a, b) => {
                    // Sort by isGroupMember with `true` values first
                    return a.isUserInterest === b.isUserInterest ? 0 : a.isUserInterest ? -1 : 1;
                });

            // Remove specific fields before sending the response
            return removeFieldsFromObject(poll, ['createdAt', 'updatedAt']);
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async delete(pollId: string, userId: string) {
        try {
            /* 
                TODO:
                // remove poll likes
                // remove poll invitations
            */

            // Check poll id is valid or not
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.pattern.base'));
            }

            const poll: any = await this.findPollById(pollId);

            if (!poll || poll?.isDeleted || !poll?._id) {
                throw new NotFoundException('Poll not found');
            }

            if (!poll?.isActive) {
                throw new UnprocessableEntityException('Poll is not active');
            }

            if (poll?.createdByUserId != userId) {
                throw new UnprocessableEntityException('Only poll owner can delete the poll');
            }

            await this.pollModel.findByIdAndUpdate(pollId, {
                isDeleted: true,
                isActive: false
            });

            await this.pollResponseModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.pollCommentModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.pollInsightModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.groupPollModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.sharedPollWithUsersModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.bookmarkPollModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.locationModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.pollGuidMapping.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.pollResponseHistoryModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.reportedPollCommentModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.reportedPollModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });
            await this.sharedPollModel.updateMany({ pollId, isDeleted: false }, { $set: { isDeleted: true } });

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async update(updatePollData: any, pollId: string, userId: string) {
        try {
            // TODO: handle public to private poll case
            // TODO: update question type in response as well

            // Check poll id is valid or not
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.pattern.base'));
            }

            const poll: any = await this.findPollById(pollId);

            if (!poll?._id) {
                throw new NotFoundException('Poll not found');
            }

            // Check poll is created by user or not
            if (poll?.createdByUserId != userId) {
                throw new UnprocessableEntityException('Only owner can update the poll');
            }

            // Validate payload
            validateSchema(UpdatePollSchema, updatePollData);

            // When poll is published then only description and end date can be updated
            if (poll?.status === PollStatuses.PUBLISHED) {
                const updatePollPyaload: any = poll;
                updatePollPyaload.updatedBy = userId;
                if (updatePollData?.endDate) {
                    updatePollPyaload.endDate = updatePollData.endDate;
                    updatePollPyaload['isClosed'] = false;
                }

                const questions = updatePollData?.questions || [];
                for (const i in questions) {
                    const question = questions[i];
                    if (
                        question?.description &&
                        updatePollPyaload?.questions?.length &&
                        updatePollPyaload.questions[i]
                    ) {
                        updatePollPyaload.questions[i].description = question.description;
                    }
                }
                const updatedPoll = await this.pollModel.findByIdAndUpdate(pollId, updatePollPyaload, {
                    new: true
                });
                await updatedPoll.save();
            } else if (poll?.status === PollStatuses.REJECTED) {
                updatePollData.updatedBy = userId;

                // Not allowing user to update created by
                if (updatePollData?.createdByUserId) {
                    delete updatePollData.createdByUserId;
                }

                const allInterests = await this.interstsService.findAll();
                const interests: string[] = allInterests.map((interest) => (interest?.id || '').toString());
                const interestIds = updatePollData.interests || [];
                for (const interestId of interestIds) {
                    if (!interests.includes(interestId)) {
                        throw new NotFoundException('Interest not found');
                    }
                }

                const updatedPoll = await this.pollModel.findByIdAndUpdate(pollId, updatePollData, {
                    new: true
                });
                await updatedPoll.save();
            }
            this.savePollInCache(pollId);
            return { id: pollId };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    // Old function to get polls from user
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    // async myPolls(queryParams: any, userId: string, currentUserId: string, paginateOptions: any) {
    //     try {
    //         const { isActive = false, trendingPolls = false } = queryParams;
    //         const currentDate = new Date();

    //         // Initialize the match conditions
    //         const matchConditions: any = {
    //             isActive: true,
    //             isDeleted: false,
    //             createdByUserId: mongoose.Types.ObjectId.createFromHexString(userId)
    //         };

    //         // If currentUserId and userId are different, only show published polls
    //         if (currentUserId.toString() !== userId.toString()) {
    //             matchConditions['status'] = PollStatuses.UNDER_REVIEW;
    //             // matchConditions['status'] = PollStatuses.PUBLISHED; // TODO: undo comment and remove above line
    //             matchConditions['isAnonymous'] = false;

    //             matchConditions['$or'] = [
    //                 { visibility: VisibilityTypes.PUBLIC },
    //                 {
    //                     // Only include private polls shared with the current user
    //                     visibility: VisibilityTypes.PRIVATE,
    //                     _id: {
    //                         $in: await this.sharedPollModel
    //                             .find({
    //                                 sharedWith: mongoose.Types.ObjectId.createFromHexString(currentUserId),
    //                                 isDeleted: false
    //                             })
    //                             .distinct('pollId')
    //                     }
    //                 }
    //             ];
    //         }

    //         // If isActive is true, add endDate filter
    //         if (isActive === 'true') {
    //             matchConditions['endDate'] = { $gt: currentDate };
    //         }

    //         // Build the aggregation pipeline
    //         const aggregationPipeline: any = [
    //             { $match: matchConditions },
    //             {
    //                 $lookup: {
    //                     from: 'interests',
    //                     localField: 'interests',
    //                     foreignField: '_id',
    //                     as: 'interests'
    //                 }
    //             },
    //             {
    //                 $project: {
    //                     visibility: 1,
    //                     isAnonymous: 1,
    //                     allowComments: 1,
    //                     bgImageUrl: 1,
    //                     endDate: 1,
    //                     status: 1,
    //                     createdByUsername: 1,
    //                     createdByUserId: 1,
    //                     createdByUserProfilePicUrl: 1,
    //                     interests: '$interests.name',
    //                     questions: 1,
    //                     displayResultMode: 1,
    //                     createdAt: 1,
    //                     updatedBy: 1,
    //                     isDeleted: 1,
    //                     mediaType: 1,
    //                     sharedWithUsersCount: 1,
    //                     votes: { $size: { $ifNull: ['$responses', []] } }, // Assuming responses are stored in the `responses` array
    //                     votersCount: 1,
    //                     voterImages: [
    //                         'https://www.shutterstock.com/image-photo/image-handsome-smiling-young-african-260nw-722913181.jpg',
    //                         'https://t4.ftcdn.net/jpg/02/32/98/33/360_F_232983351_z5CAl79bHkm6eMPSoG7FggQfsJLxiZjY.jpg',
    //                         'https://st2.depositphotos.com/4431055/7492/i/950/depositphotos_74925449-stock-photo-men-human-face-smiling.jpg'
    //                     ]
    //                 }
    //             }
    //         ];

    //         // Add sorting for trending polls
    //         if (trendingPolls === 'true') {
    //             aggregationPipeline.push({ $sort: { votersCount: -1, createdAt: -1 } });
    //         } else {
    //             aggregationPipeline.push({ $sort: { createdAt: -1 } });
    //         }

    //         // Pagination logic
    //         if (paginateOptions.paginate) {
    //             aggregationPipeline.push(
    //                 { $skip: (paginateOptions.page - 1) * paginateOptions.limit },
    //                 { $limit: paginateOptions.limit }
    //             );
    //         } else {
    //             aggregationPipeline.push({ $limit: 500 });
    //         }

    //         let results = await this.pollModel.aggregate(aggregationPipeline);
    //         const count = await this.pollModel.countDocuments(matchConditions);

    //         const pollResponsesObj: any = {};

    //         // Using Promise.all to fetch responses concurrently
    //         await Promise.all(
    //             results.map(async (poll) => {
    //                 const pollId = poll._id;
    //                 const pollResponsesCount = await this.pollResponseModel.countDocuments({
    //                     pollId,
    //                     userId: currentUserId
    //                 });
    //                 pollResponsesObj[pollId.toString()] = pollResponsesCount; // Store responses for each pollId
    //             })
    //         );

    //         results = results
    //             .filter((poll) => poll)
    //             .map((poll) => {
    //                 poll.id = poll._id;
    //                 poll.isAnswered = pollResponsesObj[poll._id.toString()] > 0;

    //                 return poll;
    //             });

    //         return {
    //             docs: results,
    //             page: paginateOptions.page,
    //             limit: paginateOptions.limit,
    //             totalPages: Math.ceil(count / paginateOptions.limit),
    //             totalResults: count
    //         };
    //     } catch (error) {
    //         throw new RpcException(error);
    //     }
    // }

    async myPolls(queryParams: any, userId: string, currentUserId: string, paginateOptions: any) {
        try {
            const { isActive = false, trendingPolls = false } = queryParams;
            const currentDate = new Date();

            // Initialize the match conditions
            const matchConditions: any = {
                isActive: true,
                isDeleted: false,
                createdByUserId: mongoose.Types.ObjectId.createFromHexString(userId)
            };

            // If currentUserId and userId are different, only show published polls
            if (currentUserId.toString() !== userId.toString()) {
                matchConditions['status'] = PollStatuses.UNDER_REVIEW;
                // matchConditions['status'] = PollStatuses.PUBLISHED; // TODO: undo comment and remove above line
                matchConditions['isAnonymous'] = false;

                matchConditions['$or'] = [
                    { visibility: VisibilityTypes.PUBLIC },
                    {
                        // Only include private polls shared with the current user
                        visibility: VisibilityTypes.PRIVATE,
                        _id: {
                            $in: await this.sharedPollModel
                                .find({
                                    sharedWith: mongoose.Types.ObjectId.createFromHexString(currentUserId),
                                    isDeleted: false
                                })
                                .distinct('pollId')
                        }
                    }
                ];
            }

            // If isActive is true, add endDate filter
            if (isActive === 'true') {
                matchConditions['endDate'] = { $gt: currentDate };
            }

            // Build the aggregation pipeline
            const aggregationPipeline: any = [
                { $match: matchConditions },
                {
                    $lookup: {
                        from: 'interests',
                        localField: 'interests',
                        foreignField: '_id',
                        as: 'interests'
                    }
                },
                {
                    $project: {
                        visibility: 1,
                        isAnonymous: 1,
                        allowComments: 1,
                        bgImageUrl: 1,
                        endDate: 1,
                        status: 1,
                        createdByUsername: 1,
                        createdByUserId: 1,
                        createdByUserProfilePicUrl: 1,
                        interests: '$interests.name',
                        questions: 1,
                        displayResultMode: 1,
                        createdAt: 1,
                        updatedBy: 1,
                        isDeleted: 1,
                        mediaType: 1,
                        sharedWithUsersCount: 1,
                        votes: 1, // Assuming responses are stored in the `responses` array
                        votersCount: 1,
                        isClosed: 1,
                        voterImages: [
                            'https://www.shutterstock.com/image-photo/image-handsome-smiling-young-african-260nw-722913181.jpg',
                            'https://t4.ftcdn.net/jpg/02/32/98/33/360_F_232983351_z5CAl79bHkm6eMPSoG7FggQfsJLxiZjY.jpg',
                            'https://st2.depositphotos.com/4431055/7492/i/950/depositphotos_74925449-stock-photo-men-human-face-smiling.jpg'
                        ]
                    }
                }
            ];

            // Add sorting for trending polls
            if (trendingPolls === 'true') {
                aggregationPipeline.push({ $sort: { votersCount: -1, createdAt: -1 } });
            } else {
                aggregationPipeline.push({ $sort: { createdAt: -1 } });
            }

            // Pagination logic
            if (paginateOptions.paginate) {
                aggregationPipeline.push(
                    { $skip: (paginateOptions.page - 1) * paginateOptions.limit },
                    { $limit: paginateOptions.limit }
                );
            } else {
                aggregationPipeline.push({ $limit: 500 });
            }

            let results = await this.pollModel.aggregate(aggregationPipeline);
            const count = await this.pollModel.countDocuments(matchConditions);

            const pollResponsesObj: any = {};

            // Using Promise.all to fetch responses concurrently
            await Promise.all(
                results.map(async (poll) => {
                    const pollId = poll._id;
                    const pollResponsesCount = await this.pollResponseModel.countDocuments({
                        pollId,
                        userId: currentUserId
                    });
                    pollResponsesObj[pollId.toString()] = pollResponsesCount; // Store responses for each pollId
                })
            );

            const bookmarkedPollObj: any = {};
            await Promise.all(
                results.map(async (poll) => {
                    const pollId = poll._id;
                    const bookmarkedPoll = await this.bookmarkPollModel.findOne({
                        pollId,
                        bookmarkedBy: currentUserId
                    });
                    bookmarkedPollObj[pollId.toString()] = bookmarkedPoll?._id ? true : false;
                })
            );

            const pollResponseHistory: any = {};
            await Promise.all(
                results.map(async (poll) => {
                    const pollId = poll._id;

                    const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                        pollId,
                        userId: currentUserId,
                        isDeleted: false
                    });
                    pollResponseHistory[pollId.toString()] = pollResponseHistoryCount; // Store responses for each pollId
                })
            );

            const pollIds = results.map((poll) => poll._id);

            const allPollResponses: any = {};
            // Using Promise.all to fetch responses concurrently
            await Promise.all(
                pollIds.map(async (pollId) => {
                    const pollResponses = await this.pollResponseModel.find({ pollId, userId: currentUserId });
                    allPollResponses[pollId.toString()] = pollResponses; // Store responses for each pollId
                })
            );

            // First, find all the group memberships for the user
            const userGroups = await this.groupMemberModel
                .find({ userId: currentUserId, isActive: true, isDeleted: false }) // Ensure user is active and not deleted
                .select('groupId') // Select only the groupId field
                .exec();

            // Extract the group IDs that the user is a member of
            const userGroupIds = userGroups.map((membership) => membership.groupId);
            const userGroupIdsString = userGroupIds.map((id) => id.toString());

            const groupSharedPolls = await this.groupPollModel
                .find({ pollId: { $in: pollIds }, isDeleted: false }) // Filter by pollId and user's groupIds
                .populate({
                    path: 'groupId',
                    populate: {
                        path: 'groupInterests',
                        select: '_id name'
                    }
                })
                .exec();

            results = results
                .filter((poll) => poll)
                .map((poll) => {
                    poll.id = poll._id;
                    poll.isAnswered = pollResponsesObj[poll._id.toString()] > 0;
                    poll.isSaved = bookmarkedPollObj[poll._id.toString()];
                    poll.allowChangeMyMind = pollResponseHistory[poll._id.toString()] < 2;
                    poll.commentCount = 0;

                    if (!poll['votes']) {
                        poll['votes'] = 0;
                    }
                    if (!poll['votersCount']) {
                        poll['votersCount'] = 0;
                    }
                    if (!poll['sharedWithUsersCount']) {
                        poll['sharedWithUsersCount'] = 0;
                    }

                    const pollResponses = allPollResponses[poll._id.toString()];
                    if (poll?.questions?.length) {
                        poll.questions = poll.questions.map((question: any) => {
                            const options = question?.options || [];

                            // If poll type is SINGLE_CHOICE or THIS_THAT
                            if (
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.THIS_THAT
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionId = pollResponse?.optionId;

                                // Map options to add isSelected field
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: option.id === optionId
                                }));
                            }

                            // If poll type is MULTIPLE_CHOICE or DATE
                            if (
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const optionIds = pollResponses.map((response) => response?.optionId);

                                // Map options to add isSelected field for multiple choice
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: optionIds.includes(option.id)
                                }));
                            }

                            // If poll type is SLIDER or LIGHT_METER
                            if (
                                question?.type === QuestionTypes.SLIDER ||
                                question?.type === QuestionTypes.LIGHT_METER
                            ) {
                                pollResponses?.length &&
                                    pollResponses[0] &&
                                    (question.sliderValue = pollResponses[0]?.sliderValue || 0);
                            }

                            // If poll type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                question.options = options.map((option) => {
                                    const pollResponse = pollResponses.find(
                                        (response) => response.optionId === option.id
                                    );
                                    return {
                                        ...option,
                                        selectedRank: pollResponse?.order || null
                                    };
                                });
                            }

                            return question;
                        });
                    }

                    const groupDetails: any = (
                        groupSharedPolls.filter(
                            (groupPoll) => groupPoll?.pollId?.toString() === poll?._id?.toString()
                        ) || []
                    )
                        .map((groupPoll) => groupPoll?.groupId)
                        .filter((group) => group)
                        .map((group: any) => {
                            return {
                                ...group.toObject(),
                                isGroupMember: userGroupIdsString.includes(group?._id?.toString())
                            };
                        })
                        .sort((a, b) => {
                            // Sort by isGroupMember with `true` values first
                            return a.isGroupMember === b.isGroupMember ? 0 : a.isGroupMember ? -1 : 1;
                        });

                    poll.groups = groupDetails || [];

                    return poll;
                });

            return {
                docs: results,
                page: paginateOptions.page,
                limit: paginateOptions.limit,
                totalPages: Math.ceil(count / paginateOptions.limit),
                totalResults: count
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }
    async myPollsV2(queryParams: any, userId: string, currentUserId: string, paginateOptions: any) {
        try {
            const { isActive = false, trendingPolls = false } = queryParams;
            const currentDate = new Date();

            // Initialize the match conditions
            let matchConditions: any = {
                // isActive: true,
                // isDeleted: false,
                // createdByUserId: mongoose.Types.ObjectId.createFromHexString(userId)
            };

            // If currentUserId and userId are different, only show published polls
            if (currentUserId.toString() !== userId.toString()) {
                matchConditions['status'] = PollStatuses.UNDER_REVIEW;
                // matchConditions['status'] = PollStatuses.PUBLISHED; // TODO: undo comment and remove above line
                matchConditions['isAnonymous'] = false;

                // get all public group polls created by user
                const groupsCreatedByUser = await this.groupModel.find({
                    createdBy: userId,
                    groupType: VisibilityTypes.PUBLIC,
                    isDeleted: false
                });
                const groupIds = groupsCreatedByUser.map((group) => group._id);
                const groupPolls = await this.groupPollModel.find({ groupId: { $in: groupIds }, isDeleted: false });
                const groupPollIds = groupPolls.map((groupPoll) => groupPoll.pollId);
                console.log({ groupPollIds });

                // get all private polls created by profile user and share with current user
                const sharedPolls = await this.sharedPollModel.find({
                    sharedWith: mongoose.Types.ObjectId.createFromHexString(currentUserId),
                    sharedBy: mongoose.Types.ObjectId.createFromHexString(userId),
                    isDeleted: false
                });
                const sharedPollIds = sharedPolls.map((sharedPoll) => sharedPoll.pollId);
                console.log({ sharedPollIds });

                const allPollIds = [...groupPollIds, ...sharedPollIds];
                // const allPollObjectIds = allPollIds.map((pollId) =>
                //     mongoose.Types.ObjectId.createFromHexString(pollId)
                // );
                // console.log('---------');

                matchConditions['$or'] = [
                    {
                        visibility: VisibilityTypes.PUBLIC,
                        isActive: true,
                        isDeleted: false,
                        createdByUserId: mongoose.Types.ObjectId.createFromHexString(userId)
                    },
                    {
                        _id: { $in: allPollIds }
                    }
                ];
            } else {
                matchConditions = {
                    isActive: true,
                    isDeleted: false,
                    createdByUserId: mongoose.Types.ObjectId.createFromHexString(userId)
                };
            }

            // If isActive is true, add endDate filter
            if (isActive === 'true') {
                matchConditions['endDate'] = { $gt: currentDate };
            }
            // Build the aggregation pipeline
            const aggregationPipeline: any = [
                { $match: matchConditions },
                {
                    $lookup: {
                        from: 'interests',
                        localField: 'interests',
                        foreignField: '_id',
                        as: 'interests'
                    }
                },
                {
                    $project: {
                        visibility: 1,
                        isAnonymous: 1,
                        allowComments: 1,
                        bgImageUrl: 1,
                        endDate: 1,
                        status: 1,
                        createdByUsername: 1,
                        createdByUserId: 1,
                        createdByUserProfilePicUrl: 1,
                        interests: 1,
                        questions: 1,
                        displayResultMode: 1,
                        createdAt: 1,
                        updatedBy: 1,
                        isDeleted: 1,
                        mediaType: 1,
                        sharedWithUsersCount: 1,
                        votes: 1, // Assuming responses are stored in the `responses` array
                        votersCount: 1,
                        isClosed: 1
                        // voterImages: [
                        //     'https://www.shutterstock.com/image-photo/image-handsome-smiling-young-african-260nw-722913181.jpg',
                        //     'https://t4.ftcdn.net/jpg/02/32/98/33/360_F_232983351_z5CAl79bHkm6eMPSoG7FggQfsJLxiZjY.jpg',
                        //     'https://st2.depositphotos.com/4431055/7492/i/950/depositphotos_74925449-stock-photo-men-human-face-smiling.jpg'
                        // ]
                    }
                }
            ];
            // Add sorting for trending polls
            if (trendingPolls === 'true') {
                aggregationPipeline.push({ $sort: { votersCount: -1, createdAt: -1 } });
            } else {
                aggregationPipeline.push({ $sort: { createdAt: -1 } });
            }

            // Pagination logic
            if (paginateOptions.paginate) {
                aggregationPipeline.push(
                    { $skip: (paginateOptions.page - 1) * paginateOptions.limit },
                    { $limit: paginateOptions.limit }
                );
            } else {
                aggregationPipeline.push({ $limit: 500 });
            }

            let results = await this.pollModel.aggregate(aggregationPipeline);
            const count = await this.pollModel.countDocuments(matchConditions);

            const pollResponsesObj: any = {};

            // Using Promise.all to fetch responses concurrently
            await Promise.all(
                results.map(async (poll) => {
                    const pollId = poll._id;
                    const pollResponsesCount = await this.pollResponseModel.countDocuments({
                        pollId,
                        userId: currentUserId
                    });
                    pollResponsesObj[pollId.toString()] = pollResponsesCount; // Store responses for each pollId
                })
            );

            const bookmarkedPollObj: any = {};
            await Promise.all(
                results.map(async (poll) => {
                    const pollId = poll._id;
                    const bookmarkedPoll = await this.bookmarkPollModel.findOne({
                        pollId,
                        bookmarkedBy: currentUserId
                    });
                    bookmarkedPollObj[pollId.toString()] = bookmarkedPoll?._id ? true : false;
                })
            );

            const pollResponseHistory: any = {};
            await Promise.all(
                results.map(async (poll) => {
                    const pollId = poll._id;

                    const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                        pollId,
                        userId: currentUserId,
                        isDeleted: false
                    });
                    pollResponseHistory[pollId.toString()] = pollResponseHistoryCount; // Store responses for each pollId
                })
            );

            const pollIds = results.map((poll) => poll._id);

            const allPollResponses: any = {};
            // Using Promise.all to fetch responses concurrently
            await Promise.all(
                pollIds.map(async (pollId) => {
                    const pollResponses = await this.pollResponseModel.find({ pollId, userId: currentUserId });
                    allPollResponses[pollId.toString()] = pollResponses; // Store responses for each pollId
                })
            );

            // First, find all the group memberships for the user
            const userGroups = await this.groupMemberModel
                .find({ userId: currentUserId, isActive: true, isDeleted: false }) // Ensure user is active and not deleted
                .select('groupId') // Select only the groupId field
                .exec();

            // Extract the group IDs that the user is a member of
            const userGroupIds = userGroups.map((membership) => membership.groupId);
            const userGroupIdsString = userGroupIds.map((id) => id.toString());

            const groupSharedPolls = await this.groupPollModel
                .find({ pollId: { $in: pollIds }, isDeleted: false }) // Filter by pollId and user's groupIds
                .populate({
                    path: 'groupId',
                    populate: {
                        path: 'groupInterests',
                        select: '_id name'
                    }
                })
                .exec();

            const user = await this.userService.getUserById(userId);
            const userInterests = user?.interests || [];
            const userInterestNames = userInterests.map((interest: any) => interest.name); // Get user interest names

            results = results
                .filter((poll) => poll)
                .map((poll) => {
                    poll.id = poll._id;
                    poll.isAnswered = pollResponsesObj[poll._id.toString()] > 0;
                    poll.isSaved = bookmarkedPollObj[poll._id.toString()];
                    poll.allowChangeMyMind = pollResponseHistory[poll._id.toString()] < 2;
                    poll.commentCount = 0;

                    if (!poll['votes']) {
                        poll['votes'] = 0;
                    }
                    if (!poll['votersCount']) {
                        poll['votersCount'] = 0;
                    }
                    if (!poll['sharedWithUsersCount']) {
                        poll['sharedWithUsersCount'] = 0;
                    }

                    poll['interests'] = (poll['interests'] || [])
                        .map((interest) => {
                            return {
                                id: interest._id,
                                name: interest.name,
                                isUserInterest: userInterestNames.includes(interest.name)
                            };
                        })
                        .sort((a, b) => {
                            // Sort by isGroupMember with `true` values first
                            return a.isUserInterest === b.isUserInterest ? 0 : a.isUserInterest ? -1 : 1;
                        });

                    const pollResponses = allPollResponses[poll._id.toString()];
                    if (poll?.questions?.length) {
                        poll.questions = poll.questions.map((question: any) => {
                            const options = question?.options || [];

                            // If poll type is SINGLE_CHOICE or THIS_THAT
                            if (
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.THIS_THAT
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionId = pollResponse?.optionId;

                                // Map options to add isSelected field
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: option.id === optionId
                                }));
                            }

                            // If poll type is MULTIPLE_CHOICE or DATE
                            if (
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const optionIds = pollResponses.map((response) => response?.optionId);

                                // Map options to add isSelected field for multiple choice
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: optionIds.includes(option.id)
                                }));
                            }

                            // If poll type is SLIDER or LIGHT_METER
                            if (
                                question?.type === QuestionTypes.SLIDER ||
                                question?.type === QuestionTypes.LIGHT_METER
                            ) {
                                pollResponses?.length &&
                                    pollResponses[0] &&
                                    (question.sliderValue = pollResponses[0]?.sliderValue || 0);
                            }

                            // If poll type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                question.options = options.map((option) => {
                                    const pollResponse = pollResponses.find(
                                        (response) => response.optionId === option.id
                                    );
                                    return {
                                        ...option,
                                        selectedRank: pollResponse?.order || null
                                    };
                                });
                            }

                            return question;
                        });
                    }

                    const groupDetails: any = (
                        groupSharedPolls.filter(
                            (groupPoll) => groupPoll?.pollId?.toString() === poll?._id?.toString()
                        ) || []
                    )
                        .map((groupPoll) => groupPoll?.groupId)
                        .filter((group) => group)
                        .map((group: any) => {
                            return {
                                ...group.toObject(),
                                isGroupMember: userGroupIdsString.includes(group?._id?.toString())
                            };
                        });

                    poll.groups = groupDetails || [];

                    return poll;
                });

            return {
                docs: results,
                page: paginateOptions.page,
                limit: paginateOptions.limit,
                totalPages: Math.ceil(count / paginateOptions.limit),
                totalResults: count
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async closePoll(pollId: string, userId: string) {
        try {
            // Check poll id is valid or not
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.pattern.base'));
            }

            // Find the poll to ensure it exists and isn't already closed or deleted
            const poll = await this.pollModel.findOne({
                _id: pollId,
                isDeleted: false,
                isClosed: false
            });

            if (!poll) {
                throw new UnprocessableEntityException('Poll not found or already closed');
            }

            if (poll?.createdByUserId != userId) {
                throw new UnprocessableEntityException('Only poll owner can close the poll');
            }

            // Update the poll to set it as closed
            const result = await this.pollModel.updateOne(
                { _id: pollId },
                {
                    $set: {
                        isClosed: true
                    }
                }
            );

            if (result.modifiedCount === 0) {
                throw new UnprocessableEntityException('Failed to close the poll');
            }

            return { id: poll._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    @Cron('*/15 * * * *', {
        timeZone: 'UTC' // Ensure the cron job runs in UTC every 15 mins
    })
    // @Cron(CronExpression.EVERY_5_SECONDS)
    async closePolls() {
        try {
            // Get the current date in UTC
            const nowUTC = new Date(
                Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate())
            );

            // Calculate the end of the previous day in UTC (23:59:59.999)
            // const endOfPreviousDayUTC = new Date(
            //     Date.UTC(
            //         nowUTC.getUTCFullYear(),
            //         nowUTC.getUTCMonth(),
            //         nowUTC.getUTCDate() - 1, // Subtract 1 day
            //         23,
            //         59,
            //         59,
            //         999
            //     )
            // );

            // Find polls that are and not closed
            const polls = await this.pollModel.find({
                isClosed: false,
                endDate: { $lte: nowUTC }
            });

            // Close each poll through array of ids
            const pollIds = polls.map((poll) => poll._id);

            // Update the polls to set them as closed
            await this.pollModel.updateMany(
                { _id: { $in: pollIds } },
                {
                    $set: {
                        isClosed: true
                    }
                }
            );
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async findPromotedPolls(pollId: string, paginateOptions: { page: number; limit: number }) {
        try {
            // Fetch all promoted polls
            const allPromotedPolls: any[] = await this.pollModel.find({ isPromoted: true });

            // Find the index of the specified pollId
            const pollIndex = allPromotedPolls.findIndex((poll) => poll._id.toString() === pollId);

            // If the pollId is found, move it to the first position
            if (pollIndex !== -1) {
                const [specifiedPoll] = allPromotedPolls.splice(pollIndex, 1); // Remove the specified poll
                allPromotedPolls.unshift(specifiedPoll);
            }

            // Implement pagination
            const totalResults = allPromotedPolls.length;
            const startIndex = (paginateOptions.page - 1) * paginateOptions.limit;
            const endIndex = startIndex + paginateOptions.limit;

            const paginatedPolls = allPromotedPolls.slice(startIndex, endIndex);

            // You can also include additional details such as totalPages if needed
            const totalPages = Math.ceil(totalResults / paginateOptions.limit);

            return {
                docs: paginatedPolls,
                page: paginateOptions.page,
                limit: paginateOptions.limit,
                totalPages,
                totalResults
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
