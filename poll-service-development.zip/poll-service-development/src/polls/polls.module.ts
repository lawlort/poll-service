import { forwardRef, Module } from '@nestjs/common';
import { PollsService } from './polls.service';
import { PollsController } from './polls.controller';
import { MongooseModule } from '@nestjs/mongoose';
import PollSchema, { Poll } from './schemas/poll.schema';
import { LocationsModule } from 'src/locations/locations.module';
import PollResponseSchema, { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
import PollInsightsSchema, { PollInsight } from 'src/poll-insights/schemas/poll-insight.schema';
import PollCommentSchema, { PollComment } from 'src/poll-comments/schemas/poll-comment.schema';
import { InterestsModule } from 'src/interests/interests.module';
import { PollsControllerV2 } from './polls-v2/polls.controller';
import { PollsServiceV2 } from './polls-v2/polls.service';
import MediaMappingSchema, { MediaMapping } from 'src/media-mapping/schemas/media-mapping.schema';
import PollGuidMappingSchema, { PollGuidMapping } from 'src/poll-guid-mapping/schemas/poll-guid-mapping.schema';
import PollResponseHistorySchema, {
    PollResponseHistory
} from 'src/poll-response-history/schemas/poll-response-history.schema';
import BookmarkedPollSchema, { BookmarkedPoll } from 'src/bookmarked-polls/schemas/bookmarked-poll.schema';
import { PollInsightsModule } from 'src/poll-insights/poll-insights.module';
import GroupPollSchema, { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import { SharedPollsModule } from 'src/shared-polls/shared-polls.module';
import { GroupPollsModule } from 'src/group-polls/group-polls.module';
import GroupMemberSchema, { GroupMember } from 'src/group-members/schemas/group-members.schema';
import FollowRequestSchema, { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';
import { PollsControllerV3 } from './polls-v3/polls.controller';
import { PollsServiceV3 } from './polls-v3/polls.service';
import { SharedPollWithUsersModule } from 'src/shared-poll-with-users/shared-poll-with-users.module';
import SharedPollWithUsersSchema, {
    SharedPollWithUsers
} from 'src/shared-poll-with-users/schemas/shared-poll-with-users.schema';
import LocationSchema, { Location } from 'src/locations/schemas/location.schema';
import ReportedPollCommentSchema, {
    ReportedPollComment
} from 'src/reported-poll-comments/schemas/reported-poll-comment.schema';
import SharedPollSchema, { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import ReportedPollSchema, { ReportedPoll } from 'src/reported-polls/schemas/reported-poll.schema';
import { PollsControllerV4 } from './polls-v4/polls.controller';
import { PollsServiceV4 } from './polls-v4/polls.service';
import { UsersModule } from 'src/users/users.module';
import GroupSchema, { Group } from 'src/groups/schemas/group.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            {
                name: Poll.name,
                schema: PollSchema
            },
            {
                name: PollResponse.name,
                schema: PollResponseSchema
            },
            {
                name: PollComment.name,
                schema: PollCommentSchema
            },
            {
                name: PollInsight.name,
                schema: PollInsightsSchema
            },
            {
                name: MediaMapping.name,
                schema: MediaMappingSchema
            },
            {
                name: PollGuidMapping.name,
                schema: PollGuidMappingSchema
            },
            {
                name: PollResponseHistory.name,
                schema: PollResponseHistorySchema
            },
            {
                name: BookmarkedPoll.name,
                schema: BookmarkedPollSchema
            },
            {
                name: GroupPoll.name,
                schema: GroupPollSchema
            },
            { name: GroupMember.name, schema: GroupMemberSchema },
            { name: FollowRequest.name, schema: FollowRequestSchema },
            { name: SharedPollWithUsers.name, schema: SharedPollWithUsersSchema },
            { name: Location.name, schema: LocationSchema },
            { name: ReportedPollComment.name, schema: ReportedPollCommentSchema },
            { name: SharedPoll.name, schema: SharedPollSchema },
            { name: ReportedPoll.name, schema: ReportedPollSchema },
            { name: Group.name, schema: GroupSchema }
        ]),
        LocationsModule,
        InterestsModule,
        forwardRef(() => PollInsightsModule),
        SharedPollsModule,
        GroupPollsModule,
        SharedPollWithUsersModule,
        UsersModule
    ],
    controllers: [PollsController, PollsControllerV2, PollsControllerV3, PollsControllerV4],
    providers: [PollsService, PollsServiceV2, PollsServiceV3, PollsServiceV4],
    exports: [PollsService]
})
export class PollsModule {}
