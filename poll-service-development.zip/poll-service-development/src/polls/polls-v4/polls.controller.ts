import { Controller, Body } from '@nestjs/common';
import { PollsServiceV4 } from './polls.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_CREATE_POLL_V4 } from 'src/utils/constants/commands';

@Controller('polls')
export class PollsControllerV4 {
    constructor(private readonly pollsService: PollsServiceV4) {}

    @MessagePattern({ cmd: CMD_CREATE_POLL_V4 })
    async createV4(@Body() payload) {
        const { body = {}, user = {}, ip = '', token = '' } = payload;
        return await this.pollsService.create(body, user, ip, token);
    }
}
