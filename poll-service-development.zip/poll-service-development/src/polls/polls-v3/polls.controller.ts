import { Controller, Body } from '@nestjs/common';
import { PollsServiceV3 } from './polls.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_CREATE_POLL_V3 } from 'src/utils/constants/commands';

@Controller('polls')
export class PollsControllerV3 {
    constructor(private readonly pollsService: PollsServiceV3) {}

    @MessagePattern({ cmd: CMD_CREATE_POLL_V3 })
    async createV3(@Body() payload) {
        const { body = {}, user = {}, ip = '', token = '' } = payload;
        return await this.pollsService.create(body, user, ip, token);
    }
}
