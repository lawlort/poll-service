import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreatePollSchema } from './dto/createPollSchema';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { globalErrorObj } from 'src/utils/common/globalErrorRes';
import { LocationsService } from 'src/locations/locations.service';
import { InterestsService } from 'src/interests/interests.service';
import { LocationEventType } from 'src/locations/schemas/location.schema';
import { PollGuidMapping, PollGuidMappingDocument } from 'src/poll-guid-mapping/schemas/poll-guid-mapping.schema';
import { MediaMapping } from 'src/media-mapping/schemas/media-mapping.schema';
import { Poll, QuestionTypes, VisibilityTypes } from '../schemas/poll.schema';
import { GroupPollsService } from 'src/group-polls/group-polls.service';
import { FollowRequestStatus } from 'src/utils/constants/string';
import { GroupMember } from 'src/group-members/schemas/group-members.schema';
import { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';
import { SharedPollWithUsersService } from 'src/shared-poll-with-users/shared-poll-with-users.service';
import { PollInsightsService } from 'src/poll-insights/poll-insights.service';
import axios from 'axios';

@Injectable()
export class PollsServiceV3 {
    constructor(
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        @InjectModel(PollGuidMapping.name) private readonly pollGuidMappingModel: Model<PollGuidMappingDocument>,
        @InjectModel(MediaMapping.name) private readonly mediaMappingModel: Model<MediaMapping>,
        private locationService: LocationsService,
        private interstsService: InterestsService,
        private groupPollService: GroupPollsService,
        private sharedPollWithUsersService: SharedPollWithUsersService,
        @InjectModel(GroupMember.name) private groupMemberModel: Model<GroupMember>,
        @InjectModel(FollowRequest.name) private followRequestModel: Model<FollowRequest>,
        private pollInsightsService: PollInsightsService
    ) {}

    async create(createPollData, user: any, ip: string, token: string) {
        try {
            // TODO: Manage private poll in later sprint

            if (!user?.id) {
                throw new NotFoundException('User not found');
            }
            validateSchema(CreatePollSchema, createPollData);

            if (createPollData?.visibility === VisibilityTypes.PRIVATE) {
                if (!createPollData?.shareWithAllFollowers) {
                    if (!createPollData?.shareWithGroupIds?.length && !createPollData?.shareWithUserIds?.length) {
                        throw new BadRequestException('Share with group or user required');
                    }
                }
            }

            // for date poll check value of all options are valid date
            if (createPollData?.questions?.length) {
                for (const question of createPollData.questions) {
                    if (question?.type === QuestionTypes.DATE) {
                        for (const option of question.options) {
                            if (isNaN(Date.parse(option.value))) {
                                throw new BadRequestException(
                                    globalErrorObj('Invalid option date value', 'value', 'string.pattern.base')
                                );
                            }
                        }
                        // get max id from options
                        if (question?.options?.length) {
                            const maxId = Math.max(...question.options.map((option) => option.id));
                            question.options.push({ id: maxId + 1, value: 'None of these' });
                        }
                    }
                }
            }

            // check interest exists in db
            const allInterests = await this.interstsService.findAll();
            const interests: string[] = allInterests.map((interest) => (interest?.id || '').toString());
            const interestIds = createPollData.interests || [];
            for (const interestId of interestIds) {
                if (!interests.includes(interestId)) {
                    throw new NotFoundException('Interest not found');
                }
            }

            createPollData.createdByUsername = user?.username || '';
            createPollData.createdByUserId = user?.id || '';
            createPollData.createdByUserProfilePicUrl = user?.profilePicUrl || '';

            // check media mapping and add converted url
            const mediaMappings = await this.mediaMappingModel.find({ guid: createPollData?.pollGuid }).lean();

            if (mediaMappings?.length) {
                if (createPollData?.bgImageUrl) {
                    const mediaMapping = mediaMappings.find((media) => media.originalUrl === createPollData.bgImageUrl);
                    if (mediaMapping) {
                        createPollData.convertedMediaUrl = mediaMapping.convertedUrl;
                    }
                }

                // check for all questions options
                for (const question of createPollData?.questions || []) {
                    for (const option of question?.options || []) {
                        const mediaMapping = mediaMappings.find((media) => media.originalUrl === option.mediaUrl);
                        if (mediaMapping) {
                            option.convertedMediaUrl = mediaMapping.convertedUrl;
                        }
                    }
                }
            }

            const poll = await this.pollModel.create(createPollData);
            await poll.save();

            // get location details
            const locationDetails: any = await this.locationService.getLocationDetails(ip);

            if (!(locationDetails?.data?.status === 'fail')) {
                const locationData = locationDetails?.data || {};
                const locationPayload = { eventType: LocationEventType.CREATE_POLL, pollId: poll._id, ...locationData };
                await this.locationService.create(locationPayload);
            }

            await this.pollGuidMappingModel.create({
                pollId: poll._id,
                pollGuid: createPollData.pollGuid
            });

            // share poll with groups and users

            // if (createPollData?.visibility === VisibilityTypes.PRIVATE) {
            //     let uniqueUserIds = [];
            //     if (createPollData?.shareWithGroupIds?.length) {
            //         uniqueUserIds = await this.groupMemberModel.distinct('userId', {
            //             groupId: { $in: createPollData.shareWithGroupIds || [] }
            //         });
            //     }

            //     const uniquUserIdStrings = uniqueUserIds.map((id) => id.toString());

            //     let followersIds = [];
            //     if (createPollData.shareWithAllFollowers) {
            //         // Fetch all followers for the user in one go
            //         const followers = await this.followRequestModel
            //             .find({ receiverId: user.id, status: FollowRequestStatus.ACCEPTED })
            //             .select('senderId') // Only fetch senderId to save bandwidth
            //             .exec();

            //         followersIds = followers.map((f) => f.senderId.toString());
            //     }

            //     const uniqueUserIdsToShareWith = Array.from(
            //         new Set([...uniquUserIdStrings, ...followersIds, ...(createPollData.shareWithUserIds || [])])
            //     );

            //     await this.pollModel.updateOne(
            //         { _id: poll._id },
            //         { sharedWithUsersCount: uniqueUserIdsToShareWith.length },
            //         { new: true }
            //     );

            //     this.groupPollService.sharePollWithUniqueUsers(
            //         poll._id.toString(),
            //         user.id,
            //         createPollData?.shareWithGroupIds || [],
            //         uniqueUserIdsToShareWith || []
            //     );
            // } else if (createPollData?.visibility === VisibilityTypes.PUBLIC) {
            //     // entry in group poll table
            //     if (createPollData?.shareWithGroupIds?.length) {
            //         this.groupPollService.sharePollWithGroups(
            //             poll._id.toString(),
            //             user.id,
            //             createPollData.shareWithGroupIds
            //         );
            //     }
            // }

            // share poll with users and followers

            this.sharedPollWithUsersService.sharePollWithUsers(
                poll._id.toString(),
                user.id,
                createPollData?.shareWithUserIds || [],
                createPollData?.shareWithAllFollowers
            );

            // share poll with groups
            this.groupPollService.sharePollWithGroups(
                poll._id.toString(),
                user.id,
                createPollData?.shareWithGroupIds || []
            );

            if (createPollData?.visibility === VisibilityTypes.PRIVATE) {
                let followersIds = [];
                let uniqueUserIdsOfGroups = [];
                if (createPollData?.shareWithAllFollowers) {
                    // Fetch all followers for the user in one go
                    const followers = await this.followRequestModel
                        .find({ receiverId: user.id, status: FollowRequestStatus.ACCEPTED, isDeleted: false })
                        .select('senderId') // Only fetch senderId to save bandwidth
                        .exec();

                    followersIds = followers.map((f) => f.senderId.toString());
                }

                // get unique members from all groups
                if (createPollData?.shareWithGroupIds?.length) {
                    uniqueUserIdsOfGroups = await this.groupMemberModel.distinct('userId', {
                        groupId: { $in: createPollData.shareWithGroupIds || [] }
                    });
                }
                const uniquUserIdStrings = uniqueUserIdsOfGroups.map((id) => id.toString());

                const uniqueUserIdsToShareWith = Array.from(
                    new Set([...uniquUserIdStrings, ...followersIds, ...(createPollData.shareWithUserIds || [])])
                );

                await this.pollModel.updateOne(
                    { _id: poll._id },
                    { sharedWithUsersCount: uniqueUserIdsToShareWith.length },
                    { new: true }
                );

                this.groupPollService.sharePollWithUniqueUsers(
                    poll._id.toString(),
                    user.id,
                    uniqueUserIdsToShareWith || []
                );
            }

            // prepare feed
            axios.get(`${process.env.API_GATEWAY_BASEURL}/v1/users/prepare-feed`, {
                headers: {
                    authorization: `Bearer ${token}`
                }
            });

            // TODO: Create empty poll insights
            this.pollInsightsService.createEmptyPollInsight(poll._id.toString());

            return { id: poll._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
