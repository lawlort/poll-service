import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument, Schema as mongooseSchema, Types } from 'mongoose';
import * as mongoosePaginate from 'mongoose-aggregate-paginate-v2';
import { Interest } from 'src/interests/schemas/interest.schema';

export enum VisibilityTypes {
    PRIVATE = 'private',
    PUBLIC = 'public'
}

export enum QuestionTypes {
    THIS_THAT = 'this_that',
    SINGLE_CHOICE = 'single_choice',
    SLIDER = 'slider',
    LIGHT_METER = 'light_meter',
    MULTIPLE_CHOICE = 'multiple_choice',
    DATE = 'date',
    RANKING = 'ranking'
}

export enum PollStatuses {
    DRAFT = 'draft',
    UNDER_REVIEW = 'under review',
    PUBLISHED = 'published',
    REJECTED = 'rejected'
}

export enum DisplayResultModes {
    IMMEDIATE = 'immediate',
    END = 'end'
}

export const imagesMimeTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/heic', 'image/heif'];
export const audioMimeTypes = [
    'audio/mpeg', // MP3
    'audio/wav', // WAV
    'audio/aac', // AAC
    'audio/flac', // FLAC
    'audio/ogg', // OGG
    'audio/mp4', // M4A
    'audio/midi', // MIDI
    'audio/x-ms-wma', // WMA
    'audio/webm' // WEBM
];
export const videoMimeTypes = [
    'video/mp4', // MP4
    'video/x-msvideo', // AVI
    'video/quicktime', // MOV
    'video/x-ms-wmv', // WMV
    'video/x-matroska', // MKV
    'video/x-flv', // FLV
    'video/webm', // WEBM
    'video/mpeg', // MPEG
    'video/3gpp' // 3GP
];

@Schema({ _id: false })
class Option {
    @Prop({ required: true, default: 1 })
    id: number;

    @Prop()
    value: string;

    @Prop()
    mediaUrl: string;

    @Prop()
    convertedMediaUrl: string;

    @Prop()
    thumbnailUrl: string;

    @Prop()
    mediaType: string;
}

const OptionSchema = SchemaFactory.createForClass(Option);

@Schema({ _id: false })
class Question {
    @Prop({ required: true, default: 1 })
    id: number;

    @Prop({ required: true })
    title: string;

    @Prop()
    description: string;

    @Prop()
    isMultiChoice: boolean;

    @Prop({ required: true })
    type: string;

    @Prop({ type: [OptionSchema], required: false })
    options: Option[];

    @Prop({ type: mongooseSchema.Types.Mixed })
    optionWeightage: any;
}

const QuestionSchema = SchemaFactory.createForClass(Question);

@Schema({ timestamps: true, versionKey: false })
export class Poll {
    @Prop({ required: true })
    visibility: string;

    @Prop({ required: false })
    isAnonymous: boolean;

    @Prop({ default: true })
    allowComments: boolean;

    @Prop()
    bgImageUrl: string;

    @Prop()
    convertedMediaUrl: string;

    @Prop()
    thumbnailUrl: string;

    @Prop()
    mediaType: string;

    @Prop({ required: true })
    endDate: Date;

    @Prop({ default: PollStatuses.UNDER_REVIEW })
    status: string;

    @Prop({ default: true })
    isActive: boolean;

    @Prop({ default: false })
    isDeleted: boolean;

    @Prop({ default: false })
    isClosed: boolean;

    @Prop({ required: true })
    createdByUsername: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    createdByUserId: string;

    @Prop()
    createdByUserProfilePicUrl: string;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    updatedBy: mongooseSchema.Types.ObjectId;

    @Prop({ type: [Types.ObjectId], ref: Interest.name })
    interests: Types.ObjectId[];

    @Prop({ type: [QuestionSchema], required: true })
    questions: Question[];

    @Prop({ required: true, enum: DisplayResultModes })
    displayResultMode: string;

    @Prop()
    pollGuid: string;

    @Prop()
    sharedWithUsersCount: number;

    @Prop({ default: false })
    isPromoted: boolean;

    @Prop({ default: 0 })
    votes: number;

    @Prop({ default: 0 })
    votersCount: number;
}

const PollSchema = SchemaFactory.createForClass(Poll);

PollSchema.index({ isDeleted: 1, endDate: 1, status: 1, visibility: 1 });
PollSchema.index({ visibility: 1 });
PollSchema.index({ status: 1 });
PollSchema.index({ endDate: 1 });
PollSchema.index({ isDeleted: 1 });
PollSchema.index({ isAnonymous: 1 });
PollSchema.index({ interests: 1 });
PollSchema.index({ createdByUserId: 1 });
PollSchema.index({ displayResultMode: 1 });
PollSchema.index({ isClosed: 1, endDate: 1 });
PollSchema.index({ pollGuid: 1 }, { unique: true, sparse: true });

PollSchema.plugin(mongoosePaginate);

PollSchema.set('toJSON', { getters: true, virtuals: true });

PollSchema.method('toClient', function () {
    const obj: any = this.toObject();

    //Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

PollSchema.pre('save', function (next) {
    if (this.interests && Array.isArray(this.interests)) {
        this.interests = this.interests.map((interest) => {
            return typeof interest === 'string' ? mongoose.Types.ObjectId.createFromHexString(interest) : interest;
        });
    }
    next();
});

export type PollDocument = HydratedDocument<Poll>;

export default PollSchema;
