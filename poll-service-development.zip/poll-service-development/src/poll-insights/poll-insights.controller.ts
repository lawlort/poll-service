import { Controller, Body } from '@nestjs/common';
import { PollInsightsService } from './poll-insights.service';
import { MessagePattern } from '@nestjs/microservices';
import {
    CMD_CALCULATE_POLL_RESPONSE,
    CMD_GET_POLL_INSIGHTS,
    CMD_GET_POLL_INSIGHTS_V2
} from 'src/utils/constants/commands';

@Controller('poll-insights')
export class PollInsightsController {
    constructor(private readonly pollInsightsService: PollInsightsService) {}

    @MessagePattern({ cmd: CMD_GET_POLL_INSIGHTS })
    async getPollInsights(@Body() payload) {
        const { pollId = '', userId = '' } = payload;
        return await this.pollInsightsService.getPollInsights(pollId, userId);
    }

    @MessagePattern({ cmd: CMD_GET_POLL_INSIGHTS_V2 })
    async getPollInsightsV2(@Body() payload) {
        const { pollId = '', userId = '' } = payload;
        return await this.pollInsightsService.getPollInsightsV2(pollId, userId);
    }

    @MessagePattern({ cmd: CMD_CALCULATE_POLL_RESPONSE })
    async calculatePollInsights(@Body() payload) {
        const { body = {}, userId = '' } = payload;
        return await this.pollInsightsService.calculatePollInsightFromPollResponse(body, userId);
    }
}
