import { forwardRef, Module } from '@nestjs/common';
import { PollInsightsService } from './poll-insights.service';
import { PollInsightsController } from './poll-insights.controller';
import { MongooseModule } from '@nestjs/mongoose';
import PollInsightsSchema, { PollInsight } from './schemas/poll-insight.schema';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';
import PollResponseSchema, { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
import PollResponseHistorySchema, {
    PollResponseHistory
} from 'src/poll-response-history/schemas/poll-response-history.schema';
import { PollsModule } from 'src/polls/polls.module';
import GroupPollSchema, { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import GroupMemberSchema, { GroupMember } from 'src/group-members/schemas/group-members.schema';
import { GendersModule } from 'src/genders/genders.module';
import { UsersModule } from 'src/users/users.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: PollInsight.name, schema: PollInsightsSchema },
            { name: Poll.name, schema: PollSchema },
            { name: PollResponse.name, schema: PollResponseSchema },
            { name: PollResponseHistory.name, schema: PollResponseHistorySchema },
            { name: PollResponse.name, schema: PollResponseSchema },
            { name: GroupPoll.name, schema: GroupPollSchema },
            { name: PollResponseHistory.name, schema: PollResponseHistorySchema },
            { name: GroupMember.name, schema: GroupMemberSchema }
        ]),
        forwardRef(() => PollsModule), // Wrap with forwardRef to break circular dependency,
        GendersModule,
        UsersModule
    ],
    controllers: [PollInsightsController],
    providers: [PollInsightsService],
    exports: [PollInsightsService]
})
export class PollInsightsModule {}
