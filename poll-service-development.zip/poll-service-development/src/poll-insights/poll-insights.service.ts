import { BadRequestException, forwardRef, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { PollInsight } from './schemas/poll-insight.schema';
import { isValidObjectId, Model } from 'mongoose';
import { globalErrorObj } from 'src/utils/common/globalErrorRes';
import { Poll, QuestionTypes } from 'src/polls/schemas/poll.schema';
import { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
import { PollResponseHistory } from 'src/poll-response-history/schemas/poll-response-history.schema';
import { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import { UNITED_KINGDOM, UNKNOWN } from 'src/utils/constants/string';
import { PollsService } from 'src/polls/polls.service';
import { GroupMember } from 'src/group-members/schemas/group-members.schema';
import { GendersService } from 'src/genders/genders.service';
import { GENDER_PREFER_NOT_TO_RESPOND, GENDER_UNKNOWN } from 'src/utils/constants/genders';
import { UsersService } from 'src/users/users.service';

@Injectable()
export class PollInsightsService {
    constructor(
        @InjectModel(PollInsight.name) private pollInsightsModel: Model<PollInsight>,
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        @InjectModel(PollResponse.name) private pollResponseModel: Model<PollResponse>,
        @InjectModel(PollResponseHistory.name) private pollResponseHistoryModel: Model<PollResponseHistory>,
        @InjectModel(GroupPoll.name) private groupPollModel: Model<GroupPoll>,
        @InjectModel(GroupMember.name) private groupMemberModel: Model<GroupMember>,
        @Inject(forwardRef(() => PollsService)) private pollService: PollsService,
        private genderService: GendersService,
        private userService: UsersService
    ) {}

    async createEmptyPollInsight(pollId: string) {
        try {
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.pattern.base'));
            }

            const poll = await this.pollModel.findById(pollId).lean();

            if (!poll?._id) {
                throw new NotFoundException('Poll not found');
            }

            const questions = poll?.questions || [];
            const initialPercentageData = questions.map((question) => ({
                pollId,
                ...question
            }));

            const emptyGenders = (await this.createEmptyGenderData(poll)) || [];

            const initialGenderData = emptyGenders;

            const initialGraphData = {
                totalResponses: 0,
                dateWisePercentages: []
            };

            const initialLocationData = questions.map((question) => ({
                pollId,
                questionId: question.id,
                cityData: [],
                stateData: [],
                countryData: []
            }));

            const payload = {
                pollId: pollId,
                createdBy: poll.createdByUserId,
                insights: {
                    percentageData: initialPercentageData,
                    genderData: initialGenderData,
                    graphData: initialGraphData,
                    locationData: initialLocationData
                },
                totalVotes: 0
            };

            return await this.pollInsightsModel.create(payload);
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async createEmptyGenderData(poll) {
        try {
            const genders = await this.genderService.findAll();
            const initialGenderCounts = genders.map((gender) => {
                return {
                    gender: gender.genderType,
                    count: 0,
                    percentage: 0
                };
            });
            const questions = poll?.questions || [];
            const initialGenderData = questions.map((question) => ({
                pollId: poll._id,
                questionId: question.id,
                genderData: initialGenderCounts
            }));
            return initialGenderData;
        } catch (error) {
            return [];
        }
    }

    adjustPercentages(percentages) {
        // Round each percentage and convert to an integer
        const roundedPercentages = percentages.map((e) => Math.round(e));
        // Calculate the sum of the rounded percentages
        const sum = roundedPercentages.reduce((a, b) => a + b, 0);

        // If the sum is not 100, adjust the highest percentage
        if (sum > 0 && sum !== 100) {
            const difference = 100 - sum;
            const maxIndex = roundedPercentages.indexOf(Math.max(...roundedPercentages));
            roundedPercentages[maxIndex] += difference;
        }

        return roundedPercentages;
    }

    //eslint-disable-next-line @typescript-eslint/no-unused-vars
    async getPollInsights(pollId: string, userId: string) {
        try {
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.pattern.base'));
            }

            const poll = await this.pollModel.findById(pollId).populate('interests');

            // const count = await this.pollResponseModel.countDocuments({ pollId });

            const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                pollId,
                userId,
                isDeleted: false
            });

            // First, find all the group memberships for the user
            const userGroups = await this.groupMemberModel
                .find({ userId: userId, isActive: true, isDeleted: false }) // Ensure user is active and not deleted
                .select('groupId') // Select only the groupId field
                .exec();

            // Extract the group IDs that the user is a member of
            const userGroupIds = userGroups.map((membership) => membership.groupId.toString());

            // Then, find the polls shared with those groups
            const groupSharedPolls = await this.groupPollModel
                .find({ pollId, isDeleted: false }) // Filter by pollId and user's groupIds
                .populate({
                    path: 'groupId',
                    populate: {
                        path: 'groupInterests',
                        select: '_id name'
                    }
                })
                .exec();

            // Filter out the groups that are undefined/null and extract the valid group information
            const groups = groupSharedPolls
                .filter((group) => group?.groupId) // Ensure groupId is valid
                .map((group) => group.groupId) // Extract the groupId details
                .map((group: any) => {
                    return {
                        ...group.toObject(),
                        isGroupMember: userGroupIds.includes(group?._id?.toString())
                    };
                });

            const pollInsight = await this.pollInsightsModel.findOne({ pollId });

            if (pollInsight?.isDeleted) {
                throw new NotFoundException('Poll insight not found');
            }

            // if result available
            if (pollInsight?._id) {
                const pollResponses = await this.pollResponseModel.find({ pollId, userId });
                const pollInsightObj = pollInsight.toObject();

                if (pollInsightObj.insights?.percentageData?.length) {
                    pollInsightObj.insights.percentageData = pollInsightObj.insights.percentageData.map(
                        (question: any) => {
                            const options = question?.options || [];

                            if (
                                question?.type === QuestionTypes.THIS_THAT ||
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const optionsArr = options || [];
                                // sort by percentage and sort by count for same percentages
                                optionsArr.sort((a, b) => {
                                    if (a?.percentage === b?.percentage) {
                                        return b?.count - a?.count;
                                    }
                                    return b?.percentage - a?.percentage;
                                });

                                // add rank to each option. For same percentages, rank will be same and for other it will be in ascending order
                                let lastIndex = 1;
                                optionsArr.forEach((option, index) => {
                                    if (index > 0 && option?.percentage !== optionsArr[index - 1]?.percentage) {
                                        lastIndex = lastIndex + 1;
                                    }
                                    option.rank = lastIndex;
                                });
                                question.options = optionsArr;
                            }
                            // if question type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                const optionsArr = options || [];

                                if (optionsArr[0]?.weightage) {
                                    optionsArr.sort((a, b) => {
                                        return b?.weightage - a?.weightage;
                                    });
                                }

                                let lastIndex = 1;
                                optionsArr.forEach((option, index) => {
                                    if (index > 0 && option?.weightage !== optionsArr[index - 1]?.weightage) {
                                        lastIndex = lastIndex + 1;
                                    }
                                    option.rank = lastIndex;
                                    if (option?.weightage >= 0) {
                                        option.percentage = option?.weightage || 0;
                                    }
                                });
                                question.options = optionsArr;

                                // if (options[0]?.weightage) {
                                //     question.options = options.sort((a, b) => b?.weightage - a?.weightage);
                                // }
                                // let currentRank = 1;
                                // for (let i = 0; i < options.length; i++) {
                                //     if (i > 0 && options[i]?.weightage === options[i - 1]?.weightage) {
                                //         // If weightage is the same as the previous, assign the same rank
                                //         options[i]['rank'] = options[i - 1].selectedRank;
                                //     } else {
                                //         // Assign the current rank
                                //         options[i]['rank'] = currentRank;
                                //     }

                                //     if (options[i]?.weightage >= 0) {
                                //         options[i]['percentage'] = options[i]?.weightage || 0;
                                //     }

                                //     currentRank++;
                                // }
                            }

                            // If poll type is SINGLE_CHOICE or THIS_THAT
                            if (
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.THIS_THAT
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionId = pollResponse?.optionId;

                                // Map options to add isSelected field
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: option.id === optionId
                                }));

                                if (!pollResponse) {
                                    question.options = options.map((option) => ({
                                        ...option,
                                        isSelected: false
                                    }));
                                }
                            }

                            // If poll type is MULTIPLE_CHOICE or DATE
                            if (
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionIds = (pollResponses || []).map((response) => response.optionId);

                                // Map options to add isSelected field for multiple choice
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: optionIds.includes(option.id)
                                }));

                                if (!pollResponse) {
                                    question.options = options.map((option) => ({
                                        ...option,
                                        isSelected: false
                                    }));
                                }
                            }

                            // If poll type is SLIDER or LIGHT_METER
                            if (
                                question?.type === QuestionTypes.SLIDER ||
                                question?.type === QuestionTypes.LIGHT_METER
                            ) {
                                pollResponses?.length &&
                                    pollResponses[0] &&
                                    (question.sliderValue = pollResponses[0]?.sliderValue || 0);

                                if (!pollResponses?.length) {
                                    delete question.sliderValue;
                                }
                            }

                            // If poll type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                if (!pollResponses?.length) {
                                    question?.options?.forEach((option) => {
                                        delete option.selectedRank;
                                    });
                                } else {
                                    question.options = options.map((option) => {
                                        const pollResponse = pollResponses.find(
                                            (response) => response.optionId === option.id
                                        );
                                        return {
                                            ...option,
                                            selectedRank: pollResponse?.order || null
                                        };
                                    });
                                }
                            }

                            question.options = question.options.map((option) => {
                                if (option?.percentage) {
                                    option.percentage = Number(option.percentage.toFixed(1));
                                }
                                return option;
                            });

                            if (question?.percentage) {
                                question.percentage = Number(question.percentage.toFixed(1));
                            }

                            if (question?.sliderValue) {
                                question.sliderValue = Number(question.sliderValue.toFixed(1));
                            }

                            return question;
                        }
                    );
                }

                if (pollInsightObj.insights?.genderData?.length) {
                    pollInsightObj.insights.genderData = pollInsightObj.insights.genderData.map((gender) => {
                        if (gender?.genderData?.length) {
                            gender.genderData = gender.genderData.map((_gender) => {
                                if (_gender?.percentage) {
                                    _gender.percentage = Number(_gender.percentage.toFixed(1));
                                }
                                return _gender;
                            });

                            let totalUnknownGenderCount = 0;
                            let totalUnknownGenderPercentage = 0;

                            const newGenderData = [];
                            for (const _gender of gender?.genderData || []) {
                                if (
                                    _gender?.gender !== GENDER_UNKNOWN &&
                                    _gender?.gender !== GENDER_PREFER_NOT_TO_RESPOND
                                ) {
                                    newGenderData.push(_gender);
                                } else {
                                    totalUnknownGenderCount += _gender?.count || 0;
                                    totalUnknownGenderPercentage += _gender?.percentage || 0;
                                }
                            }
                            newGenderData.push({
                                gender: GENDER_UNKNOWN,
                                count: totalUnknownGenderCount,
                                percentage: totalUnknownGenderPercentage
                            });

                            // Check if all gender percentages are not 0
                            const isAnyPercentageNonZero = newGenderData.some((gender) => gender.percentage > 0);
                            if (isAnyPercentageNonZero) {
                                const genderPercentages = newGenderData.map((gender) => gender.percentage);
                                const adjustedGenderPercentages = this.adjustPercentages(genderPercentages);
                                newGenderData.forEach((gender, index) => {
                                    gender.percentage = adjustedGenderPercentages[index];
                                });
                            }

                            newGenderData.sort((a, b) => {
                                if (a?.percentage === b?.percentage) {
                                    return b?.count - a?.count;
                                }
                                return b?.percentage - a?.percentage;
                            });

                            // Assign rank based on percentage (same percentage gets the same rank)
                            let lastIndex = 1;
                            newGenderData.forEach((option, index) => {
                                if (index > 0 && option.percentage !== newGenderData[index - 1].percentage) {
                                    lastIndex += 1;
                                }
                                option.rank = lastIndex;
                            });

                            gender.genderData = newGenderData;
                        }
                        return gender;
                    });
                }

                if (pollInsightObj?.insights?.graphData?.dateWisePercentages?.length) {
                    const dateWisePercentageArr = pollInsightObj?.insights?.graphData?.dateWisePercentages || [];
                    pollInsightObj.insights.graphData.dateWisePercentages = dateWisePercentageArr.map(
                        (dateWisePercentage) => {
                            if (dateWisePercentage?.percentage) {
                                dateWisePercentage.percentage = Number(dateWisePercentage.percentage.toFixed(1));
                            }
                            return dateWisePercentage;
                        }
                    );

                    dateWisePercentageArr.sort((a, b) => {
                        if (a?.percentage === b?.percentage) {
                            return b?.count - a?.count;
                        }
                        return b?.percentage - a?.percentage;
                    });

                    // Assign rank to each date based on percentage (handle equal percentages with the same rank)
                    let lastIndex = 1;
                    dateWisePercentageArr.forEach((response, index) => {
                        if (index > 0 && response.percentage !== dateWisePercentageArr[index - 1].percentage) {
                            lastIndex += 1;
                        }
                        response.rank = lastIndex;
                    });
                    pollInsightObj.insights.graphData.dateWisePercentages = dateWisePercentageArr;
                }

                if (pollInsightObj?.insights?.locationData?.length) {
                    pollInsightObj.insights.locationData = pollInsightObj.insights.locationData.map((location) => {
                        if (location?.cityData?.length) {
                            const cityData = location.cityData || [];
                            location.cityData = cityData.map((_location) => {
                                if (_location?.percentage) {
                                    _location.percentage = Number(_location.percentage.toFixed(0));
                                }
                                return _location;
                            });

                            // Sort and rank city data
                            cityData.sort((a, b) => {
                                if (a?.percentage === b?.percentage) {
                                    return b?.count - a?.count;
                                }
                                return b?.percentage - a?.percentage;
                            });

                            let cityLastIndex = 1;
                            cityData.forEach((option, index) => {
                                if (index > 0 && option.percentage !== cityData[index - 1].percentage) {
                                    cityLastIndex = cityLastIndex + 1;
                                }
                                option.rank = cityLastIndex;
                            });

                            location.cityData = cityData;
                        }

                        if (location?.countryData?.length) {
                            const countryData = location.countryData || [];
                            location.countryData = countryData.map((_location) => {
                                if (_location?.percentage) {
                                    _location.percentage = Number(_location.percentage.toFixed(0));
                                }
                                return _location;
                            });

                            // Sort and rank city data
                            countryData.sort((a, b) => {
                                if (a?.percentage === b?.percentage) {
                                    return b?.count - a?.count;
                                }
                                return b?.percentage - a?.percentage;
                            });

                            let countryLastIndex = 1;
                            countryData.forEach((option, index) => {
                                if (index > 0 && option.percentage !== countryData[index - 1].percentage) {
                                    countryLastIndex = countryLastIndex + 1;
                                }
                                option.rank = countryLastIndex;
                            });

                            location.countryData = countryData;
                        }

                        if (location?.stateData?.length) {
                            const stateData = location.stateData || [];
                            location.stateData = stateData.map((_location) => {
                                if (_location?.percentage) {
                                    _location.percentage = Number(_location.percentage.toFixed(0));
                                }
                                return _location;
                            });

                            // Sort and rank city data
                            stateData.sort((a, b) => {
                                if (a?.percentage === b?.percentage) {
                                    return b?.count - a?.count;
                                }
                                return b?.percentage - a?.percentage;
                            });

                            let stateLastIndex = 1;
                            stateData.forEach((option, index) => {
                                if (index > 0 && option.percentage !== stateData[index - 1].percentage) {
                                    stateLastIndex = stateLastIndex + 1;
                                }
                                option.rank = stateLastIndex;
                            });

                            location.stateData = stateData;
                        }

                        const ukData = (location?.countryData || []).find(
                            (country) => country?.country === UNITED_KINGDOM
                        );
                        // if (ukData) {
                        location['outsideUkPercentage'] = 100 - (ukData?.percentage || 0);
                        // }

                        return location;
                    });
                }

                return {
                    ...pollInsightObj,
                    createdByUserProfilePicUrl: poll?.createdByUserProfilePicUrl,
                    isAnnonymous: poll?.isAnonymous,
                    createdByUsername: poll?.createdByUsername,
                    createdByUserId: poll?.createdByUserId,
                    bgImageUrl: poll?.bgImageUrl,
                    interests: (poll?.interests || []).map((interest: any) => interest.name),
                    isAnswered: pollResponses.length > 0,
                    votes: poll?.votes || 0,
                    allowChangeMyMind: pollResponseHistoryCount < 2,
                    groups,
                    sharedWithUsersCount: poll?.sharedWithUsersCount || 0,
                    votersCount: poll?.votersCount || 0,
                    visibility: poll?.visibility || null,
                    convertedMediaUrl: poll?.convertedMediaUrl || null,
                    thumbnailUrl: poll?.thumbnailUrl || null,
                    mediaType: poll?.mediaType || null
                };
            }
            // if result not available
            const result = await this.createPollInsight(pollId, userId);
            result['allowChangeMyMind'] = pollResponseHistoryCount < 2;
            result['votes'] = poll?.votes || 0;
            result['sharedWithUsersCount'] = poll?.sharedWithUsersCount || 0;
            result['votersCount'] = poll?.votersCount || 0;
            result['allowChangeMyMind'] = pollResponseHistoryCount < 2;
            result['visibility'] = poll?.visibility || null;
            result['convertedMediaUrl'] = poll?.convertedMediaUrl || null;
            result['thumbnailUrl'] = poll?.thumbnailUrl || null;
            result['mediaType'] = poll?.mediaType || null;
            return result;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async getPollInsightsV2(pollId: string, userId: string) {
        try {
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.pattern.base'));
            }

            const poll: any = await this.pollModel.findById(pollId).populate('interests');

            // const count = await this.pollResponseModel.countDocuments({ pollId });

            const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                pollId,
                userId,
                isDeleted: false
            });

            // First, find all the group memberships for the user
            const userGroups = await this.groupMemberModel
                .find({ userId: userId, isActive: true, isDeleted: false }) // Ensure user is active and not deleted
                .select('groupId') // Select only the groupId field
                .exec();

            // Extract the group IDs that the user is a member of
            const userGroupIds = userGroups.map((membership) => membership.groupId.toString());

            // Then, find the polls shared with those groups
            const groupSharedPolls = await this.groupPollModel
                .find({ pollId, isDeleted: false }) // Filter by pollId and user's groupIds
                .populate({
                    path: 'groupId',
                    populate: {
                        path: 'groupInterests',
                        select: '_id name'
                    }
                })
                .exec();

            // Filter out the groups that are undefined/null and extract the valid group information
            const groups = groupSharedPolls
                .filter((group) => group?.groupId) // Ensure groupId is valid
                .map((group) => group.groupId) // Extract the groupId details
                .map((group: any) => {
                    return {
                        ...group.toObject(),
                        isGroupMember: userGroupIds.includes(group?._id?.toString())
                    };
                });

            const pollInsight = await this.pollInsightsModel.findOne({ pollId });

            if (pollInsight?.isDeleted) {
                throw new NotFoundException('Poll insight not found');
            }

            // if result available
            if (pollInsight?._id) {
                const pollResponses = await this.pollResponseModel.find({ pollId, userId });
                const pollInsightObj = pollInsight.toObject();

                if (pollInsightObj.insights?.percentageData?.length) {
                    pollInsightObj.insights.percentageData = pollInsightObj.insights.percentageData.map(
                        (question: any) => {
                            const options = question?.options || [];

                            if (
                                question?.type === QuestionTypes.THIS_THAT ||
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const optionsArr = options || [];
                                // sort by percentage and sort by count for same percentages
                                optionsArr.sort((a, b) => {
                                    if (a?.percentage === b?.percentage) {
                                        return b?.count - a?.count;
                                    }
                                    return b?.percentage - a?.percentage;
                                });

                                // add rank to each option. For same percentages, rank will be same and for other it will be in ascending order
                                let lastIndex = 1;
                                optionsArr.forEach((option, index) => {
                                    if (index > 0 && option?.percentage !== optionsArr[index - 1]?.percentage) {
                                        lastIndex = lastIndex + 1;
                                    }
                                    option.rank = lastIndex;
                                });
                                question.options = optionsArr;
                            }
                            // if question type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                const optionsArr = options || [];

                                if (optionsArr[0]?.weightage) {
                                    optionsArr.sort((a, b) => {
                                        return b?.weightage - a?.weightage;
                                    });
                                }

                                let lastIndex = 1;
                                optionsArr.forEach((option, index) => {
                                    if (index > 0 && option?.weightage !== optionsArr[index - 1]?.weightage) {
                                        lastIndex = lastIndex + 1;
                                    }
                                    option.rank = lastIndex;
                                    if (option?.weightage >= 0) {
                                        option.percentage = option?.weightage || 0;
                                    }
                                });
                                question.options = optionsArr;

                                // if (options[0]?.weightage) {
                                //     question.options = options.sort((a, b) => b?.weightage - a?.weightage);
                                // }
                                // let currentRank = 1;
                                // for (let i = 0; i < options.length; i++) {
                                //     if (i > 0 && options[i]?.weightage === options[i - 1]?.weightage) {
                                //         // If weightage is the same as the previous, assign the same rank
                                //         options[i]['rank'] = options[i - 1].selectedRank;
                                //     } else {
                                //         // Assign the current rank
                                //         options[i]['rank'] = currentRank;
                                //     }

                                //     if (options[i]?.weightage >= 0) {
                                //         options[i]['percentage'] = options[i]?.weightage || 0;
                                //     }

                                //     currentRank++;
                                // }
                            }

                            // If poll type is SINGLE_CHOICE or THIS_THAT
                            if (
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.THIS_THAT
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionId = pollResponse?.optionId;

                                // Map options to add isSelected field
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: option.id === optionId
                                }));

                                if (!pollResponse) {
                                    question.options = options.map((option) => ({
                                        ...option,
                                        isSelected: false
                                    }));
                                }
                            }

                            // If poll type is MULTIPLE_CHOICE or DATE
                            if (
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionIds = (pollResponses || []).map((response) => response.optionId);

                                // Map options to add isSelected field for multiple choice
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: optionIds.includes(option.id)
                                }));

                                if (!pollResponse) {
                                    question.options = options.map((option) => ({
                                        ...option,
                                        isSelected: false
                                    }));
                                }
                            }

                            // If poll type is SLIDER or LIGHT_METER
                            if (
                                question?.type === QuestionTypes.SLIDER ||
                                question?.type === QuestionTypes.LIGHT_METER
                            ) {
                                pollResponses?.length &&
                                    pollResponses[0] &&
                                    (question.sliderValue = pollResponses[0]?.sliderValue || 0);

                                if (!pollResponses?.length) {
                                    delete question.sliderValue;
                                }
                            }

                            // If poll type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                if (!pollResponses?.length) {
                                    question?.options?.forEach((option) => {
                                        delete option.selectedRank;
                                    });
                                } else {
                                    question.options = options.map((option) => {
                                        const pollResponse = pollResponses.find(
                                            (response) => response.optionId === option.id
                                        );
                                        return {
                                            ...option,
                                            selectedRank: pollResponse?.order || null
                                        };
                                    });
                                }
                            }

                            question.options = question.options.map((option) => {
                                if (option?.percentage) {
                                    option.percentage = Number(option.percentage.toFixed(1));
                                }
                                return option;
                            });

                            if (question?.percentage) {
                                question.percentage = Number(question.percentage.toFixed(1));
                            }

                            if (question?.sliderValue) {
                                question.sliderValue = Number(question.sliderValue.toFixed(1));
                            }

                            return question;
                        }
                    );
                }

                if (pollInsightObj.insights?.genderData?.length) {
                    pollInsightObj.insights.genderData = pollInsightObj.insights.genderData.map((gender) => {
                        if (gender?.genderData?.length) {
                            gender.genderData = gender.genderData.map((_gender) => {
                                if (_gender?.percentage) {
                                    _gender.percentage = Number(_gender.percentage.toFixed(1));
                                }
                                return _gender;
                            });

                            let totalUnknownGenderCount = 0;
                            let totalUnknownGenderPercentage = 0;

                            const newGenderData = [];
                            for (const _gender of gender?.genderData || []) {
                                if (
                                    _gender?.gender !== GENDER_UNKNOWN &&
                                    _gender?.gender !== GENDER_PREFER_NOT_TO_RESPOND
                                ) {
                                    newGenderData.push(_gender);
                                } else {
                                    totalUnknownGenderCount += _gender?.count || 0;
                                    totalUnknownGenderPercentage += _gender?.percentage || 0;
                                }
                            }
                            newGenderData.push({
                                gender: GENDER_UNKNOWN,
                                count: totalUnknownGenderCount,
                                percentage: totalUnknownGenderPercentage
                            });

                            // Check if all gender percentages are not 0
                            const isAnyPercentageNonZero = newGenderData.some((gender) => gender.percentage > 0);
                            if (isAnyPercentageNonZero) {
                                const genderPercentages = newGenderData.map((gender) => gender.percentage);
                                const adjustedGenderPercentages = this.adjustPercentages(genderPercentages);
                                newGenderData.forEach((gender, index) => {
                                    gender.percentage = adjustedGenderPercentages[index];
                                });
                            }

                            newGenderData.sort((a, b) => {
                                if (a?.percentage === b?.percentage) {
                                    return b?.count - a?.count;
                                }
                                return b?.percentage - a?.percentage;
                            });

                            // Assign rank based on percentage (same percentage gets the same rank)
                            let lastIndex = 1;
                            newGenderData.forEach((option, index) => {
                                if (index > 0 && option.percentage !== newGenderData[index - 1].percentage) {
                                    lastIndex += 1;
                                }
                                option.rank = lastIndex;
                            });

                            gender.genderData = newGenderData;
                        }
                        return gender;
                    });
                }

                if (pollInsightObj?.insights?.graphData?.dateWisePercentages?.length) {
                    const dateWisePercentageArr = pollInsightObj?.insights?.graphData?.dateWisePercentages || [];
                    pollInsightObj.insights.graphData.dateWisePercentages = dateWisePercentageArr.map(
                        (dateWisePercentage) => {
                            if (dateWisePercentage?.percentage) {
                                dateWisePercentage.percentage = Number(dateWisePercentage.percentage.toFixed(1));
                            }
                            return dateWisePercentage;
                        }
                    );

                    dateWisePercentageArr.sort((a, b) => {
                        if (a?.percentage === b?.percentage) {
                            return b?.count - a?.count;
                        }
                        return b?.percentage - a?.percentage;
                    });

                    // Assign rank to each date based on percentage (handle equal percentages with the same rank)
                    let lastIndex = 1;
                    dateWisePercentageArr.forEach((response, index) => {
                        if (index > 0 && response.percentage !== dateWisePercentageArr[index - 1].percentage) {
                            lastIndex += 1;
                        }
                        response.rank = lastIndex;
                    });
                    pollInsightObj.insights.graphData.dateWisePercentages = dateWisePercentageArr;
                }

                if (pollInsightObj?.insights?.locationData?.length) {
                    pollInsightObj.insights.locationData = pollInsightObj.insights.locationData.map((location) => {
                        if (location?.cityData?.length) {
                            const cityData = location.cityData || [];
                            location.cityData = cityData.map((_location) => {
                                if (_location?.percentage) {
                                    _location.percentage = Number(_location.percentage.toFixed(0));
                                }
                                return _location;
                            });

                            // Sort and rank city data
                            cityData.sort((a, b) => {
                                if (a?.percentage === b?.percentage) {
                                    return b?.count - a?.count;
                                }
                                return b?.percentage - a?.percentage;
                            });

                            let cityLastIndex = 1;
                            cityData.forEach((option, index) => {
                                if (index > 0 && option.percentage !== cityData[index - 1].percentage) {
                                    cityLastIndex = cityLastIndex + 1;
                                }
                                option.rank = cityLastIndex;
                            });

                            location.cityData = cityData;
                        }

                        if (location?.countryData?.length) {
                            const countryData = location.countryData || [];
                            location.countryData = countryData.map((_location) => {
                                if (_location?.percentage) {
                                    _location.percentage = Number(_location.percentage.toFixed(0));
                                }
                                return _location;
                            });

                            // Sort and rank city data
                            countryData.sort((a, b) => {
                                if (a?.percentage === b?.percentage) {
                                    return b?.count - a?.count;
                                }
                                return b?.percentage - a?.percentage;
                            });

                            let countryLastIndex = 1;
                            countryData.forEach((option, index) => {
                                if (index > 0 && option.percentage !== countryData[index - 1].percentage) {
                                    countryLastIndex = countryLastIndex + 1;
                                }
                                option.rank = countryLastIndex;
                            });

                            location.countryData = countryData;
                        }

                        if (location?.stateData?.length) {
                            const stateData = location.stateData || [];
                            location.stateData = stateData.map((_location) => {
                                if (_location?.percentage) {
                                    _location.percentage = Number(_location.percentage.toFixed(0));
                                }
                                return _location;
                            });

                            // Sort and rank city data
                            stateData.sort((a, b) => {
                                if (a?.percentage === b?.percentage) {
                                    return b?.count - a?.count;
                                }
                                return b?.percentage - a?.percentage;
                            });

                            let stateLastIndex = 1;
                            stateData.forEach((option, index) => {
                                if (index > 0 && option.percentage !== stateData[index - 1].percentage) {
                                    stateLastIndex = stateLastIndex + 1;
                                }
                                option.rank = stateLastIndex;
                            });

                            location.stateData = stateData;
                        }

                        const ukData = (location?.countryData || []).find(
                            (country) => country?.country === UNITED_KINGDOM
                        );
                        // if (ukData) {
                        location['outsideUkPercentage'] = 100 - (ukData?.percentage || 0);
                        // }

                        return location;
                    });
                }
                const user = await this.userService.getUserById(userId);
                const userInterests = user?.interests || [];
                const userInterestNames = userInterests.map((interest: any) => interest.name); // Get user interest names

                poll['interests'] = (poll['interests'] || [])
                    .map((interest) => {
                        return {
                            id: interest._id,
                            name: interest.name,
                            isUserInterest: userInterestNames.includes(interest.name)
                        };
                    })
                    .sort((a, b) => {
                        // Sort by isGroupMember with `true` values first
                        return a.isUserInterest === b.isUserInterest ? 0 : a.isUserInterest ? -1 : 1;
                    });

                return {
                    ...pollInsightObj,
                    createdByUserProfilePicUrl: poll?.createdByUserProfilePicUrl,
                    isAnnonymous: poll?.isAnonymous,
                    createdByUsername: poll?.createdByUsername,
                    createdByUserId: poll?.createdByUserId,
                    bgImageUrl: poll?.bgImageUrl,
                    interests: poll?.interests,
                    isAnswered: pollResponses.length > 0,
                    votes: poll?.votes || 0,
                    allowChangeMyMind: pollResponseHistoryCount < 2,
                    groups,
                    sharedWithUsersCount: poll?.sharedWithUsersCount || 0,
                    votersCount: poll?.votersCount || 0,
                    visibility: poll?.visibility || null,
                    convertedMediaUrl: poll?.convertedMediaUrl || null,
                    thumbnailUrl: poll?.thumbnailUrl || null,
                    mediaType: poll?.mediaType || null
                };
            }

            // if result not available
            const result = await this.createPollInsight(pollId, userId);
            result['allowChangeMyMind'] = pollResponseHistoryCount < 2;
            result['votes'] = poll?.votes || 0;
            result['sharedWithUsersCount'] = poll?.sharedWithUsersCount || 0;
            result['votersCount'] = poll?.votersCount || 0;
            result['allowChangeMyMind'] = pollResponseHistoryCount < 2;
            result['visibility'] = poll?.visibility || null;
            result['convertedMediaUrl'] = poll?.convertedMediaUrl || null;
            result['thumbnailUrl'] = poll?.thumbnailUrl || null;
            result['mediaType'] = poll?.mediaType || null;
            return result;
        } catch (error) {
            console.log(error);
            throw new RpcException(error);
        }
    }

    async createPollInsight(pollId: string, userId: string) {
        try {
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.pattern.base'));
            }

            const poll = await this.pollModel.findById(pollId).populate('interests');

            if (!poll?._id) {
                throw new NotFoundException('Poll not found');
            }

            // calculate insights
            const insights = await this.calculatePollInsights(poll, userId);

            const totalResponses = await this.pollResponseModel.countDocuments({ pollId });

            const payload = {
                pollId,
                createdBy: poll.createdByUserId,
                insights,
                totalVotes: totalResponses
            };

            // delete old insights
            const pollInsights = await this.pollInsightsModel.find({ pollId, isDeleted: false });
            const pullInsightsIds = pollInsights.map((insight) => insight._id);

            // delete old insights
            if (pullInsightsIds.length > 0) {
                await this.pollInsightsModel.deleteMany({ _id: { $in: pullInsightsIds } });
            }

            // create new insights
            const pollInsight = await this.pollInsightsModel.create(payload);

            const pollResponses = await this.pollResponseModel.find({ pollId, userId });

            const pollInsightObj = pollInsight.toObject();

            if (pollInsightObj.insights?.percentageData?.length) {
                pollInsightObj.insights.percentageData = pollInsightObj.insights.percentageData.map((question: any) => {
                    const options = question?.options || [];

                    // If poll type is SINGLE_CHOICE or THIS_THAT
                    if (question?.type === QuestionTypes.SINGLE_CHOICE || question?.type === QuestionTypes.THIS_THAT) {
                        const pollResponse = pollResponses[0];
                        const optionId = pollResponse?.optionId;

                        // Map options to add isSelected field
                        question.options = options.map((option) => ({
                            ...option,
                            isSelected: option.id === optionId
                        }));

                        if (!pollResponse) {
                            question.options = options.map((option) => ({
                                ...option,
                                isSelected: false
                            }));
                        }
                    }

                    // If poll type is MULTIPLE_CHOICE or DATE
                    if (question?.type === QuestionTypes.MULTIPLE_CHOICE || question?.type === QuestionTypes.DATE) {
                        const pollResponse = pollResponses[0];
                        const optionIds = (pollResponses || []).map((response) => response.optionId);

                        // Map options to add isSelected field for multiple choice
                        question.options = options.map((option) => ({
                            ...option,
                            isSelected: optionIds.includes(option.id)
                        }));

                        if (!pollResponse) {
                            question.options = options.map((option) => ({
                                ...option,
                                isSelected: false
                            }));
                        }
                    }

                    // If poll type is SLIDER or LIGHT_METER
                    if (question?.type === QuestionTypes.SLIDER || question?.type === QuestionTypes.LIGHT_METER) {
                        pollResponses?.length &&
                            pollResponses[0] &&
                            (question.sliderValue = pollResponses[0]?.sliderValue || 0);

                        if (!pollResponses?.length) {
                            delete question.sliderValue;
                        }
                    }

                    // If poll type is RANKING
                    if (question?.type === QuestionTypes.RANKING) {
                        if (!pollResponses?.length) {
                            question?.options?.forEach((option) => {
                                delete option.selectedRank;
                            });
                        } else {
                            question.options = options.map((option) => {
                                const pollResponse = pollResponses.find((response) => response.optionId === option.id);
                                return {
                                    ...option,
                                    selectedRank: pollResponse?.order || null
                                };
                            });
                        }
                    }

                    question.options = question.options.map((option) => {
                        if (option?.percentage) {
                            option.percentage = Number(option.percentage.toFixed(2));
                        }
                        return option;
                    });

                    if (question?.percentage) {
                        question.percentage = Number(question.percentage.toFixed(2));
                    }

                    if (question?.sliderValue) {
                        question.sliderValue = Number(question.sliderValue.toFixed(2));
                    }

                    return question;
                });
            }

            if (pollInsightObj.insights?.genderData?.length) {
                pollInsightObj.insights.genderData = pollInsightObj.insights.genderData.map((gender) => {
                    if (gender?.genderData?.length) {
                        gender.genderData = gender.genderData.map((_gender) => {
                            if (_gender?.percentage) {
                                _gender.percentage = Number(_gender.percentage.toFixed(2));
                            }
                            return _gender;
                        });
                    }
                    return gender;
                });
            }

            if (pollInsightObj?.insights?.graphData?.dateWisePercentages?.length) {
                pollInsightObj.insights.graphData.dateWisePercentages =
                    pollInsightObj.insights.graphData.dateWisePercentages.map((dateWisePercentage) => {
                        if (dateWisePercentage?.percentage) {
                            dateWisePercentage.percentage = Number(dateWisePercentage.percentage.toFixed(2));
                        }
                        return dateWisePercentage;
                    });
            }

            if (pollInsightObj?.insights?.locationData?.length) {
                pollInsightObj.insights.locationData = pollInsightObj.insights.locationData.map((location) => {
                    if (location?.cityData?.length) {
                        location.cityData = location.cityData.map((_location) => {
                            if (_location?.percentage) {
                                _location.percentage = Number(_location.percentage.toFixed(2));
                            }
                            return _location;
                        });
                    }

                    if (location?.countryData?.length) {
                        location.countryData = location.countryData.map((_location) => {
                            if (_location?.percentage) {
                                _location.percentage = Number(_location.percentage.toFixed(2));
                            }
                            return _location;
                        });
                    }

                    if (location?.stateData?.length) {
                        location.stateData = location.stateData.map((_location) => {
                            if (_location?.percentage) {
                                _location.percentage = Number(_location.percentage.toFixed(2));
                            }
                            return _location;
                        });
                    }

                    return location;
                });
            }

            return {
                ...pollInsightObj,
                createdByUserProfilePicUrl: poll.createdByUserProfilePicUrl,
                isAnnonymous: poll.isAnonymous,
                createdByUsername: poll.createdByUsername,
                createdByUserId: poll.createdByUserId,
                bgImageUrl: poll.bgImageUrl,
                interests: (poll.interests || []).map((interest: any) => interest.name),
                isAnswered: pollResponses.length > 0
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async calculatePollInsights(poll: any, userId: string) {
        try {
            const pollId = poll._id;

            const pollResponses = await this.pollResponseModel.countDocuments({ pollId });

            if (!pollResponses) {
                return {
                    percentageData: [],
                    genderDate: [],
                    graphData: [],
                    geoLocationData: []
                };
            }

            const percentageData = await this.calculatePollResponsePercentages(poll, userId);
            const genderData = await this.calculateGenderData(poll);
            const graphData = await this.calculateGraphData(poll);
            const locationData = await this.calculateLocationData(poll);

            return { percentageData, genderData, graphData, locationData };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async calculatePollResponsePercentages(poll, userId) {
        try {
            const res = [];
            const pollId = poll._id;
            const questions = poll?.questions || [];
            for (const question of questions) {
                const questionRes = await this.calculateQuestionResponsePercentages(pollId, question, userId);
                res.push(questionRes);
            }
            return res;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async calculateQuestionResponsePercentages(pollId, question, userId) {
        try {
            const questionType = question.type;

            // calculate response percentages for this_that and single_choice questions

            if (
                questionType === QuestionTypes.THIS_THAT ||
                questionType === QuestionTypes.SINGLE_CHOICE ||
                questionType === QuestionTypes.MULTIPLE_CHOICE ||
                questionType === QuestionTypes.DATE
            ) {
                return await this.calculateResponsePercentagesFromSingleChoiceOrThisThat(pollId, question, userId);
            }

            // // calculate response percentages for multiple_choice and date questions
            // if (questionType === QuestionTypes.MULTIPLE_CHOICE || questionType === QuestionTypes.DATE) {
            //     return await this.calculateResponsePercentagesFromMultipleChoiceAndDate(pollId, question, userId);
            // }

            // calculate response percentages for ranking questions
            if (questionType === QuestionTypes.RANKING) {
                return await this.calculateResponsePercentagesFromRanking(pollId, question, userId);
            }

            // calculate response percentages for slider and light_meter questions
            if (questionType === QuestionTypes.SLIDER || questionType === QuestionTypes.LIGHT_METER) {
                return await this.calculateResponsePercentagesFromSliderAndLightMeter(pollId, question, userId);
            }
        } catch (error) {
            throw new RpcException(error);
        }
    }

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    async calculateResponsePercentagesFromSliderAndLightMeter(pollId: string, question: any, userId: string) {
        try {
            const questionId = question.id;

            // Step 1: Perform the aggregation
            const result = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId: pollId,
                        questionId: questionId,
                        sliderValue: { $exists: true } // Ensure that sliderValue exists
                    }
                },
                {
                    $group: {
                        _id: null,
                        avgSliderValue: { $avg: '$sliderValue' }
                    }
                }
            ]);

            // Step 2: Calculate percentage
            let avgSliderPercentage = 0;

            if (result && result.length > 0) {
                // Assuming sliders and ranking meters have a range of 0-100
                avgSliderPercentage = Number(Number((result[0].avgSliderValue / 100) * 100).toFixed(2));
            }

            const pollResponseCount = await this.pollResponseModel.countDocuments({
                pollId,
                questionId,
                sliderValue: { $exists: true }
            });

            // get user response
            // const pollResponses = await this.pollResponseModel.find({ pollId, questionId, userId });
            // const pollResponse =
            //     pollResponses && pollResponses?.length && pollResponses.length > 0 ? pollResponses[0] : null;
            // const sliderValue = pollResponse?.sliderValue || 0;

            return {
                pollId,
                ...question.toObject(),
                percentage: avgSliderPercentage,
                count: pollResponseCount
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async calculateResponsePercentagesFromSingleChoiceOrThisThat(pollId: string, question: any, userId: string) {
        try {
            const options = question?.options || [];

            // Step 1: Get the total count of responses for the question
            const totalResult = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId,
                        questionId: question.id
                    }
                },
                {
                    $count: 'totalResponses'
                }
            ]);

            const totalResponses = totalResult && totalResult.length > 0 ? totalResult[0].totalResponses : 0;

            const optionsArr = [];

            // Step 2: Get the count for each option
            for (const option of options) {
                let updatedOptionResponse = {};
                const optionId = option.id;
                const result = await this.pollResponseModel.aggregate([
                    {
                        $match: {
                            pollId,
                            questionId: question.id,
                            optionId
                        }
                    },
                    {
                        $count: 'count'
                    }
                ]);

                const count = result && result.length > 0 ? result[0].count : 0;
                const percentage = Number(Number(totalResponses > 0 ? (count / totalResponses) * 100 : 0).toFixed(2));

                updatedOptionResponse = { ...option.toObject(), count, percentage };
                optionsArr.push(updatedOptionResponse);

                // sort by percentage and sort by count for same percentages
                optionsArr.sort((a, b) => {
                    if (a.percentage === b.percentage) {
                        return b.count - a.count;
                    }
                    return b.percentage - a.percentage;
                });

                // add rank to each option. For same percentages, rank will be same and for other it will be in ascending order
                let lastIndex = 1;
                optionsArr.forEach((option, index) => {
                    if (index > 0 && option.percentage !== optionsArr[index - 1].percentage) {
                        lastIndex = lastIndex + 1;
                    }
                    option.rank = lastIndex;
                });
            }

            const pollResponses = await this.pollResponseModel.find({ pollId, questionId: question.id, userId });
            const pollResponse =
                pollResponses && pollResponses?.length && pollResponses.length > 0 ? pollResponses[0] : null;
            const optionId = pollResponse?.optionId || null;

            const updatedOptionsArr = optionsArr.map((option) => ({
                ...option,
                isSelected: option.id === optionId
            }));

            return {
                pollId,
                ...question.toObject(),
                options: updatedOptionsArr
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async calculateResponsePercentagesFromMultipleChoiceAndDate(pollId: string, question: any, userId) {
        try {
            const options = question?.options || [];

            // Step 1: Get the total count of responses for the question
            const totalResult = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId,
                        questionId: question.id
                    }
                },
                {
                    $count: 'totalResponses'
                }
            ]);

            const totalResponses = totalResult && totalResult.length > 0 ? totalResult[0].totalResponses : 0;

            const optionsMap = new Map<number, number>();

            // Step 2: Get the count for each optionId in optionIds
            const responses = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId,
                        questionId: question.id,
                        optionIds: { $exists: true, $ne: [] } // Ensure that optionIds exists and is not empty
                    }
                },
                {
                    $unwind: '$optionIds'
                },
                {
                    $group: {
                        _id: '$optionIds',
                        count: { $sum: 1 }
                    }
                }
            ]);

            // Process response counts
            responses.forEach((response) => {
                const optionId = response._id;
                const count = response.count;
                optionsMap.set(optionId, count);
            });

            // Build the options array with counts and percentages
            const optionsArr = options.map((option) => {
                const optionId = option.id;
                const count = optionsMap.get(optionId) || 0;
                const percentage = totalResponses > 0 ? (count / totalResponses) * 100 : 0;

                return {
                    ...option.toObject(),
                    count,
                    percentage: Number(percentage.toFixed(2))
                };
            });

            // sort by percentage and sort by count for same percentages
            optionsArr.sort((a, b) => {
                if (a.percentage === b.percentage) {
                    return b.count - a.count;
                }
                return b.percentage - a.percentage;
            });

            // add rank to each option. For same percentages, rank will be same and for other it will be in ascending order
            let lastIndex = 1;
            optionsArr.forEach((option, index) => {
                if (index > 0 && option.percentage !== optionsArr[index - 1].percentage) {
                    lastIndex = lastIndex + 1;
                }
                option.rank = lastIndex;
            });

            // get user response
            const pollResponses = await this.pollResponseModel.find({ pollId, questionId: question.id, userId });
            const pollResponse =
                pollResponses && pollResponses?.length && pollResponses.length > 0 ? pollResponses[0] : null;
            const optionIds = pollResponse?.optionIds || [];
            const updatedOptionsArr = optionsArr.map((option) => ({
                ...option,
                isSelected: optionIds.includes(option.id)
            }));

            return {
                pollId,
                ...question.toObject(),
                options: updatedOptionsArr
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async calculateResponsePercentagesFromRanking(pollId: string, question: any, userId: string) {
        try {
            const questionId = question.id;

            // Step 1: Get the total count of responses for the poll and question
            const totalResult = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId: pollId,
                        questionId: questionId,
                        order: { $exists: true } // Ensure order field exists (for ranking questions)
                    }
                },
                {
                    $group: {
                        _id: { userId: '$userId', questionId: '$questionId' } // Group by userId and questionId to count each user's response once per question
                    }
                },
                {
                    $count: 'totalResponses' // Count the unique groupings
                }
            ]);

            const totalResponses = totalResult && totalResult.length > 0 ? totalResult[0].totalResponses : 0;

            if (totalResponses === 0) {
                return {
                    pollId,
                    questionId,
                    options: [] // No responses, return empty options
                };
            }

            // Step 2: Group by optionId and order, and count occurrences
            const optionResults = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId: pollId,
                        questionId: questionId,
                        order: { $exists: true } // Ensure order field exists
                    }
                },
                {
                    $group: {
                        _id: { optionId: '$optionId', order: '$order' },
                        count: { $sum: 1 }
                    }
                },
                {
                    $sort: { '_id.order': 1 } // Sort by order to prioritize high   est ranks
                }
            ]);

            // Step 3: Organize results by optionId, and rank by highest occurrences of order 1, then order 2, etc.
            // Step 1: Group by optionId
            const groupedOptions = optionResults.reduce((acc, curr) => {
                const optionId = curr._id.optionId;
                const order = curr._id.order;
                const count = curr.count;

                if (!acc[optionId]) {
                    acc[optionId] = { optionId, ranks: {}, totalCount: 0 };
                }

                acc[optionId].ranks[order] = count; // Store count for the specific order
                acc[optionId].totalCount += count; // Total responses for this optionId
                return acc;
            }, {});

            // Step 2: Calculate the percentage for each order and prepare the result
            const result = Object.values(groupedOptions).map((option: any) => {
                const rankPercentages = Object.entries(option.ranks).map(([order, count]) => ({
                    order: parseInt(order), // Convert the order back to a number
                    percentage: Number(((Number(count) / Number(totalResponses)) * 100).toFixed(2)) || 0,
                    count
                }));

                return {
                    optionId: option.optionId,
                    ranks: rankPercentages // Array of rank and their respective percentages
                };
            });

            // Step 4: Calculate percentages and format result
            // Step 1: Flatten all ranks and keep track of the optionId
            const allRanks = [];

            result.forEach((option) => {
                option.ranks.forEach((rank) => {
                    allRanks.push({
                        optionId: option.optionId,
                        order: rank.order,
                        percentage: rank.percentage,
                        count: rank.count
                    });
                });
            });

            // Step 2: Sort ranks by 'order' in ascending order
            allRanks.sort((a, b) => a.order - b.order);

            const rankResult = {};
            const usedOrders = new Set(); // Keep track of assigned orders

            // Step 4: Process all ranks and store highest percentage for each option
            allRanks.forEach((item) => {
                const { optionId, order, percentage, count } = item;

                // If this is the first time seeing the optionId, initialize its data
                if (!rankResult[optionId]) {
                    rankResult[optionId] = { highestOrder: order, highestPercentage: percentage, count };
                } else {
                    // If the current percentage is higher than the stored one, update the result
                    if (percentage > rankResult[optionId].highestPercentage) {
                        rankResult[optionId] = { highestOrder: order, highestPercentage: percentage, count };
                    }
                }
            });

            // Step 5: Sort the options by percentage (descending) and resolve order conflicts
            const sortedOptions = Object.keys(rankResult)
                .map((key) => ({
                    optionId: Number(key),
                    ...rankResult[key]
                }))
                .sort((a, b) => b.highestPercentage - a.highestPercentage); // Sort by percentage in descending order

            const availableOrders = [...Array(sortedOptions.length).keys()].map((i) => i + 1); // Generate available order values

            sortedOptions.forEach((option) => {
                const { highestOrder } = option;

                // If the order is already used, assign the next available one
                if (usedOrders.has(highestOrder)) {
                    const newOrder = availableOrders.shift(); // Get the next available order
                    option.highestOrder = newOrder; // Assign new order
                    usedOrders.add(newOrder); // Mark the new order as used
                } else {
                    usedOrders.add(highestOrder); // Mark the original order as used
                    availableOrders.splice(availableOrders.indexOf(highestOrder), 1); // Remove the used order
                }
            });

            // Step 6: Prepare the final response
            const response: any = sortedOptions.map((option) => ({
                optionId: option.optionId,
                highestOrder: option.highestOrder,
                percentage: Number(Number(option.highestPercentage || 0).toFixed(2)),
                count: option.count
            }));

            // sort by percentage and sort by count for same percentages
            response.sort((a, b) => {
                if (a.percentage === b.percentage) {
                    return b.count - a.count;
                }
                return b.percentage - a.percentage;
            });

            // add rank to each option. For same percentages, rank will be same and for other it will be in ascending order
            let lastIndex = 1;
            response.forEach((option, index) => {
                if (index > 0 && option.percentage !== response[index - 1].percentage) {
                    lastIndex = lastIndex + 1;
                }
                option.rank = lastIndex;
            });

            const questionOptions = question?.options || [];
            const responseOptions = response.map((option) => {
                const questionOption = questionOptions.find((qOption) => qOption.id === option.optionId);
                return {
                    ...questionOption.toObject(),
                    ...option
                };
            });

            // get user response
            const pollResponses = await this.pollResponseModel.find({ pollId, questionId, userId });
            const updatedOptionsArr = responseOptions.map((option) => {
                const pollResponse = pollResponses.find((response) => response.optionId === option.id);
                return {
                    ...option,
                    selectedRank: pollResponse?.order || null
                };
            });

            return {
                pollId,
                ...question.toObject(),
                options: updatedOptionsArr
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async calculateGenderData(poll) {
        try {
            const res = [];
            const pollId = poll._id;
            const questions = poll?.questions || [];
            for (const question of questions) {
                const questionRes = await this.genderPercentages(pollId, question);
                res.push(questionRes);
            }
            return res;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async genderPercentages(pollId: string, question: any) {
        try {
            const questionId = question.id;

            // Step 1: Get the total count of unique responses for the question (unique by pollId and userId)
            const totalResponsesResult = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId: pollId,
                        questionId: questionId,
                        gender: { $exists: true, $ne: null } // Ensure gender field exists
                    }
                },
                {
                    $group: {
                        _id: { pollId: '$pollId', userId: '$userId' } // Group by pollId and userId to ensure uniqueness
                    }
                },
                {
                    $count: 'totalResponses' // Count unique pollId-userId combinations
                }
            ]);

            const totalResponses =
                totalResponsesResult && totalResponsesResult.length > 0 ? totalResponsesResult[0].totalResponses : 0;

            if (totalResponses === 0) {
                return {
                    pollId,
                    questionId,
                    genderData: [] // No responses, return empty data
                };
            }

            // Step 2: Group by gender and count unique occurrences of pollId-userId for each gender
            const genderResults = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId: pollId,
                        questionId: questionId,
                        gender: { $exists: true, $ne: null } // Ensure gender field exists
                    }
                },
                {
                    $group: {
                        _id: { gender: '$gender', pollId: '$pollId', userId: '$userId' } // Group by gender and unique pollId-userId
                    }
                },
                {
                    $group: {
                        _id: '$_id.gender', // Group by gender
                        count: { $sum: 1 } // Count unique responses for each gender
                    }
                },
                {
                    $project: {
                        _id: 0,
                        gender: '$_id',
                        count: 1,
                        percentage: {
                            $multiply: [{ $divide: ['$count', totalResponses] }, 100] // Calculate percentage for each gender
                        }
                    }
                }
            ]);

            const gendersArr: any = genderResults.map((result) => ({
                gender: result.gender,
                count: result.count,
                percentage: Number(result.percentage.toFixed(2)) // Format percentage to two decimal places
            }));

            // Sort by percentage and count
            gendersArr.sort((a, b) => {
                if (a.percentage === b.percentage) {
                    return b.count - a.count;
                }
                return b.percentage - a.percentage;
            });

            // Assign rank based on percentage (same percentage gets the same rank)
            let lastIndex = 1;
            gendersArr.forEach((option, index) => {
                if (index > 0 && option.percentage !== gendersArr[index - 1].percentage) {
                    lastIndex += 1;
                }
                option.rank = lastIndex;
            });

            return {
                pollId,
                questionId,
                genderData: gendersArr
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async calculateLocationData(poll: any) {
        try {
            const res = [];
            const pollId = poll._id;
            const questions = poll?.questions || [];
            for (const question of questions) {
                const questionRes = await this.locationPercentages(pollId, question);
                res.push(questionRes);
            }
            return res;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async locationPercentages(pollId: string, question: any) {
        try {
            const questionId = question.id;

            // Step 1: Get total count of unique responses for the poll and question (unique by pollId and userId)
            const totalResponsesResult = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId: pollId,
                        questionId: questionId
                    }
                },
                {
                    $group: {
                        _id: { pollId: '$pollId', userId: '$userId' } // Group by pollId and userId to ensure uniqueness
                    }
                },
                {
                    $count: 'totalResponses'
                }
            ]);

            const totalResponses =
                totalResponsesResult && totalResponsesResult.length > 0 ? totalResponsesResult[0].totalResponses : 0;

            if (totalResponses === 0) {
                return {
                    pollId,
                    questionId,
                    cityData: [],
                    stateData: [],
                    countryData: []
                };
            }

            // Step 2: Group by city and calculate percentages based on unique pollId and userId
            const cityResults = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId: pollId,
                        questionId: questionId,
                        city: { $exists: true, $ne: null }
                    }
                },
                {
                    $group: {
                        _id: { city: '$city', pollId: '$pollId', userId: '$userId' } // Group by city, pollId, and userId
                    }
                },
                {
                    $group: {
                        _id: '$_id.city', // Group by city
                        count: { $sum: 1 } // Count unique responses for each city
                    }
                },
                {
                    $project: {
                        _id: 0,
                        city: '$_id',
                        count: 1,
                        percentage: { $multiply: [{ $divide: ['$count', totalResponses] }, 100] } // Calculate percentage
                    }
                }
            ]);

            // Step 3: Group by state and calculate percentages based on unique pollId and userId
            const stateResults = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId: pollId,
                        questionId: questionId,
                        state: { $exists: true, $ne: null }
                    }
                },
                {
                    $group: {
                        _id: { state: '$state', pollId: '$pollId', userId: '$userId' } // Group by state, pollId, and userId
                    }
                },
                {
                    $group: {
                        _id: '$_id.state', // Group by state
                        count: { $sum: 1 } // Count unique responses for each state
                    }
                },
                {
                    $project: {
                        _id: 0,
                        state: '$_id',
                        count: 1,
                        percentage: { $multiply: [{ $divide: ['$count', totalResponses] }, 100] } // Calculate percentage
                    }
                }
            ]);

            // Step 4: Group by country and calculate percentages based on unique pollId and userId
            const countryResults = await this.pollResponseModel.aggregate([
                {
                    $match: {
                        pollId: pollId,
                        questionId: questionId,
                        country: { $exists: true, $ne: null }
                    }
                },
                {
                    $group: {
                        _id: { country: '$country', pollId: '$pollId', userId: '$userId' } // Group by country, pollId, and userId
                    }
                },
                {
                    $group: {
                        _id: '$_id.country', // Group by country
                        count: { $sum: 1 } // Count unique responses for each country
                    }
                },
                {
                    $project: {
                        _id: 0,
                        country: '$_id',
                        count: 1,
                        percentage: { $multiply: [{ $divide: ['$count', totalResponses] }, 100] } // Calculate percentage
                    }
                }
            ]);

            const cityArr: any = cityResults.map((result) => ({
                city: result.city,
                count: result.count,
                percentage: Number(result.percentage.toFixed(2))
            }));

            const stateArr: any = stateResults.map((result) => ({
                state: result.state,
                count: result.count,
                percentage: Number(result.percentage.toFixed(2))
            }));

            const countryArr: any = countryResults.map((result) => ({
                country: result.country,
                count: result.count,
                percentage: Number(result.percentage.toFixed(2))
            }));

            // Sort and rank city data
            cityArr.sort((a, b) => {
                if (a.percentage === b.percentage) {
                    return b.count - a.count;
                }
                return b.percentage - a.percentage;
            });

            let cityLastIndex = 1;
            cityArr.forEach((option, index) => {
                if (index > 0 && option.percentage !== cityArr[index - 1].percentage) {
                    cityLastIndex = cityLastIndex + 1;
                }
                option.rank = cityLastIndex;
            });

            // Sort and rank state data
            stateArr.sort((a, b) => {
                if (a.percentage === b.percentage) {
                    return b.count - a.count;
                }
                return b.percentage - a.percentage;
            });

            let stateLastIndex = 1;
            stateArr.forEach((option, index) => {
                if (index > 0 && option.percentage !== stateArr[index - 1].percentage) {
                    stateLastIndex = stateLastIndex + 1;
                }
                option.rank = stateLastIndex;
            });

            // Sort and rank country data
            countryArr.sort((a, b) => {
                if (a.percentage === b.percentage) {
                    return b.count - a.count;
                }
                return b.percentage - a.percentage;
            });

            let countryLastIndex = 1;
            countryArr.forEach((option, index) => {
                if (index > 0 && option.percentage !== countryArr[index - 1].percentage) {
                    countryLastIndex = countryLastIndex + 1;
                }
                option.rank = countryLastIndex;
            });

            return {
                pollId,
                questionId,
                cityData: cityArr,
                stateData: stateArr,
                countryData: countryArr
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async calculateGraphData(poll: any) {
        try {
            const pollId = poll?._id;

            // Count the total number of unique responses for the given poll (unique by pollId and userId)
            const totalResponses = await this.pollResponseModel.aggregate([
                {
                    $match: { pollId } // Filter by the pollId
                },
                {
                    $group: {
                        _id: { pollId: '$pollId', userId: '$userId' } // Group by pollId and userId to ensure uniqueness
                    }
                },
                {
                    $count: 'uniqueResponseCount' // Count the unique responses
                }
            ]);

            // Handle case where there are no responses
            if (totalResponses.length === 0) {
                return {
                    totalResponses: 0,
                    dateWisePercentages: []
                };
            }

            const uniqueCount = totalResponses[0]?.uniqueResponseCount || 0;

            // Aggregate unique responses by date and calculate the percentage for each date
            const responses = await this.pollResponseModel.aggregate([
                {
                    $match: { pollId } // Filter by the pollId
                },
                {
                    $group: {
                        _id: {
                            year: { $year: '$createdAt' }, // Extract year from the date
                            month: { $month: '$createdAt' }, // Extract month from the date
                            day: { $dayOfMonth: '$createdAt' }, // Extract day from the date
                            pollId: '$pollId',
                            userId: '$userId' // Ensure uniqueness by grouping by pollId and userId
                        },
                        dateResponses: { $sum: 1 } // Count total responses for that date
                    }
                },
                {
                    $group: {
                        _id: {
                            year: '$_id.year',
                            month: '$_id.month',
                            day: '$_id.day'
                        },
                        dateResponses: { $sum: 1 } // Sum the responses grouped by date
                    }
                },
                {
                    $project: {
                        _id: 0,
                        date: {
                            $concat: [
                                { $toString: '$_id.year' },
                                '-',
                                {
                                    $cond: [
                                        { $lt: ['$_id.month', 10] },
                                        { $concat: ['0', { $toString: '$_id.month' }] },
                                        { $toString: '$_id.month' }
                                    ]
                                },
                                '-',
                                {
                                    $cond: [
                                        { $lt: ['$_id.day', 10] },
                                        { $concat: ['0', { $toString: '$_id.day' }] },
                                        { $toString: '$_id.day' }
                                    ]
                                }
                            ]
                        },
                        percentage: {
                            $multiply: [{ $divide: ['$dateResponses', uniqueCount] }, 100] // Calculate percentage based on unique responses
                        },
                        count: '$dateResponses' // Include the count of responses for the date
                    }
                },
                {
                    $sort: { date: 1 } // Sort by date in ascending order
                }
            ]);

            // sort by percentage and then by count for equal percentages
            responses.sort((a, b) => {
                if (a.percentage === b.percentage) {
                    return b.count - a.count;
                }
                return b.percentage - a.percentage;
            });

            // Assign rank to each date based on percentage (handle equal percentages with the same rank)
            let lastIndex = 1;
            responses.forEach((response, index) => {
                if (index > 0 && response.percentage !== responses[index - 1].percentage) {
                    lastIndex += 1;
                }
                response.rank = lastIndex;
            });

            // Format the percentage to 2 decimal places
            responses.forEach((response) => {
                response.percentage = Number(response.percentage.toFixed(2));
            });

            return {
                totalResponses: uniqueCount,
                dateWisePercentages: responses
            };
        } catch (err) {
            throw new RpcException(err);
        }
    }

    async calculatePollInsightFromPollResponse(pollResponse: any, userId: string) {
        try {
            const { pollId, questionId } = pollResponse;
            if (!pollId || !questionId) {
                return;
            }

            const poll = await this.pollModel.findById(pollId);

            if (!poll?._id) {
                return;
            }

            const existingInsight = await this.pollInsightsModel.findOne({ pollId, isDeleted: false });

            if (!existingInsight) {
                const result = await this.createPollInsight(poll._id.toString(), userId);
                return result;
            } else {
                const newInsight = await this.calculateNewInsight(poll, userId, existingInsight, pollResponse);
                return newInsight;
            }
        } catch (error) {
            throw new RpcException(error);
        }
    }

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    async calculateNewInsight(poll: any, userId: string, existingInsight: any, pollResponse: any) {
        try {
            const {
                removeResponse = false,
                questionType = '',
                updateGender = false,
                updatedGender = ''
            } = pollResponse;

            const newInsight: any = {};

            const uniqueCombinations = await this.pollResponseHistoryModel.aggregate([
                {
                    $match: {
                        pollId: poll._id,
                        isDeleted: false
                    }
                },
                {
                    $group: {
                        _id: {
                            pollId: '$pollId',
                            userId: '$userId'
                        }
                    }
                },
                {
                    $count: 'uniqueCount'
                }
            ]);

            // Return the count (if the array is empty, return 0)
            const votersCount = uniqueCombinations.length > 0 ? uniqueCombinations[0].uniqueCount : 0;

            if (updateGender) {
                const {
                    // eslint-disable-next-line prefer-const
                    insights: { percentageData = [], genderData = [], graphData = [], locationData = [] } = {},
                    totalVotes = 0
                } = existingInsight;

                const newGenderData = await this.calculateNewGenderDataAfterGenderChange(
                    genderData,
                    pollResponse,
                    updatedGender,
                    totalVotes
                );
                newInsight.genderData = newGenderData;
                newInsight.percentageData = percentageData;
                newInsight.graphData = graphData;
                newInsight.locationData = locationData;

                await this.pollInsightsModel.updateOne(
                    { pollId: poll._id },
                    { insights: newInsight, totalVotes, votersCount }
                );
            } else if (!removeResponse) {
                // eslint-disable-next-line prefer-const
                let {
                    // eslint-disable-next-line prefer-const
                    insights: { percentageData = [], genderData = [], graphData = [], locationData = [] } = {},
                    totalVotes = 0
                } = existingInsight;

                if (questionType === QuestionTypes.SLIDER || questionType === QuestionTypes.LIGHT_METER) {
                    // update existing poll insights
                    const newPercentageData = this.calculateNewSliderPercentageData(percentageData, pollResponse);

                    newInsight.percentageData = newPercentageData;
                    // return 'called calculate new insights slider';
                    const newgenderData = this.calculateNewGenderData(genderData, pollResponse, totalVotes);
                    newInsight.genderData = newgenderData;
                    const newGraphData = this.calculateNewGraphData(graphData, pollResponse, totalVotes);

                    newInsight.graphData = newGraphData;
                    const newLocationData = this.calculateNewLocationData(locationData, pollResponse, totalVotes);
                    newInsight.locationData = newLocationData;

                    totalVotes++;

                    await this.pollInsightsModel.updateOne(
                        { pollId: poll._id },
                        { insights: newInsight, totalVotes, votersCount }
                    );
                } else if (
                    questionType === QuestionTypes.THIS_THAT ||
                    questionType === QuestionTypes.SINGLE_CHOICE ||
                    questionType === QuestionTypes.DATE ||
                    questionType === QuestionTypes.MULTIPLE_CHOICE
                ) {
                    const newPercentageData = this.calculateNewThisThatOrSingleChoicePercentageData(
                        percentageData,
                        pollResponse,
                        totalVotes
                    );

                    newInsight.percentageData = newPercentageData;
                    // return 'called calculate new insights this that';
                    const newgenderData = this.calculateNewGenderData(genderData, pollResponse, totalVotes);
                    newInsight.genderData = newgenderData;
                    const newGraphData = this.calculateNewGraphData(graphData, pollResponse, totalVotes);

                    newInsight.graphData = newGraphData;
                    const newLocationData = this.calculateNewLocationData(locationData, pollResponse, totalVotes);
                    newInsight.locationData = newLocationData;

                    totalVotes++;

                    await this.pollInsightsModel.updateOne(
                        { pollId: poll._id },
                        { insights: newInsight, totalVotes, votersCount }
                    );
                } else if (questionType === QuestionTypes.RANKING) {
                    const newPercentageData = this.calculateNewRankingPercentageData(percentageData, pollResponse);
                    newInsight.percentageData = newPercentageData;
                    // return 'called calculate new insights this that';
                    const newgenderData = this.calculateNewGenderData(genderData, pollResponse, totalVotes);
                    newInsight.genderData = newgenderData;
                    const newGraphData = this.calculateNewGraphData(graphData, pollResponse, totalVotes);

                    newInsight.graphData = newGraphData;
                    const newLocationData = this.calculateNewLocationData(locationData, pollResponse, totalVotes);
                    newInsight.locationData = newLocationData;

                    totalVotes++;

                    await this.pollInsightsModel.updateOne(
                        { pollId: poll._id },
                        { insights: newInsight, totalVotes, votersCount }
                    );
                }

                await this.pollModel.updateOne({ _id: poll._id }, { votes: totalVotes, votersCount });
            } else if (removeResponse) {
                let {
                    // eslint-disable-next-line prefer-const
                    insights: { percentageData = [], genderData = [], graphData = [], locationData = [] } = {},
                    totalVotes = 0
                } = existingInsight;
                if (questionType === QuestionTypes.SLIDER || questionType === QuestionTypes.LIGHT_METER) {
                    // update existing poll insights
                    const newPercentageData = this.calculateNewSliderPercentageDataAfterRemoving(
                        percentageData,
                        pollResponse
                    );

                    newInsight.percentageData = newPercentageData;
                    const newgenderData = this.calculateNewGenderDataAfterRemoving(
                        genderData,
                        pollResponse,
                        totalVotes
                    );

                    newInsight.genderData = newgenderData;
                    const newGraphData = this.calculateNewGraphDataAfterRemoving(graphData, pollResponse, totalVotes);

                    newInsight.graphData = newGraphData;
                    const newLocationData = this.calculateNewLocationDataAfterRemoving(
                        locationData,
                        pollResponse,
                        totalVotes
                    );
                    newInsight.locationData = newLocationData;

                    totalVotes--;

                    await this.pollInsightsModel.updateOne(
                        { pollId: poll._id },
                        { insights: newInsight, totalVotes, votersCount }
                    );
                } else if (
                    questionType === QuestionTypes.THIS_THAT ||
                    questionType === QuestionTypes.SINGLE_CHOICE ||
                    questionType === QuestionTypes.MULTIPLE_CHOICE ||
                    questionType === QuestionTypes.DATE
                ) {
                    const newPercentageData = this.calculateNewThisThatOrSingleChoicePercentageDataAfterRemoving(
                        percentageData,
                        pollResponse,
                        totalVotes
                    );

                    newInsight.percentageData = newPercentageData;
                    const newgenderData = this.calculateNewGenderDataAfterRemoving(
                        genderData,
                        pollResponse,
                        totalVotes
                    );

                    newInsight.genderData = newgenderData;
                    const newGraphData = this.calculateNewGraphDataAfterRemoving(graphData, pollResponse, totalVotes);

                    newInsight.graphData = newGraphData;
                    const newLocationData = this.calculateNewLocationDataAfterRemoving(
                        locationData,
                        pollResponse,
                        totalVotes
                    );
                    newInsight.locationData = newLocationData;

                    totalVotes--;

                    await this.pollInsightsModel.updateOne(
                        { pollId: poll._id },
                        { insights: newInsight, totalVotes, votersCount }
                    );
                } else if (questionType === QuestionTypes.RANKING) {
                    const newPercentageData = this.calculateNewRankingPercentageDataAfterRemoving(
                        percentageData,
                        pollResponse
                    );

                    newInsight.percentageData = newPercentageData;
                    const newgenderData = this.calculateNewGenderDataAfterRemoving(
                        genderData,
                        pollResponse,
                        totalVotes
                    );

                    newInsight.genderData = newgenderData;
                    const newGraphData = this.calculateNewGraphDataAfterRemoving(graphData, pollResponse, totalVotes);

                    newInsight.graphData = newGraphData;
                    const newLocationData = this.calculateNewLocationDataAfterRemoving(
                        locationData,
                        pollResponse,
                        totalVotes
                    );
                    newInsight.locationData = newLocationData;

                    totalVotes--;

                    await this.pollInsightsModel.updateOne(
                        { pollId: poll._id },
                        { insights: newInsight, totalVotes, votersCount }
                    );
                }
                await this.pollModel.updateOne({ _id: poll._id }, { votes: totalVotes, votersCount });
            }

            return 'called calculate new insights';
        } catch (error) {
            throw new RpcException(error);
        }
    }

    // TODO: Remove commented code
    // calculateNewLocationDataForMultipleSelection(locationData, pollResponse, totalVotes) {
    //     try {
    //         const { responses = [], questionId = '' } = pollResponse;
    //         const newVoteCount = responses.length;

    //         for (const response of responses) {
    //             for (const data of locationData) {
    //                 if (data?.questionId === questionId) {
    //                     const { city = '', state = '', country = '' } = response;

    //                     let cityName = city;
    //                     if (!city) {
    //                         cityName = UNKNOWN;
    //                     }

    //                     let stateName = state;
    //                     if (!state) {
    //                         stateName = UNKNOWN;
    //                     }

    //                     let countryName = country;
    //                     if (!country) {
    //                         countryName = UNKNOWN;
    //                     }

    //                     // check if city is not available
    //                     let cityDetail = data.cityData.find((c) => c.city === cityName);
    //                     if (!cityDetail) {
    //                         cityDetail = { city: cityName, count: 0, percentage: 0 };
    //                         data.cityData.push(cityDetail);
    //                     }

    //                     // check if state is not available
    //                     let stateDetail = data.stateData.find((s) => s.state === stateName);
    //                     if (!stateDetail) {
    //                         stateDetail = { state: stateName, count: 0, percentage: 0 };
    //                         data.stateData.push(stateDetail);
    //                     }

    //                     // check if country is not available
    //                     let countryDetail = data.countryData.find((c) => c.country === countryName);
    //                     if (!countryDetail) {
    //                         countryDetail = { country: countryName, count: 0, percentage: 0 };
    //                         data.countryData.push(countryDetail);
    //                     }

    //                     // TODO: Manage unknown location data

    //                     // Update city data
    //                     (data.cityData || []).forEach((cityData) => {
    //                         if (cityData.city === cityName) {
    //                             cityData.count++;
    //                             cityData.lat = response?.lat || '';
    //                             cityData.lon = response?.lon || '';
    //                         }
    //                         cityData.percentage = Number(
    //                             Number((cityData.count / (totalVotes + newVoteCount)) * 100).toFixed(2)
    //                         );
    //                     });
    //                     // Update city data
    //                     (data.stateData || []).forEach((stateData) => {
    //                         if (stateData.state === stateName) {
    //                             stateData.count++;
    //                             stateData.lat = response?.lat || '';
    //                             stateData.lon = response?.lon || '';
    //                         }
    //                         stateData.percentage = Number(
    //                             Number((stateData.count / (totalVotes + newVoteCount)) * 100).toFixed(2)
    //                         );
    //                     });
    //                     // Update city data
    //                     (data.countryData || []).forEach((countryData) => {
    //                         if (countryData.country === countryName) {
    //                             countryData.count++;
    //                             countryData.lat = response?.lat || '';
    //                             countryData.lon = response?.lon || '';
    //                         }
    //                         countryData.percentage = Number(
    //                             Number((countryData.count / (totalVotes + newVoteCount)) * 100).toFixed(2)
    //                         );
    //                     });

    //                     break;
    //                 }
    //             }
    //         }

    //         return { ...locationData };
    //     } catch (error) {
    //         throw new RpcException(error);
    //     }
    // }

    // calculateNewGraphDataForMultipleSelection(graphData, pollResponse, totalVotes) {
    //     try {
    //         const { responses = [] } = pollResponse;
    //         const newVoteCount = responses.length;

    //         for (const response of responses) {
    //             const { createdAt = new Date() } = response;
    //             const { year, month, day } = this.getYearMonthDayFromDate(createdAt);
    //             const date = `${year}-${month}-${day}`;

    //             let dateData = (graphData?.dateWisePercentages || []).find((data) => data.date === date);
    //             if (!dateData) {
    //                 dateData = { date, count: 0, percentage: 0 };
    //                 graphData.dateWisePercentages.push(dateData);
    //             }

    //             // dateData.count++;

    //             (graphData?.dateWisePercentages || []).forEach((data) => {
    //                 if (data.date === date) {
    //                     data.count++;
    //                 }
    //                 data.percentage = Number(Number((data.count / (totalVotes + newVoteCount)) * 100).toFixed(2));
    //             });
    //         }

    //         // TODO: add percentage and rank field and manage total responses count
    //         return { ...graphData };
    //     } catch (error) {
    //         throw new RpcException(error);
    //     }
    // }

    // calculateNewGenderDataForMultipleSelection(genderDetails, pollResponse, totalVotes) {
    //     try {
    //         const { questionId = '', responses = [] } = pollResponse;
    //         const newVoteCount = responses.length;

    //         for (const data of genderDetails) {
    //             if (data.questionId === questionId) {
    //                 // if gender is not available in response add unknown label

    //                 for (const response of responses || []) {
    //                     const { gender = '' } = response;

    //                     let genderName = gender;
    //                     if (!gender) {
    //                         genderName = UNKNOWN;
    //                     }

    //                     // if gender is not there in data.genderDate, add it
    //                     const _gender = (data?.genderData || []).find(
    //                         (_genderData) => _genderData.gender === genderName
    //                     );
    //                     if (!_gender) {
    //                         data.genderData.push({
    //                             gender: genderName,
    //                             count: 0,
    //                             percentage: 0
    //                         });
    //                     }

    //                     (data.genderData || []).forEach((_genderData) => {
    //                         if (_genderData?.gender === genderName) {
    //                             _genderData.count++;
    //                         }
    //                         _genderData.percentage = Number(
    //                             Number((_genderData.count / (totalVotes + newVoteCount)) * 100).toFixed(2)
    //                         );
    //                     });
    //                 }

    //                 break; // Exit the loop after finding the matching questionId
    //             }
    //         }

    //         // TODO: manage total votes count
    //         return { ...genderDetails };
    //     } catch (error) {
    //         throw new RpcException(error);
    //     }
    // }

    // calculateNewMultipleSelectionPercentageData(percentageData, pollResponse, totalVotes) {
    //     try {
    //         const { questionId = '' } = pollResponse;
    //         const newVoteCount = pollResponse?.responses?.length || 0;

    //         for (const data of percentageData) {
    //             if (data.id === questionId) {
    //                 // data.options.forEach((option) => {
    //                 //     const optionId = option.id;
    //                 //     const count = pollResponse?.responses?.filter((response) => response === optionId).length || 0;

    //                 //     option.count = option.count + count;
    //                 //     option.percentage = Number(Number((option.count / (totalVotes + newVoteCount)) * 100).toFixed(2));
    //                 // });
    //                 // break;

    //                 const optionIds = (pollResponse?.responses || []).map((response) => response.optionId);

    //                 data.options = (data.options || []).map((option) => {
    //                     if (!option?.count) {
    //                         option.count = 0;
    //                     }
    //                     if (!option.percentage) {
    //                         option.percentage = 0;
    //                     }
    //                     return option;
    //                 });

    //                 data.options.forEach((option) => {
    //                     if (optionIds.includes(option.id)) {
    //                         option.count++;
    //                     }
    //                     option.percentage = Number(
    //                         Number((option.count / (totalVotes + newVoteCount)) * 100).toFixed(2)
    //                     );
    //                 });
    //                 break; // Exit the loop after finding the matching questionId
    //             }
    //         }

    //         return { ...percentageData };
    //     } catch (error) {
    //         throw new RpcException(error);
    //     }
    // }

    async calculateNewGenderDataAfterGenderChange(genderDetails, pollResponse, updatedGender, totalVotes) {
        try {
            if (!updatedGender) {
                return genderDetails;
            }
            const { questionId = '' } = pollResponse;
            const originalGender = pollResponse?.gender || UNKNOWN;

            for (const data of genderDetails) {
                // Check if we have matching questionId
                if (data.questionId === questionId) {
                    (data.genderData || []).forEach((_genderData) => {
                        // Reduce count and percentage for the original gender
                        if (_genderData.gender === originalGender) {
                            _genderData.count = Math.max(0, _genderData.count - 1);
                        }

                        // Increase count for the updated gender
                        if (_genderData.gender === updatedGender) {
                            _genderData.count += 1;
                        }
                    });

                    // Recalculate percentages for each gender after modification
                    const newTotalVotes = totalVotes; // No change in total votes, only redistribution across genders

                    data.genderData.forEach((_genderData) => {
                        _genderData.percentage =
                            newTotalVotes > 0 ? Number(((_genderData.count / newTotalVotes) * 100).toFixed(2)) : 0;
                    });

                    await this.pollResponseModel.updateOne(
                        {
                            _id: pollResponse._id
                        },
                        {
                            gender: updatedGender
                        }
                    );

                    break; // Stop after processing the relevant questionId
                }
            }

            return genderDetails;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewRankingPercentageData(percentageData, pollResponse) {
        try {
            const { questionId = '', optionWeightage = 0 } = pollResponse;

            for (const data of percentageData) {
                if (data.id === questionId) {
                    (data.options || []).forEach((option) => {
                        if (!option?.weightage) {
                            option.weightage = 0;
                        }
                    });

                    data.options = data.options.map((option) => {
                        if (option.id === pollResponse.optionId) {
                            option.weightage = option.weightage + optionWeightage;
                        }
                        return option;
                    });
                    break;
                }
            }
            return percentageData;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewRankingPercentageDataAfterRemoving(percentageData, pollResponse) {
        try {
            const { questionId = '', optionWeightage = 0 } = pollResponse;

            for (const data of percentageData) {
                if (data.id === questionId) {
                    (data.options || []).forEach((option) => {
                        if (!option?.weightage) {
                            option.weightage = 0;
                        }
                    });

                    data.options = data.options.map((option) => {
                        if (option.id === pollResponse.optionId) {
                            option.weightage = option.weightage - optionWeightage;
                            if (option.weightage < 0) {
                                option.weightage = 0;
                            }
                        }
                        return option;
                    });

                    break;
                }
            }
            return percentageData;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewSliderPercentageData(percentageData, pollResponse) {
        try {
            const { questionId = '', sliderValue = 0 } = pollResponse;

            for (const data of percentageData) {
                if (data.id === questionId) {
                    if (!data?.count) {
                        data.count = 1;
                        data.percentage = sliderValue;
                    } else {
                        // Calculate the new count
                        const newCount = data.count + 1;

                        // Calculate the new percentage using the weighted average
                        const newPercentage = (data.percentage * data.count + sliderValue) / newCount;

                        // Update the data object with the new values
                        data.percentage = newPercentage;
                        data.count = newCount;
                    }

                    break; // Exit the loop after finding the matching questionId
                }
            }

            return percentageData;
        } catch (error) {
            throw new RpcException(error);
        }
    }
    calculateNewSliderPercentageDataAfterRemoving(percentageData, pollResponse) {
        try {
            const { questionId = '', sliderValue = 0 } = pollResponse;

            for (const data of percentageData) {
                if (data.id === questionId) {
                    // Calculate the new count
                    const newCount = data.count - 1;

                    let newPercentage = 0;
                    if (newCount > 0) {
                        // Calculate the new percentage using the weighted average
                        newPercentage = (data.percentage * data.count - sliderValue) / newCount;
                    }

                    // Update the data object with the new values
                    data.percentage = newPercentage;
                    data.count = newCount < 0 ? 0 : newCount;
                    data.sliderValue = newPercentage; // Update sliderValue if needed

                    break; // Exit the loop after finding the matching questionId
                }
            }

            return percentageData;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewThisThatOrSingleChoicePercentageDataAfterRemoving(percentageData, pollResponse, totalVotes) {
        try {
            const { questionId = '', optionId = '' } = pollResponse;

            for (const data of percentageData) {
                if (data.id === questionId) {
                    data.options.forEach((option) => {
                        if (option?.id === optionId) {
                            option.count--;
                        }

                        if (option.count <= 0 || totalVotes - 1 <= 0) {
                            option.count = 0;
                            option.percentage = 0;
                        } else {
                            option.percentage = Number(Number((option.count / (totalVotes - 1)) * 100).toFixed(2));
                        }
                    });

                    break; // Exit the loop after finding the matching questionId
                }
            }

            return percentageData;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewThisThatOrSingleChoicePercentageData(percentageData, pollResponse, totalVotes) {
        try {
            const { questionId = '', optionId = '' } = pollResponse;

            for (const data of percentageData) {
                if (data.id === questionId) {
                    data.options = (data.options || []).map((option) => {
                        if (!option?.count) {
                            option.count = 0;
                        }
                        if (!option.percentage) {
                            option.percentage = 0;
                        }
                        return option;
                    });

                    data.options.forEach((option) => {
                        if (option?.id === optionId) {
                            option.count++;
                        }
                        option.percentage = Number(Number((option.count / (totalVotes + 1)) * 100).toFixed(2));
                    });
                    break; // Exit the loop after finding the matching questionId
                }
            }

            return percentageData;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewGenderData(genderDetails, pollResponse, totalVotes) {
        try {
            const { questionId = '' } = pollResponse;

            for (const data of genderDetails) {
                if (data.questionId === questionId) {
                    // if gender is not available in response add unknown label
                    const { gender = '' } = pollResponse;

                    let genderName = gender;
                    if (!gender) {
                        genderName = UNKNOWN;
                    }

                    // if gender is not there in data.genderDate, add it
                    const _gender = (data?.genderData || []).find((_genderData) => _genderData.gender === genderName);
                    if (!_gender) {
                        data.genderData.push({
                            gender: genderName,
                            count: 0,
                            percentage: 0
                        });
                    }

                    (data.genderData || []).forEach((_genderData) => {
                        if (_genderData?.gender === genderName) {
                            _genderData.count++;
                        }
                        _genderData.percentage = Number(
                            Number((_genderData.count / (totalVotes + 1)) * 100).toFixed(2)
                        );
                    });
                    break; // Exit the loop after finding the matching questionId
                }
            }

            // TODO: manage total votes count
            return genderDetails;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewGenderDataAfterRemoving(genderDetails, pollResponse, totalVotes) {
        try {
            const { questionId = '' } = pollResponse;

            for (const data of genderDetails) {
                if (data.questionId === questionId) {
                    let genderName = pollResponse?.gender;
                    if (!pollResponse?.gender) {
                        genderName = UNKNOWN;
                    }

                    (data.genderData || []).forEach((_genderData) => {
                        if (_genderData?.gender === genderName) {
                            _genderData.count--;
                        }

                        if (_genderData.count <= 0 || totalVotes - 1 <= 0) {
                            _genderData.count = 0;
                            _genderData.percentage = 0;
                        } else {
                            _genderData.percentage = Number(
                                Number((_genderData.count / (totalVotes - 1)) * 100).toFixed(2)
                            );
                        }
                    });
                    break; // Exit the loop after finding the matching questionId
                }
            }

            // TODO: manage total votes count
            return genderDetails;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewGraphData(graphData, pollResponse, totalVotes) {
        try {
            const { createdAt = new Date() } = pollResponse;
            const { year, month, day } = this.getYearMonthDayFromDate(createdAt);
            const date = `${year}-${month}-${day}`;

            let dateData = (graphData?.dateWisePercentages || []).find((data) => data.date === date);
            if (!dateData) {
                dateData = { date, count: 0, percentage: 0 };
                graphData.dateWisePercentages.push(dateData);
            }

            // dateData.count++;

            (graphData?.dateWisePercentages || []).forEach((data) => {
                if (data.date === date) {
                    data.count++;
                }
                data.percentage = Number(Number((data.count / (totalVotes + 1)) * 100).toFixed(2));
            });

            // TODO: add percentage and rank field and manage total responses count
            return graphData;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewGraphDataAfterRemoving(graphData, pollResponse, totalVotes) {
        try {
            const { createdAt = new Date() } = pollResponse;
            const { year, month, day } = this.getYearMonthDayFromDate(createdAt);
            const date = `${year}-${month}-${day}`;

            (graphData?.dateWisePercentages || []).forEach((data) => {
                if (data.date === date) {
                    data.count--;
                }

                if (data.count <= 0 || totalVotes - 1 <= 0) {
                    data.count = 0;
                    data.percentage = 0;
                } else {
                    data.percentage = Number(Number((data.count / (totalVotes - 1)) * 100).toFixed(2));
                }
            });
            return graphData;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    getYearMonthDayFromDate(date) {
        try {
            const _date = new Date(date);
            const year = _date.getFullYear();
            const month = _date.getMonth() + 1;
            const day = _date.getDate();
            return { year, month, day };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewLocationData(locationData, pollResponse, totalVotes) {
        try {
            for (const data of locationData) {
                if (data?.questionId === pollResponse?.questionId) {
                    const { city = '', state = '', country = '' } = pollResponse;

                    let cityName = city;
                    if (!city) {
                        cityName = UNKNOWN;
                    }

                    let stateName = state;
                    if (!state) {
                        stateName = UNKNOWN;
                    }

                    let countryName = country;
                    if (!country) {
                        countryName = UNKNOWN;
                    }

                    // check if city is not available
                    let cityDetail = data.cityData.find((c) => c.city === cityName);
                    if (!cityDetail) {
                        cityDetail = { city: cityName, count: 0, percentage: 0 };
                        data.cityData.push(cityDetail);
                    }

                    // check if state is not available
                    let stateDetail = data.stateData.find((s) => s.state === stateName);
                    if (!stateDetail) {
                        stateDetail = { state: stateName, count: 0, percentage: 0 };
                        data.stateData.push(stateDetail);
                    }

                    // check if country is not available
                    let countryDetail = data.countryData.find((c) => c.country === countryName);
                    if (!countryDetail) {
                        countryDetail = { country: countryName, count: 0, percentage: 0 };
                        data.countryData.push(countryDetail);
                    }

                    // TODO: Manage unknown location data

                    // Update city data
                    (data.cityData || []).forEach((cityData) => {
                        if (cityData.city === cityName) {
                            cityData.count++;
                            cityData.lat = pollResponse?.lat || '';
                            cityData.lon = pollResponse?.lon || '';
                        }
                        cityData.percentage = Number(Number((cityData.count / (totalVotes + 1)) * 100).toFixed(2));
                    });
                    // Update city data
                    (data.stateData || []).forEach((stateData) => {
                        if (stateData.state === stateName) {
                            stateData.count++;
                            stateData.lat = pollResponse?.lat || '';
                            stateData.lon = pollResponse?.lon || '';
                        }
                        stateData.percentage = Number(Number((stateData.count / (totalVotes + 1)) * 100).toFixed(2));
                    });
                    // Update city data
                    (data.countryData || []).forEach((countryData) => {
                        if (countryData.country === countryName) {
                            countryData.count++;
                            countryData.lat = pollResponse?.lat || '';
                            countryData.lon = pollResponse?.lon || '';
                        }
                        countryData.percentage = Number(
                            Number((countryData.count / (totalVotes + 1)) * 100).toFixed(2)
                        );
                    });

                    break;
                }
            }
            return locationData;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    calculateNewLocationDataAfterRemoving(locationData, pollResponse, totalVotes) {
        try {
            for (const data of locationData) {
                if (data?.questionId === pollResponse?.questionId) {
                    const { city = '', state = '', country = '' } = pollResponse;

                    let cityName = city;
                    if (!city) {
                        cityName = UNKNOWN;
                    }

                    let stateName = state;
                    if (!state) {
                        stateName = UNKNOWN;
                    }

                    let countryName = country;
                    if (!country) {
                        countryName = UNKNOWN;
                    }

                    // Update city data
                    (data.cityData || []).forEach((cityData) => {
                        if (cityData.city === cityName) {
                            cityData.count--;
                        }
                        if (cityData.count <= 0 || totalVotes - 1 <= 0) {
                            cityData.count = 0;
                            cityData.percentage = 0;
                        } else {
                            cityData.percentage = Number(Number((cityData.count / (totalVotes - 1)) * 100).toFixed(2));
                        }
                    });
                    // Update city data
                    (data.stateData || []).forEach((stateData) => {
                        if (stateData.state === stateName) {
                            stateData.count--;
                        }
                        if (stateData.count <= 0 || totalVotes - 1 <= 0) {
                            stateData.count = 0;
                            stateData.percentage = 0;
                        } else {
                            stateData.percentage = Number(
                                Number((stateData.count / (totalVotes - 1)) * 100).toFixed(2)
                            );
                        }
                    });
                    // Update city data
                    (data.countryData || []).forEach((countryData) => {
                        if (countryData.country === countryName) {
                            countryData.count--;
                        }
                        if (countryData.count <= 0 || totalVotes - 1 <= 0) {
                            countryData.count = 0;
                            countryData.percentage = 0;
                        } else {
                            countryData.percentage = Number(
                                Number((countryData.count / (totalVotes - 1)) * 100).toFixed(2)
                            );
                        }
                    });

                    break;
                }
            }
            return locationData;
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
