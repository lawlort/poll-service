import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'poll_insights', versionKey: false })
export class PollInsight {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    pollId: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    createdBy: string;

    @Prop({ type: mongooseSchema.Types.Mixed, required: true })
    insights: any;

    @Prop({ default: false })
    isDeleted: boolean;

    @Prop()
    totalVotes: number;

    @Prop({ default: 0 })
    votersCount: number;
}

const PollInsightsSchema = SchemaFactory.createForClass(PollInsight);

PollInsightsSchema.index({ pollId: 1 });

export type PollInsightsDocument = HydratedDocument<PollInsight>;

export default PollInsightsSchema;
