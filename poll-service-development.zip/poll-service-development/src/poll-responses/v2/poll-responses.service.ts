import {
    BadRequestException,
    forwardRef,
    Inject,
    Injectable,
    NotFoundException,
    UnprocessableEntityException
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { isValidObjectId, Model } from 'mongoose';
import { globalErrorObj } from 'src/utils/common/globalErrorRes';
import { RpcException } from '@nestjs/microservices';
import { Poll, VisibilityTypes } from 'src/polls/schemas/poll.schema';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { LocationsService } from 'src/locations/locations.service';
import { LocationEventType } from 'src/locations/schemas/location.schema';
import { UsersService } from 'src/users/users.service';
import { TRUE_STRING } from 'src/utils/constants/string';
import { PollResponseHistory } from 'src/poll-response-history/schemas/poll-response-history.schema';
// import axios from 'axios';
import { ResponseQueuesService } from 'src/response-queues/response-queues.service';
import { CreatePollResponseJoiSchema } from '../dto/CreatePollResponseSchema';
import { PollResponse } from '../schema/poll-response.schema';
import { PollResponsesService } from '../poll-responses.service';
import { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';

@Injectable()
export class PollResponsesServiceV2 {
    constructor(
        @InjectModel(PollResponse.name) private pollResponseModel: Model<PollResponse>,
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        private locationService: LocationsService,
        @Inject(forwardRef(() => UsersService)) private userService: UsersService,
        @InjectModel(PollResponseHistory.name) private pollResponseHistoryModel: Model<PollResponseHistory>,
        @InjectModel(GroupPoll.name) private groupPollModel: Model<GroupPoll>,
        @InjectModel(SharedPoll.name) private sharedPollModel: Model<SharedPoll>,
        private responseQueueService: ResponseQueuesService,
        private pollResponseService: PollResponsesService
    ) {}

    // eslint-disable-next-line
    async respondPoll(userId: string, pollId: string, response: any, ip: string, query: any, token: string) {
        try {
            // Check poll id is valid or not
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.pattern.base'));
            }

            const poll = await this.pollModel.findById(pollId);

            if (!poll?._id || poll?.isDeleted || !poll?.isActive) {
                throw new NotFoundException('Poll not found');
            }

            if (poll?.isClosed) {
                throw new UnprocessableEntityException('Poll is closed');
            }

            // Check if the user is allowed to respond to a private poll
            if (poll?.visibility === VisibilityTypes.PRIVATE) {
                const sharedPoll = await this.sharedPollModel
                    .findOne({ pollId, sharedWith: userId })
                    .sort({ createdAt: -1 }); // Fetch the latest shared poll entry based on the creation timestamp

                if (!sharedPoll?._id || sharedPoll?.isDeleted) {
                    throw new UnprocessableEntityException('You are not allowed to respond to this poll');
                }
            }

            const totalResponses = await this.pollResponseHistoryModel
                .countDocuments({ pollId, userId, isDeleted: false })
                .exec();
            if (totalResponses >= 2) {
                throw new UnprocessableEntityException('Response cannot be changed more than once');
            }

            if (query['changeMyMind'] === TRUE_STRING) {
                if (!totalResponses) {
                    throw new UnprocessableEntityException('Please submit your response first to change it');
                }
            }

            if (response?.questionId) {
                const question = poll.questions.find((q) => q.id === response.questionId);
                if (!question) {
                    throw new BadRequestException(
                        globalErrorObj('Question not found', 'questionId', 'string.pattern.base')
                    );
                }

                // check for poll question type with type getting from response
                if (question.type !== response.questionType) {
                    throw new BadRequestException(
                        globalErrorObj('Question type is invalid', 'questionType', 'string.base')
                    );
                }
            }

            // check for options as well
            if (response?.optionId) {
                const question = poll.questions.find((q) => q.id === response.questionId);
                if (!question) {
                    throw new BadRequestException(
                        globalErrorObj('Question not found', 'questionId', 'string.pattern.base')
                    );
                }

                if (!question.options.find((o) => o.id === response.optionId)) {
                    throw new BadRequestException(
                        globalErrorObj('Option not found', 'optionId', 'string.pattern.base')
                    );
                }
            }

            // check for optionIds array as well
            if (response?.optionIds) {
                if (!Array.isArray(response?.optionIds)) {
                    throw new BadRequestException(
                        globalErrorObj('Option ids should be an array', 'optionIds', 'array.base')
                    );
                }

                const question = poll.questions.find((q) => q.id === response.questionId);
                if (!question) {
                    throw new BadRequestException(
                        globalErrorObj('Question not found', 'questionId', 'string.pattern.base')
                    );
                }

                const options = question.options.map((o) => o.id);

                // options id should be unique
                if (new Set(response.optionIds).size !== response.optionIds.length) {
                    throw new BadRequestException(
                        globalErrorObj('Option ids should be unique', 'optionIds', 'array.unique')
                    );
                }

                response.optionIds.forEach((optionId) => {
                    if (!options.includes(optionId)) {
                        throw new BadRequestException(
                            globalErrorObj('Option not found', 'optionId', 'string.pattern.base')
                        );
                    }
                });
            }

            // Validation for rankings if present
            if (response?.rankings) {
                const question = poll.questions.find((q) => q.id === response.questionId);
                if (!question) {
                    throw new BadRequestException(
                        globalErrorObj('Question not found', 'questionId', 'string.pattern.base')
                    );
                }

                // check rankings length is equal to options length
                if (question?.options?.length !== response?.rankings?.length) {
                    throw new BadRequestException(
                        globalErrorObj('Rankings length is invalid', 'rankings', 'array.base')
                    );
                }

                // rankings should be unique
                if (new Set(response.rankings.map((r) => r.optionId)).size !== response.rankings.length) {
                    throw new BadRequestException(
                        globalErrorObj('Rankings should be unique', 'rankings', 'array.unique')
                    );
                }

                // rankings order should be unique
                if (new Set(response.rankings.map((r) => r.order)).size !== response.rankings.length) {
                    throw new BadRequestException(
                        globalErrorObj('Rankings order should be unique', 'rankings', 'array.unique')
                    );
                }

                // check for option id
                const options = question.options.map((o) => o.id);
                response.rankings.forEach((ranking) => {
                    if (!options.includes(ranking.optionId)) {
                        throw new BadRequestException(
                            globalErrorObj('Option not found', 'optionId', 'string.pattern.base')
                        );
                    }
                });

                // get question options length
                const questionOptionsLength = question?.options?.length || 0;

                // order number should not greater than rankings length
                if (response.rankings.some((r) => r.order > questionOptionsLength)) {
                    throw new BadRequestException(globalErrorObj('Order is invalid', 'order', 'number.base'));
                }
            }

            // get location details
            let locationPayload: any = {};
            const locationDetails: any = await this.locationService.getLocationDetails(ip);
            if (!(locationDetails?.data?.status === 'fail')) {
                const locationData = locationDetails?.data || {};
                if (Object.keys(locationData).length) {
                    locationPayload = {
                        eventType: LocationEventType.POLL_RESPONSE,
                        pollId,
                        userId,
                        ...locationData
                    };
                }
            }

            let pollResponseIds = [];
            let pollResponsesToDelete = [];
            if (query['changeMyMind'] === TRUE_STRING) {
                // get all poll responses object ids for this user using pollId and userId
                const pollResponses = await this.pollResponseModel.find({
                    pollId,
                    userId,
                    questionId: response.questionId
                });
                pollResponsesToDelete = pollResponses;
                pollResponseIds = pollResponses.map((pr) => pr._id);
            }

            // get user by id
            // Fetch user data
            let user: any = {};
            try {
                user = await this.userService.getUserById(userId);
            } catch (error) {
                throw new BadRequestException(error?.error?.message || 'Error fetching user detail');
            }

            // check for duplicate entries for different question types
            if (query['changeMyMind'] !== TRUE_STRING) {
                const isDuplicate = await this.pollResponseModel.exists({
                    userId,
                    pollId,
                    questionId: response.questionId,
                    questionType: response.questionType
                });

                if (!!isDuplicate?._id) {
                    throw new BadRequestException(
                        globalErrorObj('Response already exists for this question', 'response', 'string.base')
                    );
                }
            }

            const oldUserAge = user?.age || 18;
            const estimatedBirthdate = user?.estimatedBirthdate;
            // calculate users age from estimated birthdate
            if (estimatedBirthdate) {
                const ageDifMs = Date.now() - new Date(estimatedBirthdate).getTime();
                const ageDate = new Date(ageDifMs);
                const age = Math.abs(ageDate.getUTCFullYear() - 1970);
                user.age = age || oldUserAge;
            }

            // for ranking create different payload for all rankings
            if (response?.rankings) {
                const question = (poll?.questions || []).find((q) => q.id === response?.questionId);
                let optionWeightage = question?.optionWeightage;
                if (!Object.keys(optionWeightage || {}).length) {
                    const optionsLength = question?.options?.length || 0;
                    const _optionWeightage = {};
                    if (optionsLength) {
                        for (let i = 1; i <= optionsLength; i++) {
                            _optionWeightage[i] = Number(
                                Number((1 / optionsLength) * (optionsLength - i + 1) * 100).toFixed(3)
                            );
                        }
                    }
                    optionWeightage = _optionWeightage;
                }

                const rankingsPayload = response.rankings.map((ranking) => ({
                    userId,
                    pollId,
                    questionId: response.questionId,
                    optionId: ranking.optionId,
                    questionType: response.questionType,
                    order: ranking.order,
                    answerAnonymous: response.answerAnonymous || false,
                    ...(user?.gender ? { gender: user.gender } : {}),
                    ...locationPayload,
                    ...(locationPayload?.regionName ? { state: locationPayload.regionName } : {}),
                    ...(user?.age ? { age: user.age } : {}),
                    optionWeightage: optionWeightage[ranking.order.toString()]
                }));

                const rankings = await this.pollResponseModel.insertMany(rankingsPayload);
                await this.pollResponseHistoryModel.create({ pollId, userId, respondedAt: Date.now() });

                try {
                    for (const pollResponse of pollResponsesToDelete) {
                        await this.responseQueueService.addJobToQueue(
                            { ...pollResponse.toJSON(), removeResponse: true, token },
                            poll.questions[0].type,
                            pollId
                        );
                    }
                    for (const ranking of rankings) {
                        await this.responseQueueService.addJobToQueue(
                            { ...ranking.toJSON(), removeResponse: false, token },
                            poll.questions[0].type,
                            pollId
                        );
                    }
                } catch (error) {
                    throw new BadRequestException(error?.response?.data?.message || 'Error pushing job to queue');
                }

                await this.pollResponseService.deletePollResponses(pollResponseIds);

                // add location table entry
                if (Object.keys(locationPayload).length) {
                    await this.locationService.create(locationPayload);
                }

                this.clossPollIfAllInivtedUsersHaveVoted(pollId);

                // add delay of 1 second
                await new Promise((resolve) => setTimeout(resolve, 500));

                return { success: !!rankings?.length };
            }

            // for multiple choice and date options
            else if (response?.optionIds) {
                const optionsPayload = response.optionIds.map((optionId) => ({
                    userId,
                    pollId,
                    questionId: response.questionId,
                    optionId,
                    questionType: response.questionType,
                    answerAnonymous: response.answerAnonymous || false,
                    ...(user?.gender ? { gender: user.gender } : {}),
                    ...locationPayload,
                    ...(locationPayload?.regionName ? { state: locationPayload.regionName } : {}),
                    ...(user?.age ? { age: user.age } : {})
                }));

                const responses = await this.pollResponseModel.insertMany(optionsPayload);
                await this.pollResponseHistoryModel.create({ pollId, userId, respondedAt: Date.now() });

                try {
                    for (const pollResponse of pollResponsesToDelete) {
                        await this.responseQueueService.addJobToQueue(
                            { ...pollResponse.toJSON(), removeResponse: true, token },
                            poll.questions[0].type,
                            pollId
                        );
                    }
                    for (const response of responses) {
                        await this.responseQueueService.addJobToQueue(
                            { ...response.toJSON(), removeResponse: false, token },
                            poll.questions[0].type,
                            pollId
                        );
                    }
                } catch (error) {
                    throw new BadRequestException(error?.response?.data?.message || 'Error pushing job to queue');
                }
                await this.pollResponseService.deletePollResponses(pollResponseIds);

                // add location table entry
                if (Object.keys(locationPayload).length) {
                    await this.locationService.create(locationPayload);
                }
                this.clossPollIfAllInivtedUsersHaveVoted(pollId);
                // add delay of 1 second
                await new Promise((resolve) => setTimeout(resolve, 500));

                return { success: !!responses?.length };
            }

            let payload = {
                userId,
                pollId,
                ...response,
                ...(user?.gender ? { gender: user.gender } : {}),
                ...(user?.age ? { age: user.age } : {})
            };

            validateSchema(CreatePollResponseJoiSchema, payload);

            payload = {
                ...payload,
                ...locationPayload,
                ...(locationPayload?.regionName ? { state: locationPayload.regionName } : {})
            };

            const pollResponse = await this.pollResponseModel.create(payload);
            await this.pollResponseHistoryModel.create({ pollId, userId, respondedAt: Date.now() });

            await this.pollResponseService.deletePollResponses(pollResponseIds);

            try {
                for (const pollResponse of pollResponsesToDelete) {
                    await this.responseQueueService.addJobToQueue(
                        { ...pollResponse.toJSON(), removeResponse: true, token },
                        poll.questions[0].type,
                        pollId
                    );
                }
                await this.responseQueueService.addJobToQueue(
                    { ...pollResponse.toJSON(), removeResponse: false, token },
                    poll.questions[0].type,
                    pollId
                );
            } catch (error) {
                throw new BadRequestException(error?.response?.data?.message || 'Error pushing job to queue');
            }

            // add location table entry
            if (Object.keys(locationPayload).length) {
                await this.locationService.create(locationPayload);
            }

            // this.pollInsightsService.createPollInsight(pollId, userId);

            this.clossPollIfAllInivtedUsersHaveVoted(pollId);
            // add delay of 1 second
            await new Promise((resolve) => setTimeout(resolve, 1000));

            return { success: !!pollResponse?._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async clossPollIfAllInivtedUsersHaveVoted(pollId: string) {
        const poll = await this.pollModel.findById(pollId);
        if (!poll || poll.isDeleted || !poll.isActive) {
            throw new NotFoundException('Poll not found');
        }

        if (poll?.visibility === VisibilityTypes.PUBLIC) {
            return { success: true };
        }

        // Step 1: Count unique users the poll was shared with
        const totalSharedWithUsers: any = await this.sharedPollModel
            .find({
                pollId,
                isDeleted: false
            })
            .distinct('sharedWith');

        const totalSharedWithCount = totalSharedWithUsers.length;

        // Step 2: Count unique users who have responded to the poll
        const totalResponded = await this.pollResponseHistoryModel
            .find({
                pollId,
                isDeleted: false
            })
            .distinct('userId');

        const totalRespondedCount = totalResponded.length;

        // Step 3: Check if all shared users have responded
        if (totalSharedWithCount === totalRespondedCount) {
            // Mark the poll as closed if all shared users responded
            await this.pollModel.updateOne({ _id: pollId }, { isClosed: true, endDate: new Date() });
            console.log(`Poll with ID ${pollId} has been closed.`);
        }
        return { success: true };
    }

    // Consumer function to leave or remove user from group - EVENT_TYPE_REMOVE_USER_FROM_GROUP
    async removePollResponse(body: any, token = '') {
        try {
            const { groupId = '', userId = '' } = body;

            const currentDateTime = new Date(); // Get current date and time

            const activePolls = await this.groupPollModel
                .aggregate([
                    // Match group polls with the given groupId and not deleted
                    {
                        $match: {
                            groupId: mongoose.Types.ObjectId.createFromHexString(groupId),
                            isDeleted: false
                        }
                    },
                    // Lookup to join with Polls collection
                    {
                        $lookup: {
                            from: 'polls', // The name of the Polls collection
                            localField: 'pollId', // Field from GroupPoll
                            foreignField: '_id', // Field from Poll
                            as: 'pollDetails' // Output array field
                        }
                    },
                    // Unwind the pollDetails array
                    {
                        $unwind: {
                            path: '$pollDetails',
                            preserveNullAndEmptyArrays: true // If there is no matching poll, we keep the GroupPoll
                        }
                    },
                    // Match to filter only active polls with the specified conditions
                    {
                        $match: {
                            'pollDetails.visibility': VisibilityTypes.PUBLIC, // Public polls
                            'pollDetails.isActive': true,
                            'pollDetails.isDeleted': false,
                            // 'pollDetails.isClosed': false,
                            'pollDetails.endDate': { $gt: currentDateTime } // Greater than current datetime
                        }
                    },
                    // Optionally project to return only necessary fields
                    {
                        $project: {
                            _id: 1,
                            groupId: 1,
                            pollId: 1,
                            pollDetails: 1 // Include other necessary fields
                        }
                    }
                ])
                .exec();

            // all public poll ids
            const pollIds = activePolls.map((poll) => poll.pollId);

            const pollResponsesToDelete = await this.pollResponseModel.find({ userId, pollId: { $in: pollIds } });

            // TODO: remove poll response history as well - DONE
            // remove poll response history
            await this.pollResponseHistoryModel.updateMany(
                {
                    userId,
                    pollId: { $in: pollIds }
                },
                {
                    isDeleted: true
                }
            );

            for (const pollResponse of pollResponsesToDelete) {
                await this.responseQueueService.addJobToQueue(
                    { ...pollResponse.toJSON(), removeResponse: true, token },
                    pollResponse.questionType,
                    pollResponse.pollId
                );
            }

            // remove response from database
            const pollResponsesToDeleteIds = pollResponsesToDelete.map((response) => response._id);
            await this.pollResponseModel.deleteMany({ _id: { $in: pollResponsesToDeleteIds } });
            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
