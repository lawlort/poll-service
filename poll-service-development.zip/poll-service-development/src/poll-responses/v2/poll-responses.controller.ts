import { Controller, Body } from '@nestjs/common';
import { PollResponsesServiceV2 } from './poll-responses.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_REMOVE_POLL_RESPONSE, CMD_RESPOND_POLL_V2 } from 'src/utils/constants/commands';

@Controller('poll-responses')
export class PollResponsesControllerV2 {
    constructor(private readonly pollResponsesService: PollResponsesServiceV2) {}

    @MessagePattern({ cmd: CMD_RESPOND_POLL_V2 })
    async respondPoll(@Body() payload) {
        const { userId = '', pollId = '', body = {}, ip = '', query = {}, token = '' } = payload;
        return await this.pollResponsesService.respondPoll(userId, pollId, body, ip, query, token);
    }

    @MessagePattern({ cmd: CMD_REMOVE_POLL_RESPONSE })
    async removePollResponse(@Body() payload) {
        const { body = {}, token = '' } = payload;
        return await this.pollResponsesService.removePollResponse(body, token);
    }
}
