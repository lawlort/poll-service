import {
    BadRequestException,
    forwardRef,
    Inject,
    Injectable,
    NotFoundException,
    UnprocessableEntityException
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PollResponse } from './schema/poll-response.schema';
import mongoose, { isValidObjectId, Model } from 'mongoose';
import { globalErrorObj } from 'src/utils/common/globalErrorRes';
import { RpcException } from '@nestjs/microservices';
import { Poll } from 'src/polls/schemas/poll.schema';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreatePollResponseJoiSchema } from './dto/CreatePollResponseSchema';
import { LocationsService } from 'src/locations/locations.service';
import { LocationEventType } from 'src/locations/schemas/location.schema';
import { UsersService } from 'src/users/users.service';
import { TRUE_STRING, VisibilityTypes } from 'src/utils/constants/string';
import { PollInsightsService } from 'src/poll-insights/poll-insights.service';
import { PollResponseHistory } from 'src/poll-response-history/schemas/poll-response-history.schema';
// import axios from 'axios';
import { ResponseQueuesService } from 'src/response-queues/response-queues.service';
import { PollsService } from 'src/polls/polls.service';
import axios from 'axios';
import { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import { EventQueuesService } from 'src/event-queues/event-queues.service';
import { EVENT_TYPE_UPDATE_GENDER } from 'src/utils/constants/events';

@Injectable()
export class PollResponsesService {
    constructor(
        @InjectModel(PollResponse.name) private pollResponseModel: Model<PollResponse>,
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        private locationService: LocationsService,
        @Inject(forwardRef(() => UsersService)) private userService: UsersService,
        @Inject(forwardRef(() => PollInsightsService)) private pollInsightsService: PollInsightsService,
        @InjectModel(PollResponseHistory.name) private pollResponseHistoryModel: Model<PollResponseHistory>,
        private responseQueueService: ResponseQueuesService,
        // private pollService: PollsService,
        @Inject(forwardRef(() => PollsService)) private pollService: PollsService,

        @InjectModel(SharedPoll.name) private SharedPollModel: Model<SharedPoll>,
        private eventQueueService: EventQueuesService
    ) {}

    // eslint-disable-next-line
    async respondPoll(userId: string, pollId: string, response: any, ip: string, query, token: string) {
        try {
            // Check poll id is valid or not
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.pattern.base'));
            }

            const poll: any = await this.pollService.findPollById(pollId);

            if (!poll?._id || poll?.isDeleted) {
                throw new NotFoundException('Poll not found');
            }

            if (poll?.isClosed) {
                throw new UnprocessableEntityException('Poll is closed');
            }

            const totalResponses = await this.pollResponseHistoryModel
                .countDocuments({ pollId, userId, isDeleted: false })
                .exec();
            if (totalResponses >= 2) {
                throw new UnprocessableEntityException('Response cannot be changed more than once');
            }

            if (response?.questionId) {
                const question = poll.questions.find((q) => q.id === response.questionId);
                if (!question) {
                    throw new BadRequestException(
                        globalErrorObj('Question not found', 'questionId', 'string.pattern.base')
                    );
                }

                // check for poll question type with type getting from response
                if (question.type !== response.questionType) {
                    throw new BadRequestException(
                        globalErrorObj('Question type is invalid', 'questionType', 'string.base')
                    );
                }
            }

            // check for options as well
            if (response?.optionId) {
                const question = poll.questions.find((q) => q.id === response.questionId);
                if (!question) {
                    throw new BadRequestException(
                        globalErrorObj('Question not found', 'questionId', 'string.pattern.base')
                    );
                }

                if (!question.options.find((o) => o.id === response.optionId)) {
                    throw new BadRequestException(
                        globalErrorObj('Option not found', 'optionId', 'string.pattern.base')
                    );
                }
            }

            // check for optionIds array as well
            if (response?.optionIds) {
                if (!Array.isArray(response?.optionIds)) {
                    throw new BadRequestException(
                        globalErrorObj('Option ids should be an array', 'optionIds', 'array.base')
                    );
                }

                const question = poll.questions.find((q) => q.id === response.questionId);
                if (!question) {
                    throw new BadRequestException(
                        globalErrorObj('Question not found', 'questionId', 'string.pattern.base')
                    );
                }

                const options = question.options.map((o) => o.id);

                // options id should be unique
                if (new Set(response.optionIds).size !== response.optionIds.length) {
                    throw new BadRequestException(
                        globalErrorObj('Option ids should be unique', 'optionIds', 'array.unique')
                    );
                }

                response.optionIds.forEach((optionId) => {
                    if (!options.includes(optionId)) {
                        throw new BadRequestException(
                            globalErrorObj('Option not found', 'optionId', 'string.pattern.base')
                        );
                    }
                });
            }

            // Validation for rankings if present
            if (response?.rankings) {
                const question = poll.questions.find((q) => q.id === response.questionId);
                if (!question) {
                    throw new BadRequestException(
                        globalErrorObj('Question not found', 'questionId', 'string.pattern.base')
                    );
                }

                // check rankings length is equal to options length
                if (question?.options?.length !== response?.rankings?.length) {
                    throw new BadRequestException(
                        globalErrorObj('Rankings length is invalid', 'rankings', 'array.base')
                    );
                }

                // rankings should be unique
                if (new Set(response.rankings.map((r) => r.optionId)).size !== response.rankings.length) {
                    throw new BadRequestException(
                        globalErrorObj('Rankings should be unique', 'rankings', 'array.unique')
                    );
                }

                // rankings order should be unique
                if (new Set(response.rankings.map((r) => r.order)).size !== response.rankings.length) {
                    throw new BadRequestException(
                        globalErrorObj('Rankings order should be unique', 'rankings', 'array.unique')
                    );
                }

                // check for option id
                const options = question.options.map((o) => o.id);
                response.rankings.forEach((ranking) => {
                    if (!options.includes(ranking.optionId)) {
                        throw new BadRequestException(
                            globalErrorObj('Option not found', 'optionId', 'string.pattern.base')
                        );
                    }
                });

                // get question options length
                const questionOptionsLength = question?.options?.length || 0;

                // order number should not greater than rankings length
                if (response.rankings.some((r) => r.order > questionOptionsLength)) {
                    throw new BadRequestException(globalErrorObj('Order is invalid', 'order', 'number.base'));
                }
            }

            // get location details
            let locationPayload: any = {};
            const locationDetails: any = await this.locationService.getLocationDetails(ip);
            if (!(locationDetails?.data?.status === 'fail')) {
                const locationData = locationDetails?.data || {};
                if (Object.keys(locationData).length) {
                    locationPayload = {
                        eventType: LocationEventType.POLL_RESPONSE,
                        pollId,
                        userId,
                        ...locationData
                    };
                }
            }

            let pollResponseIds = [];
            if (query['changeMyMind'] === TRUE_STRING) {
                // get all poll responses object ids for this user using pollId and userId
                const pollResponses = await this.pollResponseModel.find({
                    pollId,
                    userId,
                    questionId: response.questionId
                });
                pollResponseIds = pollResponses.map((pr) => pr._id);
            }

            // get user by id
            // Fetch user data
            let user: any = {};
            try {
                user = await this.userService.getUserById(userId);
            } catch (error) {
                throw new BadRequestException(error?.error?.message || 'Error fetching user detail');
            }

            // check for duplicate entries for different question types
            if (query['changeMyMind'] !== TRUE_STRING) {
                const isDuplicate = await this.pollResponseModel.exists({
                    userId,
                    pollId,
                    questionId: response.questionId,
                    questionType: response.questionType
                });

                if (!!isDuplicate?._id) {
                    throw new BadRequestException(
                        globalErrorObj('Response already exists for this question', 'response', 'string.base')
                    );
                }
            }

            // for ranking create different payload for all rankings
            if (response?.rankings) {
                const rankingsPayload = response.rankings.map((ranking) => ({
                    userId,
                    pollId,
                    questionId: response.questionId,
                    optionId: ranking.optionId,
                    questionType: response.questionType,
                    order: ranking.order,
                    answerAnonymous: response.answerAnonymous || false,
                    ...(user?.gender ? { gender: user.gender } : {}),
                    ...locationPayload,
                    ...(locationPayload?.regionName ? { state: locationPayload.regionName } : {})
                }));

                const rankings = await this.pollResponseModel.insertMany(rankingsPayload);

                await this.deletePollResponses(pollResponseIds);

                this.pollInsightsService.createPollInsight(pollId, userId);

                // add location table entry
                if (Object.keys(locationPayload).length) {
                    await this.locationService.create(locationPayload);
                }

                await this.pollResponseHistoryModel.create({ pollId, userId, respondedAt: Date.now() });
                return { success: !!rankings?.length };
            }

            let payload = {
                userId,
                pollId,
                ...response,
                ...(user?.gender ? { gender: user.gender } : {})
            };

            validateSchema(CreatePollResponseJoiSchema, payload);

            payload = {
                ...payload,
                ...locationPayload,
                ...(locationPayload?.regionName ? { state: locationPayload.regionName } : {})
            };

            const pollResponse = await this.pollResponseModel.create(payload);

            await this.deletePollResponses(pollResponseIds);

            // add location table entry
            if (Object.keys(locationPayload).length) {
                await this.locationService.create(locationPayload);
            }

            this.pollInsightsService.createPollInsight(pollId, userId);

            // add delay of 1 second
            await new Promise((resolve) => setTimeout(resolve, 1000));

            await this.pollResponseHistoryModel.create({ pollId, userId, respondedAt: Date.now() });
            return { success: !!pollResponse?._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async deletePollResponses(pollResponseIds: any) {
        try {
            if (Array.isArray(pollResponseIds)) {
                // Do not remove response from history table
                await this.pollResponseModel.deleteMany({ _id: { $in: pollResponseIds } });
            }
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async updateGenderOfPollResponses(userId, gender, token) {
        try {
            // Find all poll responses of the user
            const payload = {
                eventType: EVENT_TYPE_UPDATE_GENDER,
                userId,
                gender,
                token
            };

            await this.eventQueueService.addJobToQueue(payload, EVENT_TYPE_UPDATE_GENDER, userId);
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async getUsersWhoRespondedToPoll({ paginateOptions, pollId, search, token }) {
        try {
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Invalid poll id', 'pollId', 'string.base'));
            }

            const poll: any = await this.pollService.findPollById(pollId);
            if (!poll?._id || poll?.isDeleted) {
                throw new NotFoundException('Poll not found');
            }

            // Initialize aggregation pipeline for both private and public polls
            const pipeline: any[] = [];

            // Check if poll is private and use poll_creation_shares for user list if so
            if (poll?.visibility === VisibilityTypes.PRIVATE) {
                const anonymousResponses = await this.pollResponseModel.find({
                    answerAnonymous: true,
                    pollId,
                    isDeleted: false
                });

                const userIds = Array.from(new Set(anonymousResponses.map((response) => response.userId.toString())));
                const userObjectIds = userIds.map((userId) => mongoose.Types.ObjectId.createFromHexString(userId));

                // Using poll_creation_shares to get users for private polls
                pipeline.push(
                    // Match the poll ID to filter for shared records for this specific poll
                    {
                        $match: {
                            pollId: mongoose.Types.ObjectId.createFromHexString(pollId),
                            isDeleted: false,
                            sharedWith: { $nin: userObjectIds }
                        }
                    },

                    // Group by sharedWith to get unique entries per user to whom the poll was shared
                    {
                        $group: {
                            _id: '$sharedWith', // Group by sharedWith to get unique users who received the poll
                            latestShare: { $first: '$$ROOT' } // Retrieve the full share entry for each unique user
                        }
                    },

                    // Look up user details from the 'users' collection
                    {
                        $lookup: {
                            from: 'users',
                            localField: 'latestShare.sharedWith',
                            foreignField: '_id',
                            as: 'userDetails'
                        }
                    },
                    { $unwind: '$userDetails' },

                    // Look up interests for each user
                    {
                        $lookup: {
                            from: 'interests',
                            localField: 'userDetails.interests',
                            foreignField: '_id',
                            as: 'userDetails.interestsDetails'
                        }
                    },

                    // Project the desired fields
                    {
                        $project: {
                            userId: '$userDetails._id',
                            username: '$userDetails.username',
                            refUserId: '$userDetails.refUserId',
                            profilePicUrl: '$userDetails.profilePicUrl',
                            interests: {
                                $map: {
                                    input: '$userDetails.interestsDetails',
                                    as: 'interest',
                                    in: {
                                        id: '$$interest._id',
                                        name: '$$interest.name'
                                    }
                                }
                            },
                            sharedAt: '$latestShare.createdAt' // Date when poll was shared with the user
                        }
                    }
                );

                // Add optional search filter based on username
                if (search) {
                    pipeline.push({
                        $match: {
                            username: { $regex: search, $options: 'i' }
                        }
                    });
                }
            } else {
                pipeline.push(
                    { $match: { pollId: mongoose.Types.ObjectId.createFromHexString(pollId), isDeleted: false } },
                    { $match: { answerAnonymous: false } },
                    {
                        $group: {
                            _id: '$userId',
                            pollResponse: { $first: '$$ROOT' }
                        }
                    },
                    {
                        $lookup: {
                            from: 'users',
                            localField: 'pollResponse.userId',
                            foreignField: '_id',
                            as: 'userDetails'
                        }
                    },
                    { $unwind: '$userDetails' },
                    {
                        $lookup: {
                            from: 'interests',
                            localField: 'userDetails.interests',
                            foreignField: '_id',
                            as: 'userDetails.interestsDetails'
                        }
                    },
                    {
                        $project: {
                            userId: '$userDetails._id',
                            username: '$userDetails.username',
                            refUserId: '$userDetails.refUserId',
                            profilePicUrl: '$userDetails.profilePicUrl',
                            interests: {
                                $map: {
                                    input: '$userDetails.interestsDetails',
                                    as: 'interest',
                                    in: {
                                        id: '$$interest._id',
                                        name: '$$interest.name'
                                    }
                                }
                            },
                            respondedAt: '$pollResponse.createdAt',
                            answerAnonymous: '$pollResponse.answerAnonymous'
                        }
                    }
                );

                if (search) {
                    pipeline.push({
                        $match: {
                            username: { $regex: search, $options: 'i' }
                        }
                    });
                }
            }

            // Add pagination stages
            pipeline.push(
                { $skip: (paginateOptions.page - 1) * paginateOptions.limit },
                { $limit: paginateOptions.limit }
            );

            // Execute aggregation and get results
            let results;
            let countPipeline;
            let totalResults;
            let answerAnonymousCountPipeline;
            let anonymousCountResult;
            let answerAnonymousCount;

            if (poll?.visibility === VisibilityTypes.PRIVATE) {
                results = await this.SharedPollModel.aggregate(pipeline).exec();

                // Get total count for pagination (remove pagination stages)
                countPipeline = pipeline.slice(0, -2);
                totalResults = (await this.SharedPollModel.aggregate(countPipeline).exec()).length;

                // Step 2: Loop through results and check if each user has voted
                results = await Promise.all(
                    results.map(async (result) => {
                        // Check for an existing poll response for this user and poll
                        const response = await this.pollResponseModel
                            .findOne({
                                userId: result.userId,
                                pollId: pollId
                            })
                            .lean();

                        // Set the isVoted flag based on whether a response exists
                        if (response?._id) {
                            result.isVoted = !response?.answerAnonymous;
                        } else {
                            result.isVoted = false;
                        }

                        return result;
                    })
                );

                // Anonymous response count
                answerAnonymousCountPipeline = [
                    { $match: { pollId: mongoose.Types.ObjectId.createFromHexString(pollId) } },
                    { $match: { answerAnonymous: true } },
                    { $group: { _id: '$userId' } },
                    { $count: 'answerAnonymousCount' }
                ];
                anonymousCountResult = await this.pollResponseModel.aggregate(answerAnonymousCountPipeline).exec();
                answerAnonymousCount = anonymousCountResult.length ? anonymousCountResult[0].answerAnonymousCount : 0;
            } else {
                results = await this.pollResponseModel.aggregate(pipeline).exec();

                // Get total count for pagination (remove pagination stages)
                countPipeline = pipeline.slice(0, -2);
                totalResults = (await this.pollResponseModel.aggregate(countPipeline).exec()).length;

                // Anonymous response count
                answerAnonymousCountPipeline = [
                    { $match: { pollId: mongoose.Types.ObjectId.createFromHexString(pollId) } },
                    { $match: { answerAnonymous: true } },
                    { $group: { _id: '$userId' } },
                    { $count: 'answerAnonymousCount' }
                ];
                anonymousCountResult = await this.pollResponseModel.aggregate(answerAnonymousCountPipeline).exec();
                answerAnonymousCount = anonymousCountResult.length ? anonymousCountResult[0].answerAnonymousCount : 0;
            }

            // Fetch fullName for private polls
            const formattedResults = [];
            for (const response of results) {
                let fullName = '';

                // Fetch fullName via external API for private polls
                if (poll?.visibility === VisibilityTypes.PRIVATE && response.refUserId) {
                    try {
                        const res: any = await axios.get(
                            `${process.env.API_GATEWAY_BASEURL}/v1/users/personal-info/${response.refUserId}`,
                            {
                                headers: { authorization: token }
                            }
                        );
                        fullName = res?.data?.fullName || '';
                    } catch (error) {
                        throw new BadRequestException(
                            error?.response?.data?.message || 'Error fetching user personal info'
                        );
                    }
                }

                // Format the result
                formattedResults.push({
                    userId: response.userId,
                    username: response.username || '',
                    profilePicUrl: response.profilePicUrl || '',
                    interests: response.interests || [],
                    respondedAt: response.respondedAt,
                    answerAnonymous: response.answerAnonymous,
                    isVoted: response.isVoted,
                    fullName: poll?.visibility === VisibilityTypes.PRIVATE ? fullName : undefined
                });
            }

            return {
                docs: formattedResults,
                page: paginateOptions.page,
                limit: paginateOptions.limit,
                totalPages: Math.ceil(totalResults / paginateOptions.limit),
                totalResults,
                answerAnonymousCount, // Return count of anonymous responses
                sharedWithUsersCount: poll?.sharedWithUsersCount || 0,
                votersCount: poll?.votersCount || 0,
                visibility: poll?.visibility,
                totalVotes: poll?.votes || 0
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
