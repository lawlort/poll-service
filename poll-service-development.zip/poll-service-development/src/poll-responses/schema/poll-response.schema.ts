import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';
import { QuestionTypes } from 'src/polls/schemas/poll.schema';

@Schema({ timestamps: true, collection: 'poll_responses' })
export class PollResponse {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    userId: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    pollId: string;

    @Prop({ required: true })
    questionId: number;

    @Prop()
    optionId: number; // For single-choice questions

    @Prop([{ type: Number }])
    optionIds: number[]; // For multiple-choice questions

    @Prop()
    order: number; // For ranking questions

    @Prop()
    sliderValue: number; // For slider questions

    @Prop({ enum: [...Object.values(QuestionTypes)], required: true })
    questionType: string; // Specifies the type of response

    @Prop({ default: false })
    answerAnonymous: boolean;

    @Prop()
    gender: string;

    @Prop()
    age: number;

    @Prop()
    city: string;

    @Prop()
    state: string;

    @Prop()
    lat: string;

    @Prop()
    lon: string;

    @Prop()
    country: string;

    @Prop({ default: false })
    isDeleted: boolean;

    @Prop()
    optionWeightage: number;
}

export const PollResponseSchema = SchemaFactory.createForClass(PollResponse);

// Define indexes to optimize query performance
PollResponseSchema.index({ pollId: 1, userId: 1, questionId: 1 });
PollResponseSchema.index({ pollId: 1, questionId: 1 });
PollResponseSchema.index({ pollId: 1, questionId: 1, sliderValue: 1 });
PollResponseSchema.index({ pollId: 1, userId: 1 });

// Optional: Additional indexes based on your query patterns
PollResponseSchema.index({ userId: 1 });
PollResponseSchema.index({ pollId: 1 });
PollResponseSchema.index({ answerAnonymous: 1 });
PollResponseSchema.index({ gender: 1 });
PollResponseSchema.index({ questionId: 1 });
PollResponseSchema.index({ questionId: 1, order: 1 });

export type PollResponseDocument = HydratedDocument<PollResponse>;

export default PollResponseSchema;
