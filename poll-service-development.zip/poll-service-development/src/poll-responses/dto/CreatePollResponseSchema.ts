import * as Joi from 'joi';
import { QuestionTypes } from 'src/polls/schemas/poll.schema';

// Define the Joi schema for PollResponse
export const CreatePollResponseJoiSchema = Joi.object({
    userId: Joi.string()
        .required()
        .pattern(/^[0-9a-fA-F]{24}$/) // Validate as a MongoDB ObjectId
        .messages({
            'string.base': 'User ID must be a string',
            'string.pattern.base': 'User ID must be a valid ObjectId',
            'any.required': 'User ID is required'
        }),

    pollId: Joi.string()
        .required()
        .pattern(/^[0-9a-fA-F]{24}$/)
        .messages({
            'string.base': 'Poll ID must be a string',
            'string.pattern.base': 'Poll ID must be a valid ObjectId',
            'any.required': 'Poll ID is required'
        }),

    questionId: Joi.number().required().messages({
        'number.base': 'Question ID must be a number',
        'any.required': 'Question ID is required'
    }),

    rankings: Joi.array()
        .items(
            Joi.object({
                optionId: Joi.number().required().messages({
                    'number.base': 'Option ID must be a number',
                    'any.required': 'Option ID is required'
                }),
                order: Joi.number().required().messages({
                    'number.base': 'Order must be a number',
                    'any.required': 'Order is required'
                })
            })
        )
        .optional()
        .when('questionType', {
            is: QuestionTypes.RANKING,
            then: Joi.array().min(1).required().messages({
                'array.base': 'Rankings must be an array',
                'array.min': 'At least one ranking is required for ranking questions',
                'any.required': 'Rankings are required for ranking questions'
            }),
            otherwise: Joi.forbidden().messages({
                'any.unknown': 'Rankings are not allowed for this question type'
            })
        }),

    optionId: Joi.number()
        .optional()
        .when('questionType', {
            is: Joi.valid(QuestionTypes.THIS_THAT, QuestionTypes.SINGLE_CHOICE),
            then: Joi.required().messages({
                'any.required': 'Option ID is required for "this_that" or "single-choice" questions'
            }),
            otherwise: Joi.forbidden().messages({
                'any.unknown': 'Option ID is not allowed for this question type'
            })
        }),

    optionIds: Joi.array()
        .items(Joi.number())
        .optional()
        .when('questionType', {
            is: Joi.valid(QuestionTypes.MULTIPLE_CHOICE, QuestionTypes.DATE),
            then: Joi.array().min(1).required().messages({
                'array.min': 'At least one option ID is required for multiple-choice questions',
                'any.required': 'Option IDs are required for multiple-choice questions'
            }),
            otherwise: Joi.forbidden().messages({
                'any.unknown': 'Option IDs are not allowed for this question type'
            })
        }),

    sliderValue: Joi.number()
        .min(0)
        .max(100)
        .optional()
        .when('questionType', {
            is: Joi.valid(QuestionTypes.SLIDER, QuestionTypes.LIGHT_METER),
            then: Joi.required().messages({
                'any.required': 'Slider value is required for slider questions'
            }),
            otherwise: Joi.forbidden().messages({
                'any.unknown': 'Slider value is not allowed for this question type'
            })
        }),

    questionType: Joi.string()
        .valid(...Object.values(QuestionTypes))
        .required()
        .messages({
            'string.base': 'Question type must be a string',
            'any.only': `Question type must be one of ${Object.values(QuestionTypes).join(', ')}`,
            'any.required': 'Question type is required'
        }),

    answerAnonymous: Joi.boolean().optional().default(false),
    gender: Joi.string().optional(),
    city: Joi.string().optional(),
    state: Joi.string().optional(),
    country: Joi.string().optional(),
    age: Joi.number().integer().optional(),
    lat: Joi.string().optional(),
    lon: Joi.string().optional()
});
