import { Controller, Body } from '@nestjs/common';
import { PollResponsesService } from './poll-responses.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_POLL_RESPONDED_USERS, CMD_RESPOND_POLL } from 'src/utils/constants/commands';

@Controller('poll-responses')
export class PollResponsesController {
    constructor(private readonly pollResponsesService: PollResponsesService) {}

    @MessagePattern({ cmd: CMD_RESPOND_POLL })
    async respondPoll(@Body() payload) {
        const { userId = '', pollId = '', body = {}, ip = '', query = {}, token = '' } = payload;
        return await this.pollResponsesService.respondPoll(userId, pollId, body, ip, query, token);
    }

    @MessagePattern({ cmd: CMD_GET_POLL_RESPONDED_USERS })
    async getRespondedUsers(@Body() payload) {
        const { paginateOptions, pollId, search, token = '' } = payload?.body || {};
        return await this.pollResponsesService.getUsersWhoRespondedToPoll({ paginateOptions, pollId, search, token });
    }
}
