import { forwardRef, Module } from '@nestjs/common';
import { PollResponsesService } from './poll-responses.service';
import { PollResponsesController } from './poll-responses.controller';
import { MongooseModule } from '@nestjs/mongoose';
import PollResponseSchema, { PollResponse } from './schema/poll-response.schema';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';
import { LocationsModule } from 'src/locations/locations.module';
import { UsersModule } from 'src/users/users.module';
import { PollInsightsModule } from 'src/poll-insights/poll-insights.module';
import PollResponseHistorySchema, {
    PollResponseHistory
} from 'src/poll-response-history/schemas/poll-response-history.schema';
import { ResponseQueuesModule } from 'src/response-queues/response-queues.module';
import { PollsModule } from 'src/polls/polls.module';
import { PollResponsesControllerV2 } from './v2/poll-responses.controller';
import { PollResponsesServiceV2 } from './v2/poll-responses.service';
import GroupPollSchema, { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import SharedPollSchema, { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import { EventQueuesModule } from 'src/event-queues/event-queues.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: PollResponse.name, schema: PollResponseSchema },
            { name: Poll.name, schema: PollSchema },
            { name: PollResponseHistory.name, schema: PollResponseHistorySchema },
            { name: GroupPoll.name, schema: GroupPollSchema },
            { name: SharedPoll.name, schema: SharedPollSchema }
        ]),
        LocationsModule,
        forwardRef(() => PollInsightsModule),
        forwardRef(() => UsersModule),
        ResponseQueuesModule,
        forwardRef(() => PollsModule),
        EventQueuesModule
    ],
    controllers: [PollResponsesController, PollResponsesControllerV2],
    providers: [PollResponsesService, PollResponsesServiceV2],
    exports: [PollResponsesService]
})
export class PollResponsesModule {}
