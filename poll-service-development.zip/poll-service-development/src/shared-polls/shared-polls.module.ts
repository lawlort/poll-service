import { Module } from '@nestjs/common';
import { SharedPollsService } from './shared-polls.service';
import { SharedPollsController } from './shared-polls.controller';
import { MongooseModule } from '@nestjs/mongoose';
import SharedPollSchema, { SharedPoll } from './schemas/shared-polls.schema';
import FollowRequestSchema, { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: SharedPoll.name, schema: SharedPollSchema },
            { name: FollowRequest.name, schema: FollowRequestSchema }
        ])
    ],
    controllers: [SharedPollsController],
    providers: [SharedPollsService],
    exports: [SharedPollsService]
})
export class SharedPollsModule {}
