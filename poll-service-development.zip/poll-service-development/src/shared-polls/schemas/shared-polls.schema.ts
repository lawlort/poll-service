import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';
import { Poll } from 'src/polls/schemas/poll.schema';
import { User } from 'src/users/schemas/user.schema';

@Schema({ timestamps: true, collection: 'poll_creation_shares', versionKey: false })
export class SharedPoll {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true, ref: Poll.name })
    pollId: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true, ref: User.name })
    sharedBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true, ref: User.name })
    sharedWith: string;

    @Prop({ default: false })
    isDeleted: boolean;
}

export const SharedPollSchema = SchemaFactory.createForClass(SharedPoll);

SharedPollSchema.index({ sharedBy: 1, sharedWith: 1, pollId: 1 });
SharedPollSchema.index({ sharedBy: 1 });
SharedPollSchema.index({ pollId: 1 });
SharedPollSchema.index({ sharedWith: 1 });

export type SharedPollDocument = HydratedDocument<SharedPoll>;

export default SharedPollSchema;
