import { Controller } from '@nestjs/common';
import { SharedPollsService } from './shared-polls.service';

@Controller('shared-polls')
export class SharedPollsController {
    constructor(private readonly sharedPollsService: SharedPollsService) {}
}
