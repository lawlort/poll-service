export const globalErrorObj = (message, field, type) => {
    return {
        details: [
            {
                message,
                path: [field],
                type,
                context: { label: field, key: field }
            }
        ]
    };
};
