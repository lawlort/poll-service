import { subYears } from 'date-fns';

export const calculateEstimatedBirthdate = (age: number): Date => {
    return subYears(new Date(), age);
};
