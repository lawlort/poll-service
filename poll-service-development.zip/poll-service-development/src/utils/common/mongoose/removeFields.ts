export const removeFieldsFromArrayOfObjects = (arr: any, fieldsToRemove: any) => {
    if (!Array.isArray(arr)) {
        return arr;
    }

    return arr.map((item) => {
        removeFieldsFromObject(item, fieldsToRemove);
        return item;
    });
};

export const removeFieldsFromObject = (item: any, fieldsToRemove: any) => {
    if (typeof item === 'object' && item !== null) {
        fieldsToRemove.forEach((field) => {
            delete item[field];
        });
        // Replace _id with id
        if (item.hasOwnProperty('_id')) {
            item['id'] = item['_id'];
            delete item['_id'];
        }
    }
    return item;
};
