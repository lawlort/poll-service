export const EVENT_TYPE_REMOVE_USER_FROM_GROUP = 'remove_user_from_group';
export const EVENT_TYPE_UPDATE_GENDER = 'update_gender';
export const EVENT_TYPE_DELETE_POLL_FROM_GROUP = 'delete_poll_from_group';
export const EVENT_TYPE_DELETE_ACCOUNT = 'delete_account';
export const EVENT_TYPE_DELETE_GROUP = 'delete_group';
