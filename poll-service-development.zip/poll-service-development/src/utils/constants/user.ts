export const USER_PERSONAL_DETAILS_FIELDS = [
    'countryCode',
    'mobile',
    'email',
    'fullName',
    'facebook',
    'instagram',
    'snapchat',
    'spotify',
    'website'
];
