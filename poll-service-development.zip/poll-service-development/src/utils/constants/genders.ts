export const GENDER_PREFER_NOT_TO_RESPOND = 'Prefer not to respond';
export const GENDER_MAN = 'Man';
export const GENDER_WOMAN = 'Woman';
export const GENDER_NON_BINARY = 'Non-binary';
export const GENDER_UNKNOWN = 'Unknown';
