export enum FollowRequestStatus {
    PENDING = 'pending',
    ACCEPTED = 'accepted',
    REJECTED = 'rejected'
}

export enum ProfileCompletionField {
    USERNAME = 'username',
    FULL_NAME = 'fullName',
    AGE = 'age',
    MOBILE = 'mobile',
    EMAIL = 'email',
    PROFILE_PIC_URL = 'profilePicUrl',
    MY_BIO = 'myBio',
    GENDER = 'gender',
    INTERESTS = 'interests'
}

export const TRUE_STRING = 'true';
export const FALSE_STRING = 'false';

export const DefaultUserSettings = {
    USE_ANONYMOUSLY: false,
    EMAIL_NOTIFICATION: false,
    IN_APP_NOTIFICATION: false,
    FOLLOW_NOTIFICATION: false,
    LIKE_NOTIFICATION: false,
    COMMENT_NOTIFICATION: false,
    NEW_POLL_NOTIFICATION: false,
    POLL_INSIGHTS_NOTIFICATION: false
};

export enum VisibilityTypes {
    PRIVATE = 'private',
    PUBLIC = 'public'
}
export const UNKNOWN = 'Unknown';

export const UNSET_VALUE = '6690f9bac5632a73d0a24d54';

export const UNITED_KINGDOM = 'United Kingdom';
