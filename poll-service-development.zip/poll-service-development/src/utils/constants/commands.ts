export const CMD_CHECK_MICRO_SERVICE_HEALTH = 'check_micro_service_health';

/* Auth service */
export const CMD_VALIDATE_TOKEN = 'validate_token';
export const CMD_VERIFY_TOKEN = 'verfify_token';
export const CMD_VERIFY_EMPTY_TOKEN = 'verfify_empty_token';

/* User service */

// Users
export const CMD_GET_USER_BY_ID = 'get_user_by_id';
export const CMD_GET_USER_INFO_BY_ID = 'get_user_info_by_id';
export const CMD_UPDATE_USER = 'update_user';
export const CMD_SET_AGE_AND_GENDER_WISE_DATA = 'set_age_and_gender_wise_data';
export const CMD_CREATE_USER = 'create_user';
export const CMD_GET_APP_USERS_DATA = 'get_app_users_data';
export const CMD_CHECK_USERNAME_AVAILABILITY = 'check_username_availability';
export const CMD_SYNC_CONTACTS = 'sync_contacts';
export const CMD_LOGOUT_USER = 'logout_user';
export const CMD_GET_REPORT_USER_REASONS = 'cmd_get_report_user_reasons';
export const CMD_REPORT_USER = 'cmd_report_user';
export const CMD_USER_INTERESTS = 'get_user_interest';
export const CMD_USER_SETTINGS = 'update_user_settings';
export const CMD_GET_USER_FOR_AUTH = 'get_user_for_auth';
export const CMD_UPDATE_USER_IN_CACHE = 'update_user_in_cache';
export const CMD_DELETE_USER = 'delete_user';
export const CMD_DELETE_USER_ACCOUNT = 'delete_user_account';
export const CMD_GET_DELETE_ACCOUNT_REASONS = 'get_delete_account_reasons';
export const CMD_PREPARE_USER = 'get_prepare_feed';
export const CMD_GET_ALL_USERS = 'get_all_users';
export const CMD_UPDATE_USER_GENDER = 'update_user_gender';

// CMS
export const CMD_GET_CMS_BY_SLUG = 'get_cms_by_slug';

// Device
export const CMD_CREATE_DEVICE = 'create_device';

// Genders
export const CMD_GET_ALL_GENDERS = 'get_all_genders';

// Interests
export const CMD_GET_ALL_INTERESTS = 'get_all_interests';
export const CMD_UPDATE_INTEREST = 'update_interest';

// Follow requests
export const CMD_CREATE_FOLLOW_REQUEST = 'create_follow_request';
export const CMD_UPDATE_FOLLOW_REQUEST = 'update_follow_request';
export const CMD_UNFOLLOW_USER = 'unfollow_user';
export const CMD_GET_ALL_FOLLOW_REQUESTS = 'get_all_follow_requests';
export const CMD_GET_ALL_FOLLOWERS = 'get_all_followers';
export const CMD_GET_ALL_FOLLOWINGS = 'get_all_followings';

/* Poll Service */

// Polls
export const CMD_CREATE_POLL = 'create_poll';
export const CMD_GET_POLL_BY_ID = 'get_poll_by_id';
export const CMD_GET_PROMOTED_POLL = 'get_promoted_poll_by_id';
export const CMD_DELETE_POLL_BY_ID = 'delete_poll_by_id';
export const CMD_UPDATE_POLL_BY_ID = 'update_poll_by_id';
export const CMD_GET_FEED = 'get_feed';
export const CMD_GET_FEED_V2 = 'get_feed_v2';
export const CMD_GET_POLL_RANGES = 'get_poll_range_labels';
export const CMD_BOOKMARK_POLL = 'bookmark_poll';
export const CMD_REMOVE_POLL_BOOKMARK = 'remove_poll_bookmark';
export const CMD_GET_MY_POLLS = 'get_my_polls';
export const CMD_GET_MY_POLLS_V2 = 'get_my_polls_v2';
export const CMD_RESPOND_POLL = 'respond_poll';
export const CMD_REPORT_POLL = 'cmd_report_poll';
export const CMD_GET_REPORT_POLL_REASONS = 'cmd_get_report_poll_reasons';
export const CMD_GET_POLL_INSIGHTS = 'get_poll_insights';
export const CMD_GET_POLL_INSIGHTS_V2 = 'get_poll_insights_v2';
export const CMD_CLOSE_POLL = 'cmd_close_poll';
export const CMD_GET_POLL_RESPONDED_USERS = 'responded_users';
export const CMD_ADD_MEDIA_MAPPING = 'add_media_mapping';
export const CMD_CREATE_POLL_V2 = 'create_poll_v2';
export const CMD_CREATE_POLL_V3 = 'create_poll_v3';
export const CMD_GET_POLL_RANGES_V2 = 'get_poll_range_labels_v2';
export const CMD_CALCULATE_POLL_RESPONSE = 'calculate_poll_response';
export const CMD_UPDATE_POLL_IN_CACHE = 'update_poll_in_cache';
export const CMD_RESPOND_POLL_V2 = 'respond_poll_v2';
export const CMD_GET_FEED_V3 = 'get_feed_v3';
export const CMD_REMOVE_POLL_RESPONSE = 'remove_poll_response';
export const CMD_GET_FEED_V4 = 'get_feed_v4';
export const CMD_CREATE_POLL_V4 = 'create_poll_v4';

/* Notification service */

export const CMD_SEND_NOTIFICATION = 'send_notification';

// Groups
export const CMD_CREATE_GROUP = 'create_group';
export const CMD_DELETE_GROUP = 'delete_group';
export const CMD_GET_GROUP_BY_ID = 'get_group_by_id';
export const CMD_GET_POLLS_BY_GROUP_ID = 'get_polls_by_group_id';
export const CMD_GET_POLLS_BY_GROUP_ID_V2 = 'get_polls_by_group_id_v2';
export const CMD_UPDATE_GROUP = 'update_group';
export const CMD_GET_ALL_GROUPS = 'get_all_groups';
export const CMD_ADD_GROUP_ADMIN = 'add_group_admin';
export const CMD_GET_REPORT_GROUP_REASONS = 'cmd_get_report_group_reasons';
export const CMD_REPORT_GROUP = 'cmd_report_group';
export const CMD_DELETE_POLL_FROM_GROUP = 'delete_poll_from_group';
export const CMD_DELETE_POLL_FROM_GROUP_FROM_CONSUMER = 'delete_poll_from_group_from_consumer';
export const CMD_DELETE_GROUP_THROUGH_CONSUMER = 'delete_group_through_consumer';

// Group members
export const CMD_REMOVE_GROUP_MEMBERS = 'remove_group_members';
export const CMD_CREATE_GROUP_MEMBER = 'create_group_member';
export const CMD_LEAVE_GROUP_MEMBERS = 'leave_group_members';
export const CMD_GET_ALL_GROUP_MEMBERS = 'get_all_group_members';

// Comments
export const CMD_GET_REPORT_COMMENT_REASONS = 'cmd_get_report_comment_reasons';
export const CMD_CREATE_POLL_COMMENT = 'create_poll_comment';
export const CMD_REPORT_POLL_COMMENT = 'report_poll_comment';
export const CMD_GET_POLL_COMMENT = 'get_poll_comment';
export const CMD_UPDATE_POLL_COMMENT = 'update_poll_comment';
export const CMD_DELETE_POLL_COMMENT = 'delete_poll_comment';
