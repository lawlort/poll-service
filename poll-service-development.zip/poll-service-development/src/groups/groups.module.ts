import { Module } from '@nestjs/common';
import { GroupsService } from './groups.service';
import { GroupsController } from './groups.controller';
import { MongooseModule } from '@nestjs/mongoose';
import GroupSchema, { Group } from './schemas/group.schema';
import GroupMemberSchema, { GroupMember } from 'src/group-members/schemas/group-members.schema';
import { InterestsModule } from 'src/interests/interests.module';
import UserSchema, { User } from 'src/users/schemas/user.schema';
import GroupPollSchema, { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import { FollowRequestsModule } from 'src/follow-requests/follow-requests.module';
import { EventQueuesModule } from 'src/event-queues/event-queues.module';
import { PollsModule } from 'src/polls/polls.module';
import PollResponseSchema, { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
import { ResponseQueuesModule } from 'src/response-queues/response-queues.module';
import PollResponseHistorySchema, {
    PollResponseHistory
} from 'src/poll-response-history/schemas/poll-response-history.schema';
import SharedPollSchema, { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';
import SharedPollWithUsersSchema, {
    SharedPollWithUsers
} from 'src/shared-poll-with-users/schemas/shared-poll-with-users.schema';
import BookmarkedPollSchema, { BookmarkedPoll } from 'src/bookmarked-polls/schemas/bookmarked-poll.schema';
import { UsersModule } from 'src/users/users.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: Group.name, schema: GroupSchema },
            { name: GroupMember.name, schema: GroupMemberSchema },
            { name: User.name, schema: UserSchema },
            { name: GroupPoll.name, schema: GroupPollSchema },
            { name: PollResponse.name, schema: PollResponseSchema },
            { name: PollResponseHistory.name, schema: PollResponseHistorySchema },
            { name: SharedPoll.name, schema: SharedPollSchema },
            { name: Poll.name, schema: PollSchema },
            { name: GroupMember.name, schema: GroupMemberSchema },
            { name: SharedPollWithUsers.name, schema: SharedPollWithUsersSchema },
            { name: BookmarkedPoll.name, schema: BookmarkedPollSchema }
        ]),
        InterestsModule,
        FollowRequestsModule,
        EventQueuesModule,
        PollsModule,
        ResponseQueuesModule,
        UsersModule
    ],
    controllers: [GroupsController],
    providers: [GroupsService]
})
export class GroupsModule {}
