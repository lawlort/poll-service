import { BadRequestException, Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Group } from './schemas/group.schema';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreateGroupSchema, VisibilityTypes } from './dto/createGroupSchema';
import { DeleteGroupSchema } from './dto/deleteGroupSchema';
import { RpcException } from '@nestjs/microservices';
import mongoose, { isValidObjectId, Model } from 'mongoose';
import { globalErrorObj } from 'src/utils/common/globalErrorRes';
import { createGroupAdminSchema } from './dto/createGroupAdminSchema';
import { InterestsService } from 'src/interests/interests.service';
import { User, UserDocument } from 'src/users/schemas/user.schema';
import { UpdateGroupSchema } from './dto/updateGroupSchema';
import { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import { trimObjectValues } from 'src/utils/common/object';
import { FollowRequestsService } from 'src/follow-requests/follow-requests.service';
import { EventQueuesService } from 'src/event-queues/event-queues.service';
import { EVENT_TYPE_DELETE_GROUP, EVENT_TYPE_DELETE_POLL_FROM_GROUP } from 'src/utils/constants/events';
import { PollsService } from 'src/polls/polls.service';
import { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
import { ResponseQueuesService } from 'src/response-queues/response-queues.service';
import { TRUE_STRING } from 'src/utils/constants/string';
import { PollResponseHistory } from 'src/poll-response-history/schemas/poll-response-history.schema';
import { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import { Poll, QuestionTypes } from 'src/polls/schemas/poll.schema';
import { SharedPollWithUsers } from 'src/shared-poll-with-users/schemas/shared-poll-with-users.schema';
import { BookmarkedPoll } from 'src/bookmarked-polls/schemas/bookmarked-poll.schema';
import { GroupMember } from 'src/group-members/schemas/group-members.schema';
import { UsersService } from 'src/users/users.service';

@Injectable()
export class GroupsService {
    constructor(
        @InjectModel(Group.name)
        private groupModel: Model<Group>,
        @InjectModel(GroupMember.name)
        private groupMembersModel: Model<GroupMember>,
        private interestsService: InterestsService,
        @InjectModel(User.name)
        private userModel: Model<UserDocument>,
        @InjectModel(GroupPoll.name) private groupPollModel: Model<GroupPoll>,
        private followRequestsService: FollowRequestsService,
        private eventQueueService: EventQueuesService,
        private pollService: PollsService,
        @InjectModel(PollResponse.name) private pollResponseModel: Model<PollResponse>,
        @InjectModel(PollResponseHistory.name) private pollResponseHistoryModel: Model<PollResponseHistory>,
        @InjectModel(SharedPoll.name) private sharedPollModel: Model<SharedPoll>,
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        @InjectModel(BookmarkedPoll.name) private bookmarkPollModel: Model<BookmarkedPoll>,
        @InjectModel(SharedPollWithUsers.name) private sharedPollWithUsersModel: Model<SharedPollWithUsers>,
        private responseQueueService: ResponseQueuesService,
        private userService: UsersService
    ) {}

    async create(groupsData, userId) {
        try {
            const groupData = trimObjectValues(groupsData);
            validateSchema(CreateGroupSchema, groupData);

            if (groupData?.groupInterests) {
                const validInterests = await this.interestsService.findAll();
                const validInterestIds = validInterests.map((interest) => interest.id.toString());
                const groupInterestIds = groupData.groupInterests || [];

                for (const interestId of groupInterestIds) {
                    if (!validInterestIds.includes(interestId)) {
                        throw new UnprocessableEntityException(`Interest ID ${interestId} is not valid`);
                    }
                }
            }

            const { memberIds = [], isAllFollowers = false } = groupsData;

            const invalidUserId = [];
            const userNotFound = [];
            const selfRequest = [];

            // Make memberIds unique
            const uniqueMemberIds = Array.from(new Set(memberIds.flatMap((id) => id.split(','))));

            // Validate and check for self-requests
            uniqueMemberIds.forEach((memberId) => {
                if (!isValidObjectId(memberId)) {
                    invalidUserId.push(memberId);
                } else if (userId.toString() === memberId.toString()) {
                    selfRequest.push(memberId);
                }
            });

            if (invalidUserId.length) {
                throw new BadRequestException(
                    globalErrorObj(`Invalid user id: [ ${invalidUserId.join(', ')} ]`, 'userId', 'string.base')
                );
            }
            if (selfRequest.length) {
                throw new BadRequestException(
                    globalErrorObj(
                        `Cannot add yourself in group: [ ${selfRequest.join(', ')} ]`,
                        'memberId',
                        'string.base'
                    )
                );
            }

            // Check if users exist
            const userChecks = uniqueMemberIds.map(async (memberId) => {
                const user = await this.userModel.findById(memberId).exec();
                if (!user?._id) {
                    userNotFound.push(memberId);
                }
            });

            await Promise.all(userChecks);

            if (userNotFound.length) {
                throw new NotFoundException(`User not found with user ID: [ ${userNotFound.join(', ')} ]`);
            }

            // Add all followers if isAllFollowers is true
            let membersToAdd = uniqueMemberIds;
            if (isAllFollowers) {
                const allFollowers = await this.followRequestsService.getAllFollowers(userId);
                membersToAdd = allFollowers.map((follower) => follower.userId);
            }

            // Check if any members are already in the group
            // const existingMembers = await this.groupMembersModel
            //     .find({
            //         groupId: group._id,
            //         userId: { $in: membersToAdd },
            //         isDeleted: false
            //     })
            //     .exec();

            // if (existingMembers.length > 0) {
            //     const existingMemberIds = existingMembers.map((member) => member.userId.toString());
            //     throw new BadRequestException(
            //         `Members with the following IDs are already in the group: ${existingMemberIds.join(', ')}`
            //     );
            // }

            // Create the group
            const createdGroup = new this.groupModel({
                ...groupData,
                admin: [userId],
                createdBy: userId,
                updatedBy: userId
            });
            const group = await createdGroup.save();

            // Add the member to the group
            const groupMember = new this.groupMembersModel({
                groupId: group._id,
                userId: userId,
                createdBy: userId,
                updatedBy: userId
            });

            await groupMember.save();

            // Add members to the group
            const groupMembers = membersToAdd.map((memberId) => ({
                groupId: group._id,
                userId: memberId,
                createdBy: userId,
                updatedBy: userId
            }));

            await this.groupMembersModel.insertMany(groupMembers);
            return { id: group._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async remove(groupId, userId, token) {
        try {
            validateSchema(DeleteGroupSchema, { id: groupId });

            // Validate ObjectId format
            if (!isValidObjectId(groupId)) {
                throw new NotFoundException('Group not found');
            }

            const group = await this.groupModel.findOne({
                _id: groupId,
                isDeleted: false,
                isActive: true
            });
            if (!group) {
                throw new NotFoundException('Group not found');
            }

            // Check if userId is in the admin array
            if (!(group?.admin || []).includes(userId) || group?.createdBy != userId) {
                throw new UnprocessableEntityException('You are not authorized to delete this group');
            }

            // Delete the group
            await this.groupModel.findByIdAndUpdate(
                groupId,
                { isDeleted: true, isActive: false, updatedBy: userId },
                { new: true }
            );

            // Delete the related group members - Remove member from consumer
            // await this.groupMembersModel.updateMany(
            //     { groupId: groupId },
            //     { $set: { isDeleted: true, isActive: false } }
            // );

            const payload = {
                eventType: EVENT_TYPE_DELETE_GROUP,
                groupId,
                userId,
                token
            };

            await this.eventQueueService.addJobToQueue(payload, EVENT_TYPE_DELETE_GROUP, groupId);

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async deleteGroupThroughConsumer(groupId, userId, currentUserId, token) {
        try {
            const group = await this.groupModel.findById(groupId).exec();
            console.log({ group });
            // get all polls shared in group
            // live and ended polls
            // get all group members
            //
            // check member has responded on live poll - if yes then remove response. before that check that poll is not shared individually or with other group
            //
            // remove relation of poll with group and remove group member soft delete

            const currentDate = new Date();

            const groupPolls = await this.groupPollModel.aggregate([
                // Step 1: Match the specific group by groupId
                { $match: { groupId: mongoose.Types.ObjectId.createFromHexString(groupId), isDeleted: false } },

                // Step 2: Join with the polls collection to get poll details
                {
                    $lookup: {
                        from: 'polls',
                        localField: 'pollId',
                        foreignField: '_id',
                        as: 'pollDetails'
                    }
                },

                // Step 3: Unwind pollDetails to de-normalize the array
                { $unwind: '$pollDetails' },

                // Step 4: Project necessary fields and categorize as 'live' or 'ended'
                {
                    $project: {
                        pollId: '$pollId',
                        pollEndDate: '$pollDetails.endDate',
                        isPollActive: '$pollDetails.isActive',
                        isPollDeleted: '$pollDetails.isDeleted',
                        pollVisibility: '$pollDetails.visibility',
                        pollStatus: {
                            $cond: [
                                {
                                    // If poll is active, not deleted, and endDate is in the future, mark it as 'live'
                                    $and: [
                                        { $eq: ['$pollDetails.isActive', true] },
                                        { $eq: ['$pollDetails.isDeleted', false] },
                                        { $gt: ['$pollDetails.endDate', currentDate] }
                                    ]
                                },
                                'live',
                                {
                                    // Otherwise, if poll is active, not deleted, and endDate has passed, mark it as 'ended'
                                    $cond: [
                                        {
                                            $and: [
                                                { $eq: ['$pollDetails.isActive', true] },
                                                { $eq: ['$pollDetails.isDeleted', false] },
                                                { $lt: ['$pollDetails.endDate', currentDate] }
                                            ]
                                        },
                                        'ended',
                                        'other' // Handle any other cases if needed
                                    ]
                                }
                            ]
                        }
                    }
                },

                // Step 5: Group polls by their status (live or ended)
                {
                    $group: {
                        _id: '$pollStatus',
                        polls: {
                            $push: {
                                pollId: '$pollId',
                                endDate: '$pollEndDate',
                                isActive: '$isPollActive',
                                isDeleted: '$isPollDeleted',
                                visibility: '$pollVisibility'
                            }
                        }
                    }
                }
            ]);

            // Formatting the results into separate live and ended arrays
            const pollsByStatus = groupPolls.reduce(
                (acc, statusGroup) => {
                    acc[statusGroup._id] = statusGroup.polls;
                    return acc;
                },
                { live: [], ended: [] }
            );

            console.log('Live Polls:', pollsByStatus.live);
            console.log('Ended Polls:', pollsByStatus.ended);

            const groupMembers = await this.groupMembersModel.find({ groupId, isActive: true, isDeleted: false });
            let memberIds = groupMembers.map((member) => member.userId);

            for (const poll of pollsByStatus.live) {
                const pollId = poll.pollId;
                let sharedPollWithUsersIds = [];
                if (poll?.visibility === VisibilityTypes.PRIVATE) {
                    // get all individual users with whom poll is shared and those users were also part of private group
                    const sharedPollWithUsers = await this.sharedPollWithUsersModel.find({
                        pollId,
                        sharedWith: { $in: memberIds }
                    });

                    sharedPollWithUsersIds = sharedPollWithUsers.map((sharedPoll) => sharedPoll.sharedWith.toString());

                    // get all groups with whom poll is shared except current group
                    const sharedGroupPolls = await this.groupPollModel.find({
                        pollId,
                        isDeleted: false,
                        groupId: { $ne: groupId }
                    });

                    const groupIds = sharedGroupPolls.map((groupPoll) => groupPoll.groupId);

                    // get all members of group except current group
                    const groupMembers = await this.groupMembersModel.find({
                        groupId: { $in: groupIds },
                        isActive: true,
                        isDeleted: false
                    });

                    const groupMemberIds = groupMembers.map((member) => member.userId.toString());

                    // list of unique member ids with whom poll is shared except current group
                    const uniqueMemberIds = Array.from(new Set([...sharedPollWithUsersIds, ...groupMemberIds]));

                    // remove those individual user ids from group members id array
                    memberIds = memberIds.filter((memberId) => !uniqueMemberIds.includes(memberId.toString()));
                } else if (poll?.visibility === VisibilityTypes.PUBLIC) {
                    // get all individual users with whom poll is shared and those users were also part of public group
                    const sharedPollWithUsers = await this.sharedPollWithUsersModel.find({
                        pollId,
                        sharedWith: { $in: memberIds }
                    });

                    sharedPollWithUsersIds = sharedPollWithUsers.map((sharedPoll) => sharedPoll.sharedWith.toString());
                    // remove those individual user ids from group members id array
                    memberIds = memberIds.filter((memberId) => !sharedPollWithUsersIds.includes(memberId.toString()));
                }

                // remove poll responses
                let pollResponsesToDelete = [];
                const pollResponses = await this.pollResponseModel.find({
                    pollId,
                    userId: { $in: memberIds }
                });

                // TODO: remove poll response history as well - DONE
                await this.pollResponseHistoryModel.updateMany(
                    {
                        pollId,
                        userId: { $in: memberIds }
                    },
                    {
                        $set: { isDeleted: true }
                    }
                );

                await this.sharedPollModel.updateMany(
                    {
                        pollId,
                        sharedWith: { $in: memberIds }
                    },
                    {
                        $set: { isDeleted: true }
                    }
                );

                const sharedPollCount = await this.sharedPollModel.countDocuments({
                    pollId,
                    isDeleted: false
                });

                pollResponsesToDelete = pollResponses;
                // remove response from database
                const pollResponsesToDeleteIds = pollResponsesToDelete.map((response) => response._id);

                for (const pollResponse of pollResponsesToDelete) {
                    await this.responseQueueService.addJobToQueue(
                        { ...pollResponse.toJSON(), removeResponse: true, token },
                        pollResponse.questionType,
                        pollId
                    );
                }

                await this.pollResponseModel.deleteMany({ _id: { $in: pollResponsesToDeleteIds } });
                if (poll && poll?.visibility === VisibilityTypes.PRIVATE) {
                    const pollDetails = await this.pollModel.findById(pollId).exec();
                    pollDetails['sharedWithUsersCount'] = sharedPollCount;
                    await pollDetails.save();
                }
            }

            // remove group members
            await this.groupMembersModel.updateMany(
                { groupId: groupId },
                { $set: { isDeleted: true, isActive: false } }
            );

            // remove poll from group
            const livePollIds = pollsByStatus.live.map((poll) => poll.pollId);
            const endedPollIds = pollsByStatus.ended.map((poll) => poll.pollId);

            const pollIds = [...livePollIds, ...endedPollIds];
            const pollIdsString = pollIds.map((id) => id.toString());
            const uniquePollIds = Array.from(new Set(pollIdsString));

            await this.groupPollModel.updateMany(
                { pollId: { $in: uniquePollIds }, groupId },
                { $set: { isDeleted: true } }
            );

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async findOne(groupId, userId) {
        try {
            validateSchema(DeleteGroupSchema, { id: groupId });

            // Validate ObjectId format
            if (!isValidObjectId(groupId)) {
                throw new NotFoundException('Group not found');
            }

            const group = await this.groupModel
                .findOne({
                    _id: groupId,
                    isDeleted: false,
                    isActive: true
                })
                .populate([
                    {
                        path: 'groupInterests',
                        select: 'name'
                    }
                ]);
            if (!group) {
                throw new NotFoundException('Group not found');
            }

            const groupMembersCount = await this.groupMembersModel.countDocuments({
                groupId: group._id,
                isActive: true,
                isDeleted: false
            });
            const pollsSharedInGroupCount = await this.groupPollModel.countDocuments({
                groupId: group._id,
                isDeleted: false
            });
            const groupAdmins = (group.admin || []).map((admin) => admin.toString());
            const isAdmin = groupAdmins.includes(userId);
            const groupMember = await this.groupMembersModel.findOne({
                groupId: group._id,
                userId: userId,
                isActive: true,
                isDeleted: false
            });
            const isGroupMember = groupMember?._id ? true : false;
            const updatedGroupInterests = (group?.groupInterests || []).map((interest: any) => {
                return {
                    id: interest._id,
                    name: interest.name
                };
            });

            return {
                name: group.name,
                groupBio: group.groupBio,
                groupPicUrl: group.groupPicUrl,
                createdBy: group.createdBy,
                admin: group.admin,
                groupInterests: updatedGroupInterests || [],
                id: group.id,
                groupMembersCount,
                pollsSharedInGroupCount,
                isAdmin,
                isGroupMember,
                activePollCount: 0, // TODO: calculate active polls shared in the group,
                groupType: group?.groupType,
                allowMembersToPost: group?.allowMembersToPost
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async update(groupId, groupsData, userId) {
        try {
            const data = trimObjectValues(groupsData);
            validateSchema(UpdateGroupSchema, data);

            // Validate ObjectId format
            if (!isValidObjectId(groupId)) {
                throw new NotFoundException('Group not found');
            }

            const group = await this.groupModel.findOne({
                _id: groupId,
                isDeleted: false,
                isActive: true
            });
            if (!group) {
                throw new NotFoundException('Group not found');
            }

            // Check if userId is in the admin array
            if (!(group?.admin || []).includes(userId) || group?.createdBy != userId) {
                throw new UnprocessableEntityException('You are not authorized to update this group');
            }

            // Check that the provided interest IDs exist in the database
            const validInterests = await this.interestsService.findAll();
            const validInterestIds = validInterests.map((interest) => interest.id.toString());
            const groupInterestIds = data.groupInterests || [];

            for (const interestId of groupInterestIds) {
                if (!validInterestIds.includes(interestId)) {
                    throw new UnprocessableEntityException(`Interest ID ${interestId} is not valid`);
                }
            }

            const updatedGroup = await this.groupModel.findByIdAndUpdate(groupId, data, {
                new: true
            });
            if (!updatedGroup?._id) {
                throw new NotFoundException('Group not found');
            }
            return {
                name: updatedGroup.name,
                groupBio: updatedGroup.groupBio,
                groupPicUrl: updatedGroup.groupPicUrl,
                createdBy: updatedGroup.createdBy,
                admin: updatedGroup.admin,
                id: updatedGroup.id
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async findAll({
        paginateOptions,
        search,
        createdByMe,
        userId,
        groupType,
        allowMembersToPost,
        matchInterests,
        pollInterests
    }: {
        paginateOptions: { page: number; limit: number; paginate: boolean };
        search: string;
        createdByMe?: boolean;
        userId: string;
        groupType?: string;
        allowMembersToPost?: boolean;
        matchInterests?: boolean;
        pollInterests?: string[];
    }): Promise<any> {
        try {
            const matchConditions: any = {
                isActive: true,
                isDeleted: false
            };

            // If createdByMe is true, retrieve all groups created by the user
            if (createdByMe) {
                matchConditions.createdBy = mongoose.Types.ObjectId.createFromHexString(userId);
                if (groupType) {
                    matchConditions.groupType = groupType;
                }
            } else if (groupType || allowMembersToPost || matchInterests) {
                // If matchInterests is true, ensure at least one interest matches and the group is public
                if (matchInterests) {
                    // Fetch user's interests
                    const user = await this.userModel.findById(userId).select('interests').lean();
                    const userInterests = user?.interests || [];
                    matchConditions.$and = [
                        { groupType: VisibilityTypes.PUBLIC }, // Group must be public
                        { groupInterests: { $in: userInterests } } // At least one interest must match
                    ];
                } else {
                    // If groupType, allowMembersToPost is provided, filter by those conditions
                    const userGroups = await this.groupMembersModel
                        .find({ userId, isActive: true, isDeleted: false })
                        .distinct('groupId');
                    matchConditions.$or = [
                        { createdBy: mongoose.Types.ObjectId.createFromHexString(userId) },
                        { _id: { $in: userGroups } }
                    ];
                }

                if (groupType) {
                    matchConditions.groupType = groupType;
                }
            } else if (!(pollInterests && pollInterests.length > 0)) {
                const userGroups = await this.groupMembersModel
                    .find({ userId, isActive: true, isDeleted: false })
                    .distinct('groupId');

                matchConditions.$or = [
                    { createdBy: mongoose.Types.ObjectId.createFromHexString(userId) },
                    { _id: { $in: userGroups } }
                ];
            }

            // Apply the allowMembersToPost filter
            if (allowMembersToPost) {
                matchConditions.allowMembersToPost = true;
            }

            // Add search filtering if search string is provided
            if (search) {
                matchConditions.name = { $regex: `${search}`, $options: 'i' };
            }

            // Check for pollInterests and add to match conditions
            if (pollInterests && pollInterests?.length > 0) {
                matchConditions.groupInterests = {
                    $in: pollInterests.map((id) => mongoose.Types.ObjectId.createFromHexString(id))
                }; // Convert string IDs to ObjectId
            }

            // Create query using match conditions
            let query = this.groupModel.find(matchConditions).populate([
                {
                    path: 'groupInterests'
                    // select: 'id name'
                }
            ]);

            // Sort by `createdAt` in descending order
            query = query.sort({ createdAt: -1 });

            // Select required fields
            query = query.select({
                _id: 1,
                name: 1,
                groupPicUrl: 1,
                createdBy: 1,
                admin: 1,
                createdAt: 1,
                groupInterests: 1
            });

            // ** Fetch and count the groups created by or where the user is a member **
            const myGroupCountConditions: any = {
                isActive: true,
                isDeleted: false,
                $or: [
                    { createdBy: mongoose.Types.ObjectId.createFromHexString(userId) },
                    {
                        _id: {
                            $in: await this.groupMembersModel
                                .find({ userId, isActive: true, isDeleted: false })
                                .distinct('groupId')
                        }
                    }
                ]
            };
            const myGroupCount = await this.groupModel.countDocuments(myGroupCountConditions);

            // Handle pagination if enabled
            if (paginateOptions.paginate) {
                const count = await query.clone().countDocuments();
                const results = await query
                    .skip((paginateOptions.page - 1) * paginateOptions.limit)
                    .limit(paginateOptions.limit)
                    .exec();

                const transformedData = await this.processGroupResults(results);
                const paginatedResponse = this.buildPaginatedResponse(transformedData, count, paginateOptions);

                // ** Add `myGroupCount` to the response **
                return {
                    ...paginatedResponse,
                    myGroupCount
                };
            } else {
                const results = await query.exec();
                const transformedData = await this.processGroupResults(results);
                const response = this.buildPaginatedResponse(
                    transformedData,
                    transformedData.length,
                    paginateOptions,
                    false
                );

                // ** Add `myGroupCount` to the response **
                return {
                    ...response,
                    myGroupCount
                };
            }
        } catch (error) {
            throw new RpcException(error);
        }
    }

    // Helper function to process group results (e.g., fetching member counts)
    async processGroupResults(results: any[]) {
        return await Promise.all(
            results.map(async (group: any) => {
                const memberCount = await this.groupMembersModel.countDocuments({
                    groupId: group?._id,
                    isActive: true,
                    isDeleted: false
                });

                const updatedGroupInterests = (group?.groupInterests || []).map((interest) => {
                    return {
                        id: interest._id,
                        name: interest.name
                    };
                });

                return {
                    membersCount: memberCount,
                    name: group.name,
                    groupPicUrl: group.groupPicUrl,
                    createdBy: group.createdBy,
                    admin: group.admin,
                    id: group._id.toString(),
                    groupInterests: updatedGroupInterests || []
                };
            })
        );
    }

    // Helper function to build paginated response
    buildPaginatedResponse(
        data: any[],
        total: number,
        paginateOptions: { page: number; limit: number },
        paginate = true
    ) {
        return {
            data,
            total,
            limit: paginate ? paginateOptions.limit : data.length,
            page: paginate ? paginateOptions.page : 1,
            totalPages: paginate ? Math.ceil(total / paginateOptions.limit) : 1,
            pagingCounter: paginate ? (paginateOptions.page - 1) * paginateOptions.limit + 1 : 1,
            hasPrevPage: paginate ? paginateOptions.page > 1 : false,
            hasNextPage: paginate ? paginateOptions.page * paginateOptions.limit < total : false,
            prevPage: paginate && paginateOptions.page > 1 ? paginateOptions.page - 1 : null,
            nextPage: paginate && paginateOptions.page * paginateOptions.limit < total ? paginateOptions.page + 1 : null
        };
    }

    async addAdminToGroup(groupId, adminData, userId) {
        try {
            // Validate ObjectId format for groupId
            if (!isValidObjectId(groupId)) {
                throw new BadRequestException(globalErrorObj('Group id is invalid', 'groupId', 'string.base'));
            }

            validateSchema(createGroupAdminSchema, adminData);

            let { adminIds } = adminData;
            adminIds = Array.from(new Set(adminIds.flatMap((id) => id.split(','))));

            const invalidAdminIds = [];
            const alreadyAdminIds = [];
            const nonMemberIds = [];

            // Check if the group exists and is active
            const group = await this.groupModel.findOne({
                _id: groupId,
                isDeleted: false,
                isActive: true
            });

            if (!group) {
                throw new NotFoundException('Group not found');
            }

            // Check if userId is in the admin array
            if (!(group?.admin || []).includes(userId)) {
                throw new UnprocessableEntityException('You are not authorized to add admin');
            }

            // Validate each adminId in adminIds
            const adminIdChecks = adminIds.map(async (adminId) => {
                if (!isValidObjectId(adminId)) {
                    invalidAdminIds.push(adminId); // Collect invalid adminId
                } else if (group.admin.includes(adminId)) {
                    alreadyAdminIds.push(adminId); // Collect already assigned admin
                } else {
                    // Check if adminId is part of the group members
                    const isMember = await this.groupMembersModel.findOne({
                        groupId: mongoose.Types.ObjectId.createFromHexString(groupId),
                        userId: mongoose.Types.ObjectId.createFromHexString(adminId)
                    });

                    if (!isMember) {
                        nonMemberIds.push(adminId);
                    } else {
                        group.admin.push(adminId);
                    }
                }
            });
            await Promise.all(adminIdChecks);

            if (invalidAdminIds.length) {
                throw new BadRequestException(
                    globalErrorObj(`Invalid admin id: [ ${invalidAdminIds.join(', ')} ]`, 'adminId', 'string.base')
                );
            }

            if (alreadyAdminIds.length) {
                throw new BadRequestException(
                    globalErrorObj(`Already an admin: [ ${alreadyAdminIds.join(', ')} ]`, 'adminId', 'string.base')
                );
            }

            if (nonMemberIds.length) {
                throw new BadRequestException(
                    globalErrorObj(
                        `Not a member of the group: [ ${nonMemberIds.join(', ')} ]`,
                        'adminId',
                        'string.base'
                    )
                );
            }

            if (group.admin.length) {
                await group.save();
            }

            return {
                success: true
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    // Old function to get polls from group
    // async findPolls(groupId, paginateOptions, queryParams, userId) {
    //     try {
    //         const skipCount = (paginateOptions.page - 1) * paginateOptions.limit;
    //         const limitCount = paginateOptions.limit;

    //         validateSchema(DeleteGroupSchema, { id: groupId });

    //         // Validate ObjectId format
    //         if (!isValidObjectId(groupId)) {
    //             throw new NotFoundException('Group not found');
    //         }

    //         const group = await this.groupModel.findOne({
    //             _id: groupId,
    //             isDeleted: false,
    //             isActive: true
    //         });
    //         if (!group) {
    //             throw new NotFoundException('Group not found');
    //         }

    //         // Build aggregation pipeline
    //         const pipeline: any = [
    //             // Match group polls that are not deleted and belong to the specified group
    //             {
    //                 $match: {
    //                     groupId: mongoose.Types.ObjectId.createFromHexString(groupId),
    //                     isDeleted: false
    //                 }
    //             },

    //             // Lookup poll details and populate interests
    //             {
    //                 $lookup: {
    //                     from: 'polls',
    //                     localField: 'pollId',
    //                     foreignField: '_id',
    //                     as: 'pollDetails'
    //                 }
    //             },
    //             { $unwind: '$pollDetails' },

    //             // Additional match for active/trending filters if provided
    //             ...(queryParams.isActive === TRUE_STRING || queryParams.trendingPolls === TRUE_STRING
    //                 ? [
    //                       {
    //                           $match: {
    //                               'pollDetails.isActive': true,
    //                               'pollDetails.isDeleted': false,
    //                               'pollDetails.isClosed': false,
    //                               'pollDetails.endDate': { $gt: new Date() }
    //                           }
    //                       }
    //                   ]
    //                 : [
    //                       {
    //                           $match: {
    //                               'pollDetails.isActive': true,
    //                               'pollDetails.isDeleted': false
    //                           }
    //                       }
    //                   ]),

    //             // Sort by votes if trendingPolls is enabled
    //             ...(queryParams.trendingPolls === TRUE_STRING ? [{ $sort: { 'pollDetails.votersCount': -1 } }] : []),

    //             // Populate poll interests
    //             {
    //                 $lookup: {
    //                     from: 'interests',
    //                     localField: 'pollDetails.interests',
    //                     foreignField: '_id',
    //                     as: 'pollDetails.interests'
    //                 }
    //             },

    //             // Sort by creation date in descending order to get the latest polls first
    //             { $sort: { 'pollDetails.createdAt': -1 } },

    //             // Project only required fields
    //             {
    //                 $project: {
    //                     _id: 0,
    //                     pollDetails: 1
    //                 }
    //             },

    //             // Pagination
    //             { $skip: skipCount },
    //             { $limit: limitCount }
    //         ];

    //         // Run the aggregation with pagination
    //         let paginatedPolls = await this.groupPollModel.aggregate(pipeline).exec();

    //         const pollResponsesObj: any = {};

    //         // Using Promise.all to fetch responses concurrently
    //         await Promise.all(
    //             paginatedPolls.map(async (poll) => {
    //                 const pollId = poll.pollDetails._id;
    //                 const pollResponsesCount = await this.pollResponseModel.countDocuments({ pollId, userId });
    //                 pollResponsesObj[pollId.toString()] = pollResponsesCount; // Store responses for each pollId
    //             })
    //         );

    //         // Extract poll details and format interests
    //         paginatedPolls = paginatedPolls
    //             .filter((poll) => poll?.pollDetails)
    //             .map((poll) => {
    //                 const pollDetails = poll.pollDetails;

    //                 // Rename `_id` to `id`
    //                 pollDetails.id = pollDetails._id;

    //                 // Map interests to names only
    //                 pollDetails.interests = pollDetails.interests.map((interest) => interest.name);
    //                 pollDetails.isAnswered = pollResponsesObj[pollDetails._id.toString()] > 0;

    //                 return pollDetails;
    //             });

    //         // Calculate total results by removing the last 4 stages from the pipeline and adding a $count stage
    //         const countPipeline = pipeline.slice(0, -3); // Exclude $skip and $limit
    //         countPipeline.push({ $count: 'totalResults' });

    //         const totalResultsArray = await this.groupPollModel.aggregate(countPipeline).exec();
    //         const totalResults = totalResultsArray.length > 0 ? totalResultsArray[0].totalResults : 0;
    //         const totalPages = Math.ceil(totalResults / paginateOptions.limit);

    //         return {
    //             docs: paginatedPolls,
    //             page: paginateOptions.page,
    //             limit: paginateOptions.limit,
    //             totalPages,
    //             totalResults
    //         };
    //     } catch (error) {
    //         throw new RpcException(error);
    //     }
    // }

    async findPolls(groupId, paginateOptions, queryParams, userId) {
        try {
            const skipCount = (paginateOptions.page - 1) * paginateOptions.limit;
            const limitCount = paginateOptions.limit;

            validateSchema(DeleteGroupSchema, { id: groupId });

            // Validate ObjectId format
            if (!isValidObjectId(groupId)) {
                throw new NotFoundException('Group not found');
            }

            const group = await this.groupModel.findOne({
                _id: groupId,
                isDeleted: false,
                isActive: true
            });
            if (!group) {
                throw new NotFoundException('Group not found');
            }

            // Build aggregation pipeline
            const pipeline: any = [
                // Match group polls that are not deleted and belong to the specified group
                {
                    $match: {
                        groupId: mongoose.Types.ObjectId.createFromHexString(groupId),
                        isDeleted: false
                    }
                },

                // Lookup poll details and populate interests
                {
                    $lookup: {
                        from: 'polls',
                        localField: 'pollId',
                        foreignField: '_id',
                        as: 'pollDetails'
                    }
                },
                { $unwind: '$pollDetails' },

                // Additional match for active/trending filters if provided
                ...(queryParams.isActive === TRUE_STRING || queryParams.trendingPolls === TRUE_STRING
                    ? [
                          {
                              $match: {
                                  'pollDetails.isActive': true,
                                  'pollDetails.isDeleted': false,
                                  'pollDetails.isClosed': false,
                                  'pollDetails.endDate': { $gt: new Date() }
                              }
                          }
                      ]
                    : [
                          {
                              $match: {
                                  'pollDetails.isActive': true,
                                  'pollDetails.isDeleted': false
                              }
                          }
                      ]),

                // Sort by votes if trendingPolls is enabled
                ...(queryParams.trendingPolls === TRUE_STRING
                    ? [{ $sort: { 'pollDetails.votersCount': -1 } }]
                    : [{ $sort: { 'pollDetails.createdAt': -1 } }]),

                // Populate poll interests
                {
                    $lookup: {
                        from: 'interests',
                        localField: 'pollDetails.interests',
                        foreignField: '_id',
                        as: 'pollDetails.interests'
                    }
                },

                // Project only required fields
                {
                    $project: {
                        _id: 0,
                        pollDetails: 1
                    }
                },

                // Pagination
                { $skip: skipCount },
                { $limit: limitCount }
            ];

            // Run the aggregation with pagination
            let paginatedPolls = await this.groupPollModel.aggregate(pipeline).exec();

            const pollResponsesObj: any = {};

            // Using Promise.all to fetch responses concurrently
            await Promise.all(
                paginatedPolls.map(async (poll) => {
                    const pollId = poll.pollDetails._id;
                    const pollResponsesCount = await this.pollResponseModel.countDocuments({ pollId, userId });
                    pollResponsesObj[pollId.toString()] = pollResponsesCount; // Store responses for each pollId
                })
            );

            const pollResponseHistory: any = {};

            const pollIds = paginatedPolls.map((poll) => poll.pollDetails._id);

            await Promise.all(
                pollIds.map(async (pollId) => {
                    const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                        pollId,
                        userId,
                        isDeleted: false
                    });
                    pollResponseHistory[pollId.toString()] = pollResponseHistoryCount; // Store responses for each pollId
                })
            );

            const bookmarkedPollObj: any = {};
            await Promise.all(
                pollIds.map(async (pollId) => {
                    const bookmarkedPoll = await this.bookmarkPollModel.findOne({ pollId, bookmarkedBy: userId });
                    bookmarkedPollObj[pollId.toString()] = bookmarkedPoll?._id ? true : false;
                })
            );

            const allPollResponses: any = {};
            // Using Promise.all to fetch responses concurrently
            await Promise.all(
                pollIds.map(async (pollId) => {
                    const pollResponses = await this.pollResponseModel.find({ pollId, userId });
                    allPollResponses[pollId.toString()] = pollResponses; // Store responses for each pollId
                })
            );

            // First, find all the group memberships for the user
            const userGroups = await this.groupMembersModel
                .find({ userId: userId, isActive: true, isDeleted: false }) // Ensure user is active and not deleted
                .select('groupId') // Select only the groupId field
                .exec();

            // Extract the group IDs that the user is a member of
            const userGroupIds = userGroups.map((membership) => membership.groupId);
            const userGroupIdsString = userGroupIds.map((id) => id.toString());

            const groupSharedPolls = await this.groupPollModel
                .find({ pollId: { $in: pollIds }, isDeleted: false }) // Filter by pollId and user's groupIds
                .populate({
                    path: 'groupId',
                    populate: {
                        path: 'groupInterests',
                        select: '_id name'
                    }
                })
                .exec();

            // Extract poll details and format interests
            paginatedPolls = paginatedPolls
                .filter((poll) => poll?.pollDetails)
                .map((poll) => {
                    const pollDetails = poll.pollDetails;

                    // Rename `_id` to `id`
                    pollDetails.id = pollDetails._id;

                    const groupDetails: any = (
                        groupSharedPolls.filter(
                            (groupPoll) => groupPoll?.pollId?.toString() === pollDetails?._id?.toString()
                        ) || []
                    )
                        .map((groupPoll) => groupPoll?.groupId)
                        .filter((group) => group)
                        .map((group: any) => {
                            return {
                                ...group.toObject(),
                                isGroupMember: userGroupIdsString.includes(group?._id?.toString())
                            };
                        });

                    if (!pollDetails['votes']) {
                        pollDetails['votes'] = 0;
                    }
                    if (!pollDetails['votersCount']) {
                        pollDetails['votersCount'] = 0;
                    }
                    if (!pollDetails['sharedWithUsersCount']) {
                        pollDetails['sharedWithUsersCount'] = 0;
                    }

                    const pollResponses = allPollResponses[pollDetails?._id?.toString()];
                    if (pollDetails?.questions?.length) {
                        pollDetails.questions = pollDetails.questions.map((question: any) => {
                            const options = question?.options || [];

                            // If poll type is SINGLE_CHOICE or THIS_THAT
                            if (
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.THIS_THAT
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionId = pollResponse?.optionId;

                                // Map options to add isSelected field
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: option.id === optionId
                                }));
                            }

                            // If poll type is MULTIPLE_CHOICE or DATE
                            if (
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const optionIds = pollResponses.map((response) => response?.optionId);

                                // Map options to add isSelected field for multiple choice
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: optionIds.includes(option.id)
                                }));
                            }

                            // If poll type is SLIDER or LIGHT_METER
                            if (
                                question?.type === QuestionTypes.SLIDER ||
                                question?.type === QuestionTypes.LIGHT_METER
                            ) {
                                pollResponses?.length &&
                                    pollResponses[0] &&
                                    (question.sliderValue = pollResponses[0]?.sliderValue || 0);
                            }

                            // If poll type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                question.options = options.map((option) => {
                                    const pollResponse = pollResponses.find(
                                        (response) => response.optionId === option.id
                                    );
                                    return {
                                        ...option,
                                        selectedRank: pollResponse?.order || null
                                    };
                                });
                            }

                            return question;
                        });
                    }

                    // Map interests to names only
                    pollDetails.interests = pollDetails.interests.map((interest) => interest.name);
                    pollDetails.isAnswered = pollResponsesObj[pollDetails._id.toString()] > 0;
                    pollDetails.groups = groupDetails || [];
                    pollDetails.allowChangeMyMind = pollResponseHistory[pollDetails._id.toString()] < 2;
                    pollDetails.isSaved = bookmarkedPollObj[pollDetails._id.toString()];
                    pollDetails.commentCount = 0;
                    pollDetails.voterImages = [
                        'https://www.shutterstock.com/image-photo/image-handsome-smiling-young-african-260nw-722913181.jpg',
                        'https://t4.ftcdn.net/jpg/02/32/98/33/360_F_232983351_z5CAl79bHkm6eMPSoG7FggQfsJLxiZjY.jpg',
                        'https://st2.depositphotos.com/4431055/7492/i/950/depositphotos_74925449-stock-photo-men-human-face-smiling.jpg'
                    ];

                    return pollDetails;
                });

            // Calculate total results by removing the last 4 stages from the pipeline and adding a $count stage
            const countPipeline = pipeline.slice(0, -3); // Exclude $skip and $limit
            countPipeline.push({ $count: 'totalResults' });

            const totalResultsArray = await this.groupPollModel.aggregate(countPipeline).exec();
            const totalResults = totalResultsArray.length > 0 ? totalResultsArray[0].totalResults : 0;
            const totalPages = Math.ceil(totalResults / paginateOptions.limit);

            return {
                docs: paginatedPolls,
                page: paginateOptions.page,
                limit: paginateOptions.limit,
                totalPages,
                totalResults
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }
    async findPollsV2(groupId, paginateOptions, queryParams, userId) {
        try {
            const skipCount = (paginateOptions.page - 1) * paginateOptions.limit;
            const limitCount = paginateOptions.limit;

            validateSchema(DeleteGroupSchema, { id: groupId });

            // Validate ObjectId format
            if (!isValidObjectId(groupId)) {
                throw new NotFoundException('Group not found');
            }

            const group = await this.groupModel.findOne({
                _id: groupId,
                isDeleted: false,
                isActive: true
            });
            if (!group) {
                throw new NotFoundException('Group not found');
            }

            // Build aggregation pipeline
            const pipeline: any = [
                // Match group polls that are not deleted and belong to the specified group
                {
                    $match: {
                        groupId: mongoose.Types.ObjectId.createFromHexString(groupId),
                        isDeleted: false
                    }
                },

                // Lookup poll details and populate interests
                {
                    $lookup: {
                        from: 'polls',
                        localField: 'pollId',
                        foreignField: '_id',
                        as: 'pollDetails'
                    }
                },
                { $unwind: '$pollDetails' },

                // Additional match for active/trending filters if provided
                ...(queryParams.isActive === TRUE_STRING || queryParams.trendingPolls === TRUE_STRING
                    ? [
                          {
                              $match: {
                                  'pollDetails.isActive': true,
                                  'pollDetails.isDeleted': false,
                                  'pollDetails.isClosed': false,
                                  'pollDetails.endDate': { $gt: new Date() }
                              }
                          }
                      ]
                    : [
                          {
                              $match: {
                                  'pollDetails.isActive': true,
                                  'pollDetails.isDeleted': false
                              }
                          }
                      ]),

                // Sort by votes if trendingPolls is enabled
                ...(queryParams.trendingPolls === TRUE_STRING
                    ? [{ $sort: { 'pollDetails.votersCount': -1 } }]
                    : [{ $sort: { 'pollDetails.createdAt': -1 } }]),

                // Populate poll interests
                {
                    $lookup: {
                        from: 'interests',
                        localField: 'pollDetails.interests',
                        foreignField: '_id',
                        as: 'pollDetails.interests'
                    }
                },

                // Project only required fields
                {
                    $project: {
                        _id: 0,
                        pollDetails: 1
                    }
                },

                // Pagination
                { $skip: skipCount },
                { $limit: limitCount }
            ];

            // Run the aggregation with pagination
            let paginatedPolls = await this.groupPollModel.aggregate(pipeline).exec();

            const pollResponsesObj: any = {};

            // Using Promise.all to fetch responses concurrently
            await Promise.all(
                paginatedPolls.map(async (poll) => {
                    const pollId = poll.pollDetails._id;
                    const pollResponsesCount = await this.pollResponseModel.countDocuments({ pollId, userId });
                    pollResponsesObj[pollId.toString()] = pollResponsesCount; // Store responses for each pollId
                })
            );

            const pollResponseHistory: any = {};

            const pollIds = paginatedPolls.map((poll) => poll.pollDetails._id);

            await Promise.all(
                pollIds.map(async (pollId) => {
                    const pollResponseHistoryCount = await this.pollResponseHistoryModel.countDocuments({
                        pollId,
                        userId,
                        isDeleted: false
                    });
                    pollResponseHistory[pollId.toString()] = pollResponseHistoryCount; // Store responses for each pollId
                })
            );

            const bookmarkedPollObj: any = {};
            await Promise.all(
                pollIds.map(async (pollId) => {
                    const bookmarkedPoll = await this.bookmarkPollModel.findOne({ pollId, bookmarkedBy: userId });
                    bookmarkedPollObj[pollId.toString()] = bookmarkedPoll?._id ? true : false;
                })
            );

            const allPollResponses: any = {};
            // Using Promise.all to fetch responses concurrently
            await Promise.all(
                pollIds.map(async (pollId) => {
                    const pollResponses = await this.pollResponseModel.find({ pollId, userId });
                    allPollResponses[pollId.toString()] = pollResponses; // Store responses for each pollId
                })
            );

            // First, find all the group memberships for the user
            const userGroups = await this.groupMembersModel
                .find({ userId: userId, isActive: true, isDeleted: false }) // Ensure user is active and not deleted
                .select('groupId') // Select only the groupId field
                .exec();

            // Extract the group IDs that the user is a member of
            const userGroupIds = userGroups.map((membership) => membership.groupId);
            const userGroupIdsString = userGroupIds.map((id) => id.toString());

            const groupSharedPolls = await this.groupPollModel
                .find({ pollId: { $in: pollIds }, isDeleted: false }) // Filter by pollId and user's groupIds
                .populate({
                    path: 'groupId',
                    populate: {
                        path: 'groupInterests',
                        select: '_id name'
                    }
                })
                .exec();

            const user = await this.userService.getUserById(userId);
            const userInterests = user?.interests || [];
            const userInterestNames = userInterests.map((interest: any) => interest.name); // Get user interest names

            // Extract poll details and format interests
            paginatedPolls = paginatedPolls
                .filter((poll) => poll?.pollDetails)
                .map((poll) => {
                    const pollDetails = poll.pollDetails;

                    // Rename `_id` to `id`
                    pollDetails.id = pollDetails._id;

                    const groupDetails: any = (
                        groupSharedPolls.filter(
                            (groupPoll) => groupPoll?.pollId?.toString() === pollDetails?._id?.toString()
                        ) || []
                    )
                        .map((groupPoll) => groupPoll?.groupId)
                        .filter((group) => group)
                        .map((group: any) => {
                            return {
                                ...group.toObject(),
                                isGroupMember: userGroupIdsString.includes(group?._id?.toString())
                            };
                        });

                    if (!pollDetails['votes']) {
                        pollDetails['votes'] = 0;
                    }
                    if (!pollDetails['votersCount']) {
                        pollDetails['votersCount'] = 0;
                    }
                    if (!pollDetails['sharedWithUsersCount']) {
                        pollDetails['sharedWithUsersCount'] = 0;
                    }

                    const pollResponses = allPollResponses[pollDetails?._id?.toString()];
                    if (pollDetails?.questions?.length) {
                        pollDetails.questions = pollDetails.questions.map((question: any) => {
                            const options = question?.options || [];

                            // If poll type is SINGLE_CHOICE or THIS_THAT
                            if (
                                question?.type === QuestionTypes.SINGLE_CHOICE ||
                                question?.type === QuestionTypes.THIS_THAT
                            ) {
                                const pollResponse = pollResponses[0];
                                const optionId = pollResponse?.optionId;

                                // Map options to add isSelected field
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: option.id === optionId
                                }));
                            }

                            // If poll type is MULTIPLE_CHOICE or DATE
                            if (
                                question?.type === QuestionTypes.MULTIPLE_CHOICE ||
                                question?.type === QuestionTypes.DATE
                            ) {
                                const optionIds = pollResponses.map((response) => response?.optionId);

                                // Map options to add isSelected field for multiple choice
                                question.options = options.map((option) => ({
                                    ...option,
                                    isSelected: optionIds.includes(option.id)
                                }));
                            }

                            // If poll type is SLIDER or LIGHT_METER
                            if (
                                question?.type === QuestionTypes.SLIDER ||
                                question?.type === QuestionTypes.LIGHT_METER
                            ) {
                                pollResponses?.length &&
                                    pollResponses[0] &&
                                    (question.sliderValue = pollResponses[0]?.sliderValue || 0);
                            }

                            // If poll type is RANKING
                            if (question?.type === QuestionTypes.RANKING) {
                                question.options = options.map((option) => {
                                    const pollResponse = pollResponses.find(
                                        (response) => response.optionId === option.id
                                    );
                                    return {
                                        ...option,
                                        selectedRank: pollResponse?.order || null
                                    };
                                });
                            }

                            return question;
                        });
                    }

                    // Map interests to names only
                    // pollDetails.interests = pollDetails.interests.map((interest) => interest.name);
                    pollDetails['interests'] = (pollDetails['interests'] || [])
                        .map((interest) => {
                            return {
                                id: interest._id,
                                name: interest.name,
                                isUserInterest: userInterestNames.includes(interest.name)
                            };
                        })
                        .sort((a, b) => {
                            // Sort by isGroupMember with `true` values first
                            return a.isUserInterest === b.isUserInterest ? 0 : a.isUserInterest ? -1 : 1;
                        });
                    pollDetails.isAnswered = pollResponsesObj[pollDetails._id.toString()] > 0;
                    pollDetails.groups = groupDetails || [];
                    pollDetails.allowChangeMyMind = pollResponseHistory[pollDetails._id.toString()] < 2;
                    pollDetails.isSaved = bookmarkedPollObj[pollDetails._id.toString()];
                    pollDetails.commentCount = 0;
                    // pollDetails.voterImages = [
                    //     'https://www.shutterstock.com/image-photo/image-handsome-smiling-young-african-260nw-722913181.jpg',
                    //     'https://t4.ftcdn.net/jpg/02/32/98/33/360_F_232983351_z5CAl79bHkm6eMPSoG7FggQfsJLxiZjY.jpg',
                    //     'https://st2.depositphotos.com/4431055/7492/i/950/depositphotos_74925449-stock-photo-men-human-face-smiling.jpg'
                    // ];

                    return pollDetails;
                });

            // Calculate total results by removing the last 4 stages from the pipeline and adding a $count stage
            const countPipeline = pipeline.slice(0, -3); // Exclude $skip and $limit
            countPipeline.push({ $count: 'totalResults' });

            const totalResultsArray = await this.groupPollModel.aggregate(countPipeline).exec();
            const totalResults = totalResultsArray.length > 0 ? totalResultsArray[0].totalResults : 0;
            const totalPages = Math.ceil(totalResults / paginateOptions.limit);

            return {
                docs: paginatedPolls,
                page: paginateOptions.page,
                limit: paginateOptions.limit,
                totalPages,
                totalResults
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async deletePollFromGroup(groupId, pollId, userId, token) {
        try {
            // Validate ObjectId format
            if (!isValidObjectId(groupId)) {
                throw new BadRequestException(globalErrorObj('Group id is invalid', 'groupId', 'string.base'));
            }
            // Validate ObjectId format
            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.base'));
            }

            console.log('1');

            const group = await this.groupModel.findOne({
                _id: groupId,
                isDeleted: false,
                isActive: true
            });
            if (!group) {
                throw new NotFoundException('Group not found');
            }

            console.log('2');

            const poll = await this.groupPollModel.findOne({
                groupId,
                pollId,
                isDeleted: false
            });
            if (!poll) {
                throw new NotFoundException('Poll not found in group');
            }

            console.log('3');
            const groupAdmins = (group.admin || []).map((admin) => admin.toString());

            // Check if userId is in the admin array
            if (!groupAdmins.includes(userId)) {
                throw new UnprocessableEntityException('You are not authorized to delete this poll from the group');
            }

            // Delete the poll from the group
            await this.groupPollModel.findOneAndUpdate({ groupId, pollId }, { isDeleted: true }, { new: true });

            // If poll is live then we need to remove response of those group members who voted on poll and part of this group
            // If poll is not live then we don't need to remove responses
            const pollData = await this.pollService.findPollById(pollId);
            console.log('4');
            if (pollData?.endDate > new Date()) {
                const payload = { eventType: EVENT_TYPE_DELETE_POLL_FROM_GROUP, groupId, pollId, token };
                console.log('payload', payload);
                await this.eventQueueService.addJobToQueue(
                    payload,
                    EVENT_TYPE_DELETE_POLL_FROM_GROUP,
                    `${groupId}-${pollId}`
                );
            }
            return { success: true };
        } catch (error) {
            console.log('error from delete poll from group endpoint', error);
            throw new RpcException(error);
        }
    }
    async updateResponsesWhenPollRemovedFromGroup(groupId, pollId, userId, token) {
        try {
            // Validate ObjectId format
            if (!isValidObjectId(groupId)) {
                throw new BadRequestException(globalErrorObj('Group id is invalid', 'groupId', 'string.base'));
            }

            if (!isValidObjectId(pollId)) {
                throw new BadRequestException(globalErrorObj('Poll id is invalid', 'pollId', 'string.base'));
            }

            console.log('1.1');

            // remove votes of all group members who voted on poll
            const groupMembers = await this.groupMembersModel.find({ groupId, isActive: true, isDeleted: false });
            let memberIds = groupMembers.map((member) => member.userId);

            // If private poll remove from pvt group
            // check if pvt poll shared in other groups
            console.log('2.1');
            const poll = await this.pollModel.findById(pollId);
            let sharedPollWithUsersIds = [];
            if (poll?.visibility === VisibilityTypes.PRIVATE) {
                // get all individual users with whom poll is shared and those users were also part of private group
                const sharedPollWithUsers = await this.sharedPollWithUsersModel.find({
                    pollId,
                    sharedWith: { $in: memberIds }
                });
                console.log('3.1');

                sharedPollWithUsersIds = sharedPollWithUsers.map((sharedPoll) => sharedPoll.sharedWith.toString());

                // get all groups with whom poll is shared except current group
                const sharedGroupPolls = await this.groupPollModel.find({
                    pollId,
                    isDeleted: false,
                    groupId: { $ne: groupId }
                });

                const groupIds = sharedGroupPolls.map((groupPoll) => groupPoll.groupId);

                // get all members of group except current group
                const groupMembers = await this.groupMembersModel.find({
                    groupId: { $in: groupIds },
                    isActive: true,
                    isDeleted: false
                });

                console.log('4.1');

                const groupMemberIds = groupMembers.map((member) => member.userId.toString());

                // list of unique member ids with whom poll is shared except current group
                const uniqueMemberIds = Array.from(new Set([...sharedPollWithUsersIds, ...groupMemberIds]));

                // remove those individual user ids from group members id array
                memberIds = memberIds.filter((memberId) => !uniqueMemberIds.includes(memberId.toString()));
            } else if (poll?.visibility === VisibilityTypes.PUBLIC) {
                // get all individual users with whom poll is shared and those users were also part of public group
                const sharedPollWithUsers = await this.sharedPollWithUsersModel.find({
                    pollId,
                    sharedWith: { $in: memberIds }
                });

                console.log('5.1');

                sharedPollWithUsersIds = sharedPollWithUsers.map((sharedPoll) => sharedPoll.sharedWith.toString());
                // remove those individual user ids from group members id array
                memberIds = memberIds.filter((memberId) => !sharedPollWithUsersIds.includes(memberId.toString()));
            }

            // remove poll responses
            let pollResponsesToDelete = [];
            const pollResponses = await this.pollResponseModel.find({
                pollId,
                userId: { $in: memberIds }
            });
            console.log('6.1');
            // TODO: remove poll response history as well - DONE
            await this.pollResponseHistoryModel.updateMany(
                {
                    pollId,
                    userId: { $in: memberIds }
                },
                {
                    $set: { isDeleted: true }
                }
            );

            // TODO: verify with client
            // const sharedPollCount = await this.sharedPollModel.countDocuments({
            //     pollId,
            //     sharedWith: { $in: memberIds }
            // });

            await this.sharedPollModel.updateMany(
                {
                    pollId,
                    sharedWith: { $in: memberIds }
                },
                {
                    $set: { isDeleted: true }
                }
            );

            console.log('7.1');

            const sharedPollCount = await this.sharedPollModel.countDocuments({
                pollId,
                isDeleted: false
            });

            pollResponsesToDelete = pollResponses;
            // remove response from database
            const pollResponsesToDeleteIds = pollResponsesToDelete.map((response) => response._id);

            console.log('8.1');
            for (const pollResponse of pollResponsesToDelete) {
                await this.responseQueueService.addJobToQueue(
                    { ...pollResponse.toJSON(), removeResponse: true, token },
                    pollResponse.questionType,
                    pollId
                );
            }

            await this.pollResponseModel.deleteMany({ _id: { $in: pollResponsesToDeleteIds } });
            if (poll && poll?.visibility === VisibilityTypes.PRIVATE) {
                poll['sharedWithUsersCount'] = sharedPollCount;

                await poll.save();
            }

            return { success: true };
        } catch (error) {
            console.log('consumer error', error);
            throw new RpcException(error);
        }
    }
}
