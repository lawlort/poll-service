import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';
import * as mongoosePaginate from 'mongoose-aggregate-paginate-v2';
import { VisibilityTypes } from '../dto/createGroupSchema';
import { Interest } from 'src/interests/schemas/interest.schema';
import { User } from 'src/users/schemas/user.schema';
@Schema({ timestamps: true, versionKey: false })
export class Group {
    @Prop({ required: true, maxlength: 100 })
    name: string;

    @Prop()
    groupBio: string;

    @Prop({ type: String, required: true })
    groupType: string;

    @Prop({
        type: [mongooseSchema.Types.ObjectId],
        ref: Interest.name,
        default: undefined, // Ensure it's not initialized as an empty array
        required: function (this: Group) {
            return this.groupType === VisibilityTypes.PUBLIC;
        }
    })
    groupInterests: string[];

    @Prop({
        type: Boolean,
        default: function (this: Group) {
            // Default true if groupType is private, undefined if public
            return this.groupType === VisibilityTypes.PRIVATE ? true : undefined;
        },
        required: function (this: Group) {
            return this.groupType === VisibilityTypes.PUBLIC;
        }
    })
    allowMembersToPost: boolean;

    @Prop()
    groupPicUrl: string;

    @Prop({ type: [mongooseSchema.Types.ObjectId] })
    admin: string[];

    @Prop({ type: Boolean, default: true })
    isActive: boolean;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;

    @Prop({ type: mongooseSchema.Types.ObjectId, ref: User.name })
    createdBy: string; // Ensure it references User model

    @Prop({ type: mongooseSchema.Types.ObjectId })
    updatedBy: string;
}

const GroupSchema = SchemaFactory.createForClass(Group);

// Add pagination plugin
GroupSchema.plugin(mongoosePaginate);

// Add index and serialization settings as before
GroupSchema.index({ isActive: 1 });
GroupSchema.index({ isDeleted: 1 });
GroupSchema.index({ isActive: 1, isDeleted: 1 });
GroupSchema.index({ name: 'text' }); // Text index for search functionality

GroupSchema.set('toJSON', { getters: true, virtuals: true });

GroupSchema.method('toClient', function () {
    const obj: any = this.toObject();
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type GroupDocument = HydratedDocument<Group>;
export default GroupSchema;
