import { Controller, Body } from '@nestjs/common';
import { GroupsService } from './groups.service';
import { MessagePattern } from '@nestjs/microservices';
import {
    CMD_ADD_GROUP_ADMIN,
    CMD_CREATE_GROUP,
    CMD_DELETE_GROUP,
    CMD_DELETE_GROUP_THROUGH_CONSUMER,
    CMD_DELETE_POLL_FROM_GROUP,
    CMD_DELETE_POLL_FROM_GROUP_FROM_CONSUMER,
    CMD_GET_ALL_GROUPS,
    CMD_GET_GROUP_BY_ID,
    CMD_GET_POLLS_BY_GROUP_ID,
    CMD_GET_POLLS_BY_GROUP_ID_V2,
    CMD_UPDATE_GROUP
} from 'src/utils/constants/commands';

@Controller('groups')
export class GroupsController {
    constructor(private readonly groupsService: GroupsService) {}

    @MessagePattern({ cmd: CMD_CREATE_GROUP })
    async create(@Body() payload) {
        const groupData = payload?.body || {};
        const { userId = '' } = payload;
        return await this.groupsService.create(groupData, userId);
    }

    @MessagePattern({ cmd: CMD_DELETE_GROUP })
    async remove(@Body() payload) {
        const { id = '', userId = '', token = '' } = payload;
        return await this.groupsService.remove(id, userId, token);
    }
    @MessagePattern({ cmd: CMD_DELETE_GROUP_THROUGH_CONSUMER })
    async deleteGroupThroughConsumer(@Body() payload) {
        const { body: { groupId = '', userId = '', token = '' } = {}, currentUserId = '' } = payload;
        return await this.groupsService.deleteGroupThroughConsumer(groupId, userId, currentUserId, token);
    }

    @MessagePattern({ cmd: CMD_GET_GROUP_BY_ID })
    async findOne(@Body() payload) {
        const { id = '', userId = '' } = payload;
        return await this.groupsService.findOne(id, userId);
    }

    @MessagePattern({ cmd: CMD_UPDATE_GROUP })
    async update(@Body() payload) {
        const { id = '', body = {}, userId = '' } = payload;
        return await this.groupsService.update(id, body, userId);
    }

    @MessagePattern({ cmd: CMD_GET_ALL_GROUPS })
    async findAll(@Body() payload) {
        const {
            paginateOptions,
            search,
            createdByMe,
            userId,
            groupType,
            allowMembersToPost,
            matchInterests,
            pollInterests
        } = payload?.body || {};
        return await this.groupsService.findAll({
            paginateOptions,
            search,
            createdByMe,
            userId,
            groupType,
            allowMembersToPost,
            matchInterests,
            pollInterests
        });
    }

    @MessagePattern({ cmd: CMD_ADD_GROUP_ADMIN })
    async addAdmin(@Body() payload) {
        const { groupId, body: adminData } = payload;
        const { userId = '' } = payload;
        return await this.groupsService.addAdminToGroup(groupId, adminData, userId);
    }

    @MessagePattern({ cmd: CMD_GET_POLLS_BY_GROUP_ID })
    async findPolls(@Body() payload) {
        const { id = '', paginateOptions, query = {}, userId = '' } = payload;
        return await this.groupsService.findPolls(id, paginateOptions, query, userId);
    }

    @MessagePattern({ cmd: CMD_GET_POLLS_BY_GROUP_ID_V2 })
    async findPollsV2(@Body() payload) {
        const { id = '', paginateOptions, query = {}, userId = '' } = payload;
        return await this.groupsService.findPollsV2(id, paginateOptions, query, userId);
    }

    @MessagePattern({ cmd: CMD_DELETE_POLL_FROM_GROUP })
    async deletePollFromGroup(@Body() payload) {
        const { groupId = '', userId = '', pollId = '', token = '' } = payload;
        return await this.groupsService.deletePollFromGroup(groupId, pollId, userId, token);
    }

    @MessagePattern({ cmd: CMD_DELETE_POLL_FROM_GROUP_FROM_CONSUMER })
    async updateResponsesWhenPollRemovedFromGroup(@Body() payload) {
        const { userId = '', body: { pollId = '', groupId = '', token = '' } = {} } = payload;
        return await this.groupsService.updateResponsesWhenPollRemovedFromGroup(groupId, pollId, userId, token);
    }
}
