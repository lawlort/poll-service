import * as Joi from 'joi';
const objectIdRegex = /^[0-9a-fA-F]{24}$/;

export enum VisibilityTypes {
    PRIVATE = 'private',
    PUBLIC = 'public'
}

export const UpdateGroupSchema = Joi.object({
    name: Joi.string().required().max(100),
    groupBio: Joi.string().optional().max(256).allow(''),
    groupPicUrl: Joi.string().uri().optional().allow(''),

    // groupInterests is required if groupType is 'public', otherwise optional
    groupInterests: Joi.array().items(Joi.string().pattern(objectIdRegex)).when('groupType', {
        is: VisibilityTypes.PUBLIC,
        then: Joi.required(),
        otherwise: Joi.optional()
    }),

    allowMembersToPost: Joi.boolean()
}).options({ abortEarly: true });
