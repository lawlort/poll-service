import * as Joi from 'joi';

export const createGroupAdminSchema = Joi.object({
    adminIds: Joi.array().items(Joi.string()).required()
}).options({ abortEarly: true });
