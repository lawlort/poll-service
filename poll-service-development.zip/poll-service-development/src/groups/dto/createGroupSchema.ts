import * as Joi from 'joi';
const objectIdRegex = /^[0-9a-fA-F]{24}$/;

export enum VisibilityTypes {
    PRIVATE = 'private',
    PUBLIC = 'public'
}

export const CreateGroupSchema = Joi.object({
    name: Joi.string().required().min(3).max(30),
    groupBio: Joi.string().optional().max(200),
    groupPicUrl: Joi.string().uri().optional(),

    groupType: Joi.string()
        .valid(...Object.values(VisibilityTypes))
        .required(),

    // groupInterests is required if groupType is 'public', optional if 'private'
    groupInterests: Joi.array().items(Joi.string().pattern(objectIdRegex)).when('groupType', {
        is: VisibilityTypes.PUBLIC,
        then: Joi.required(),
        otherwise: Joi.optional()
    }),

    // allowMembersToPost is required if groupType is 'public', otherwise forbidden
    allowMembersToPost: Joi.boolean().when('groupType', {
        is: VisibilityTypes.PUBLIC,
        then: Joi.required(),
        otherwise: Joi.forbidden()
    }),

    memberIds: Joi.array().items(Joi.string().pattern(objectIdRegex)),
    isAllFollowers: Joi.boolean()
})
    // .xor('memberIds', 'isAllFollowers') // Ensures that either memberIds or isAllFollowers is required
    // .when(Joi.object({ isAllFollowers: Joi.boolean().valid(false) }).unknown(), {
    //     then: Joi.object({
    //         memberIds: Joi.array().min(1).required() // memberIds must be provided if isAllFollowers is false
    //     })
    // })
    .options({ abortEarly: true });
