import * as Joi from 'joi';

export const DeleteGroupSchema = Joi.object({
    id: Joi.string().required()
}).options({ abortEarly: true });
