import {
    BadRequestException,
    forwardRef,
    Inject,
    Injectable,
    NotFoundException,
    UnprocessableEntityException
} from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model, isValidObjectId } from 'mongoose';
import { User } from './schemas/user.schema';
import { UserInsight } from 'src/user-insights/schemas/userInsights.schema';
import { Gender } from 'src/genders/schemas/gender.schema';
import { v4 as uuidv4 } from 'uuid';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreateUserSchema } from './dto/createUserSchema';
import UpdateUserSchema from './dto/updateUserSchema';
import { globalErrorObj } from 'src/utils/common/globalErrorRes';
import * as Joi from 'joi';
import UsernameSchema from './dto/userNameSchema';
import { trimObjectValues } from 'src/utils/common/object';
import { GendersService } from 'src/genders/genders.service';
import { InterestsService } from 'src/interests/interests.service';
import { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';
import { calculateEstimatedBirthdate } from 'src/utils/common/date';
import {
    DefaultUserSettings,
    FollowRequestStatus,
    ProfileCompletionField,
    UNSET_VALUE
} from 'src/utils/constants/string';
import { USER_PERSONAL_DETAILS_FIELDS } from 'src/utils/constants/user';
import { Device } from 'src/devices/schemas/device.schema';
// import { Token } from 'src/tokens/schemas/token.schema';
// eslint-disable-next-line
const myCustomJoi = Joi.extend(require('joi-phone-number'));
import axios from 'axios';
import * as dotenv from 'dotenv';
import { PollResponsesService } from 'src/poll-responses/poll-responses.service';
import { UserSettings } from 'src/settings/schemas/user-settings.schema';
import { Poll, VisibilityTypes } from 'src/polls/schemas/poll.schema';
import { UsernameHistory } from 'src/username-history/schema/username-history.schema';
import { RedisService } from 'src/redis/redis.service';
import { Cron, CronExpression } from '@nestjs/schedule';
import { LocationsService } from 'src/locations/locations.service';
import { EVENT_TYPE_DELETE_ACCOUNT } from 'src/utils/constants/events';
import { EventQueuesService } from 'src/event-queues/event-queues.service';
import { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
import { FeedServiceV3 } from 'src/feed/v3/feed.service';
import { ResponseQueuesService } from 'src/response-queues/response-queues.service';
import { PollResponseHistory } from 'src/poll-response-history/schemas/poll-response-history.schema';
import { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import { Interest } from 'src/interests/schemas/interest.schema';
import { DeletedAccount } from 'src/deleted_accounts/schemas/deleted_account.schema';
import DeleteAccountSchema from './dto/deleteAccountSchema';
import { Location } from 'src/locations/schemas/location.schema';
import { BookmarkedPoll } from 'src/bookmarked-polls/schemas/bookmarked-poll.schema';
import { PollComment } from 'src/poll-comments/schemas/poll-comment.schema';
import { Group } from 'src/groups/schemas/group.schema';
import { ReportedUser } from 'src/reported-users/schemas/reported-user.schema';
import { GroupMember } from 'src/group-members/schemas/group-members.schema';

dotenv.config();

@Injectable()
export class UsersService {
    private Token: any;

    constructor(
        @InjectModel(User.name) private userModel: Model<User>,
        @InjectModel(UserInsight.name) private userInsightsModel: Model<UserInsight>,
        @InjectModel(Gender.name) private genderModel: Model<Gender>,
        @InjectModel(FollowRequest.name) private followRequestModel: Model<FollowRequest>,
        @InjectModel(UserSettings.name) private userSettingsModel: Model<UserSettings>,
        // @InjectModel(Token.name) private tokenModel: Model<Token>,
        @InjectModel(Device.name) private deviceModel: Model<Device>,
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        @InjectModel(PollResponse.name) private pollResponseModel: Model<PollResponse>,
        @InjectModel(UsernameHistory.name) private usernameHistoryModel: Model<UsernameHistory>,
        @InjectModel(PollResponseHistory.name) private pollResponseHistoryModel: Model<PollResponseHistory>,
        @InjectModel(SharedPoll.name) private sharedPollModel: Model<SharedPoll>,
        private gendersService: GendersService,
        private interstsService: InterestsService,
        @Inject(forwardRef(() => PollResponsesService)) private pollResponseService: PollResponsesService,
        private redisService: RedisService,
        private locationService: LocationsService,
        private eventQueueService: EventQueuesService,
        @Inject(forwardRef(() => FeedServiceV3)) private feedService: FeedServiceV3,
        private responseQueueService: ResponseQueuesService,
        @InjectModel(Interest.name) private interestModel: Model<Interest>,
        @InjectModel(DeletedAccount.name) private deletedAccountModel: Model<DeletedAccount>,
        @InjectModel(Location.name) private locationModel: Model<Location>,
        @InjectModel(BookmarkedPoll.name) private bookmarkedPollModel: Model<BookmarkedPoll>,
        @InjectModel(PollComment.name) private pollCommentModel: Model<PollComment>,
        @InjectModel(Group.name) private groupModel: Model<Group>,
        @InjectModel(ReportedUser.name) private reportedUserModel: Model<ReportedUser>,
        @InjectModel(GroupMember.name)
        private groupMemberModel: Model<GroupMember>
    ) {}

    async getUserForAuth(userId) {
        try {
            const user = await this.userModel.findById(userId).exec();
            return user;
        } catch (error) {
            return null;
        }
    }

    async saveUserInCache(userId) {
        const strUserId = userId?.toString() || '';
        if (strUserId) {
            const user: any = await this.userModel
                .findById(strUserId)
                .populate({ path: 'interests', select: '_id name' })
                .exec();

            if (user?.id) {
                const userObj = user.toClient();
                userObj.interests = (user.interests || []).map((interest) => {
                    return { id: interest._id, name: interest.name };
                });

                const cacheObj = {
                    data: userObj,
                    createdAt: new Date().toISOString()
                };

                this.redisService.setWithExpiry(`${strUserId}:user`, cacheObj, 60 * 60 * 24);
            }
        }
    }

    async updateUserInCache(userId) {
        try {
            if (!isValidObjectId(userId)) {
                throw new BadRequestException(globalErrorObj('Invalid user id', 'userId', 'string.base'));
            }

            const user: any = await this.userModel
                .findById(userId)
                .populate({ path: 'interests', select: '_id name' })
                .exec();

            if (!user?._id) {
                throw new NotFoundException(`User not found with user ID: ${userId}`);
            }

            const userObj = user.toClient();

            userObj.interests = (user.interests || []).map((interest) => {
                return { id: interest._id, name: interest.name };
            });

            this.saveUserInCache(userId);
            return userObj;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async getUserById(userId) {
        try {
            if (!isValidObjectId(userId)) {
                throw new BadRequestException(globalErrorObj('Invalid user id', 'userId', 'string.base'));
            }

            const userFromCache: any = await this.redisService.get(`${userId}:user`);

            if (userFromCache) {
                const { data } = JSON.parse(userFromCache);

                // const cacheAgeInMilliseconds = new Date().getTime() - new Date(createdAt).getTime();
                // const cacheAgeInMinutes = cacheAgeInMilliseconds / (1000 * 60);
                // if (cacheAgeInMinutes > 10) {
                //     this.saveUserInCache(userId);
                // }
                return data;
            }

            const user: any = await this.userModel
                .findById(userId)
                .populate({ path: 'interests', select: '_id name' })
                .exec();

            const userObj = user.toClient();

            userObj.interests = (user.interests || []).map((interest) => {
                return { id: interest._id, name: interest.name };
            });

            if (!user?._id || user?.isDeleted || !user?.isActive) {
                throw new NotFoundException(`User not found with user ID: ${userId}`);
            }
            this.saveUserInCache(userId);
            return userObj;
        } catch (error) {
            const errorMessage = error?.response?.details?.length ? error.response.details[0]?.message : error.message;

            // Re-throw the original error with context
            throw new RpcException({
                message: errorMessage || 'Error fetching user detail',
                stack: error.stack || '',
                response: error.response || ''
            });
        }
    }

    async updateUser(userId: string, updateUserData: any, currentUserId: string, token?: string) {
        try {
            const data = trimObjectValues(updateUserData);
            validateSchema(UpdateUserSchema, data);

            if (!isValidObjectId(userId)) {
                throw new BadRequestException(globalErrorObj('User id is invalid', 'userId', 'string.base'));
            }

            if (data?.username) {
                const res = await this.checkUsername(data.username, userId);
                if (!res?.isAvailable) {
                    throw new BadRequestException(
                        globalErrorObj('Username is already taken', 'username', 'string.base')
                    );
                }
            }

            if (data?.mobile && data?.countryCode) {
                const res = myCustomJoi
                    .string()
                    .phoneNumber({ format: 'international', strict: true })
                    .validate((data?.countryCode || '') + (data?.mobile || ''));
                if (res?.error?.details?.length && res.error.details[0]) {
                    throw new BadRequestException(
                        globalErrorObj('Invalid mobile with country code', 'moibleOrCountryCode', 'phoneNumber.invalid')
                    );
                }
            }

            const allGenders = await this.gendersService.findAll();
            const genders: string[] = allGenders.map((gender) => gender?.genderType || '');
            if (updateUserData?.gender && !genders.includes(updateUserData?.gender)) {
                throw new BadRequestException(
                    globalErrorObj(`Invalid gender "${updateUserData.gender}"`, 'gender', 'string.base')
                );
            }

            const allInterests = await this.interstsService.findAll();
            const interests: string[] = allInterests.map((interest) => (interest?.id || '').toString());
            if (updateUserData?.interests?.length) {
                for (const interest of updateUserData.interests) {
                    if (!interests.includes(interest)) {
                        throw new BadRequestException(
                            globalErrorObj(`Invalid interest "${interest}"`, 'interest', 'string.base')
                        );
                    }
                }
            }

            // convert email in lowercase
            if (data?.email) {
                data.email = data.email.toLowerCase();
            }

            if (userId.toString() !== currentUserId.toString()) {
                throw new UnprocessableEntityException('You are not authorized to update this user');
            }

            const userPersonalDetails: any = {};

            for (const field of USER_PERSONAL_DETAILS_FIELDS) {
                if (data.hasOwnProperty(field)) {
                    userPersonalDetails[field] = data[field];
                }
                delete data[field];
            }

            let updatedUserPrivateInfo: any = {};
            // if ((Object.values(userPersonalDetails) || []).length > 0) {
            try {
                // Fetch user data
                let user: any = {};
                try {
                    user = await this.getUserById(userId);
                } catch (error) {
                    throw new BadRequestException(error?.error?.message || 'Error fetching user detail');
                }
                if (user?.refUserId) {
                    const exisitingUser = await axios.get(
                        `${process.env.API_GATEWAY_BASEURL}/v1/users/personal-info/${user?.refUserId}`,
                        {
                            headers: {
                                authorization: token
                            }
                        }
                    );

                    if (exisitingUser?.data?.email === userPersonalDetails?.email) {
                        delete userPersonalDetails['email'];
                    }
                    if (
                        exisitingUser?.data?.mobile === userPersonalDetails?.mobile &&
                        exisitingUser?.data?.countryCode === userPersonalDetails?.countryCode
                    ) {
                        delete userPersonalDetails['mobile'];
                        delete userPersonalDetails['countryCode'];
                    }

                    const res = await axios.patch(
                        `${process.env.API_GATEWAY_BASEURL}/v1/users/personal-info/${user?.refUserId}`,
                        {
                            ...userPersonalDetails
                        },
                        {
                            headers: {
                                authorization: token
                            }
                        }
                    );

                    updatedUserPrivateInfo = res?.data || {};
                }
            } catch (error) {
                if (['Email already exists', 'Mobile number already exists'].includes(error?.response?.data?.message)) {
                    throw new UnprocessableEntityException(error?.response?.data?.message);
                }
                throw new BadRequestException(error?.response?.data?.message || 'Error updating user personal info');
            }
            // }

            // Calculate estimated birthdate
            // Fetch user data
            let user: any = {};
            try {
                user = await this.getUserById(userId);
            } catch (error) {
                throw new BadRequestException(error?.error?.message || 'Error fetching user detail');
            }

            if (data?.age && data?.age !== user?.age) {
                // calculate esitmate birhdate and set new one
                const estimatedBirthDate = calculateEstimatedBirthdate(data.age);
                data.estimatedBirthdate = estimatedBirthDate;
            }

            const updatedUser: any = await this.userModel.findByIdAndUpdate(userId, data, {
                new: true
            });

            await updatedUser.save();

            if (!updatedUser?._id) {
                throw new NotFoundException('User not found');
            }
            const res = updatedUser.toClient();
            delete res.refUserId;

            const result = { ...res, ...updatedUserPrivateInfo };

            // update poll responses when user updates the gender
            if (data?.gender && user?.gender !== data.gender) {
                const removedBearerToken = token.replace('Bearer ', '');
                this.pollResponseService.updateGenderOfPollResponses(userId, data.gender, removedBearerToken);
            }

            // if username is updated then update username in all polls as well
            if (user?.username && data?.username && user?.username !== data?.username) {
                this.pollModel
                    .updateMany({ createdByUserId: userId }, { createdByUsername: data.username }, { multi: true })
                    .exec();
            }

            // if profile pic is updated then update profile pic in all polls as well
            if (user?.profilePicUrl && data?.profilePicUrl && user?.profilePicUrl !== data?.profilePicUrl) {
                this.pollModel
                    .updateMany(
                        { createdByUserId: userId },
                        { createdByUserProfilePicUrl: data.profilePicUrl },
                        { multi: true }
                    )
                    .exec();
            }

            // manage username history
            if (data?.username && user?.username !== data?.username) {
                await this.usernameHistoryModel.create({
                    userId: userId,
                    username: data.username
                });
            }

            // Compute profileCompletionPercentage
            const profileCompletionFields = [
                ProfileCompletionField.USERNAME,
                ProfileCompletionField.FULL_NAME,
                ProfileCompletionField.AGE,
                ProfileCompletionField.MOBILE,
                ProfileCompletionField.EMAIL,
                ProfileCompletionField.PROFILE_PIC_URL,
                ProfileCompletionField.MY_BIO,
                ProfileCompletionField.GENDER,
                ProfileCompletionField.INTERESTS
            ];

            const combinedUser = { ...result };

            const completedFields = profileCompletionFields.filter((field) => {
                if (field === ProfileCompletionField.INTERESTS) {
                    // Ensure interests is an array with at least one item
                    return Array.isArray(combinedUser[field]) && combinedUser[field].length > 0;
                }
                // For other fields, check if they are truthy
                return combinedUser[field];
            });
            const profileCompletionPercentage = parseFloat(
                ((completedFields.length / profileCompletionFields.length) * 100).toFixed(2)
            );

            this.saveUserInCache(userId);
            // prepare feed
            axios.get(`${process.env.API_GATEWAY_BASEURL}/v1/users/prepare-feed`, {
                headers: {
                    authorization: token
                }
            });
            return { ...result, profileCompletionPercentage };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async createUser(createUserData: any, token: any, ip: string) {
        try {
            const data = trimObjectValues(createUserData);
            validateSchema(CreateUserSchema, data);

            if (data?.mobile && data?.countryCode) {
                const res = myCustomJoi
                    .string()
                    .phoneNumber({ format: 'international', strict: true })
                    .validate((data?.countryCode || '').trim() + (data?.mobile || '').trim());
                if (res?.error?.details?.length && res.error.details[0]) {
                    throw new BadRequestException(
                        globalErrorObj('Invalid mobile with country code', 'moibleOrCountryCode', 'phoneNumber.invalid')
                    );
                }
            }

            const userPersonalDetails = {};

            for (const field of USER_PERSONAL_DETAILS_FIELDS) {
                if (data[field]) {
                    userPersonalDetails[field] = data[field];
                }
                delete data[field];
            }

            let refUserId = '';
            let user: any = {};
            if ((Object.values(userPersonalDetails) || []).length > 0) {
                try {
                    const res: any = await axios.post(
                        `${process.env.API_GATEWAY_BASEURL}/v1/users/personal-info`,
                        {
                            ...userPersonalDetails
                        },
                        {
                            headers: {
                                authorization: token
                            }
                        }
                    );

                    // return user if user already exists
                    if (res?.data?.exists && res?.data?.user?.id) {
                        const user: any = await this.userModel.findOne({ refUserId: res.data.user.id });

                        const response = { ...user.toClient() };
                        for (const field of USER_PERSONAL_DETAILS_FIELDS) {
                            if (res.data.user[field]) {
                                response[field] = res.data.user[field];
                            }
                        }
                        delete response.refUserId;
                        user?._id && ip && this.locationService.saveUsersLocation(user._id, ip);
                        return { ...response, exists: true };
                    }

                    refUserId = res?.data?.user?.id || '';
                    user = res?.data?.user || {};
                } catch (error) {
                    throw new BadRequestException(
                        error?.response?.data?.message || 'Error creating user personal info'
                    );
                }
            }

            // Set default age to 18
            data.age = 18;

            // Calculate age
            if (data?.age) {
                // calculate esitmate birhdate and set new one
                const estimatedBirthDate = calculateEstimatedBirthdate(data.age);
                data.estimatedBirthdate = estimatedBirthDate;
            }
            // Genereate unique user id
            data.uniqueUserId = uuidv4();

            // set ref user id
            if (refUserId) {
                data.refUserId = refUserId;
            }

            const result: any = await this.userModel.create(data);

            // Create default settings for the user
            await this.createDefaultUserSettings(result._id);

            const userDetails = result.toClient();
            delete userDetails.refUserId;
            const response = { ...userDetails };
            for (const field of USER_PERSONAL_DETAILS_FIELDS) {
                if (user[field]) {
                    response[field] = user[field];
                }
            }

            result?._id && ip && this.locationService.saveUsersLocation(result._id, ip);
            this.saveUserInCache(result._id);

            return response;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    // Helper function to create default user settings
    private async createDefaultUserSettings(userId: string) {
        const defaultSettings = {
            userId,
            useAnonymously: DefaultUserSettings.USE_ANONYMOUSLY,
            emailNotification: DefaultUserSettings.EMAIL_NOTIFICATION,
            inAppNotification: DefaultUserSettings.IN_APP_NOTIFICATION,
            followNotification: DefaultUserSettings.FOLLOW_NOTIFICATION,
            likeNotification: DefaultUserSettings.LIKE_NOTIFICATION,
            commentNotification: DefaultUserSettings.COMMENT_NOTIFICATION,
            newPollNotification: DefaultUserSettings.NEW_POLL_NOTIFICATION,
            pollInsightsNotification: DefaultUserSettings.POLL_INSIGHTS_NOTIFICATION
        };

        return await this.userSettingsModel.create(defaultSettings);
    }

    async groupByAgeRange(): Promise<any> {
        const ageRanges = [];
        ageRanges.push({ min: 18, max: 20 });
        for (let i = 21; i <= 100; i += 5) {
            ageRanges.push({ min: i, max: i + 4 });
        }
        ageRanges.push({ min: 100, max: null });

        const totalUsers = await this.userModel.countDocuments();

        const aggregation = ageRanges.map(async (range) => {
            const pipeline = range.max
                ? [
                      {
                          $match: {
                              estimatedBirthdate: {
                                  $gte: new Date(new Date().setFullYear(new Date().getFullYear() - range.max)),
                                  $lte: new Date(new Date().setFullYear(new Date().getFullYear() - range.min))
                              }
                          }
                      },
                      {
                          $count: 'count'
                      }
                  ]
                : [
                      {
                          $match: {
                              estimatedBirthdate: {
                                  $lt: new Date(new Date().setFullYear(new Date().getFullYear() - range.min))
                              }
                          }
                      },
                      {
                          $count: 'count'
                      }
                  ];

            return this.userModel.aggregate(pipeline).then((result) => {
                const count = result[0]?.count || 0;
                return {
                    range: range.max ? `${range.min}-${range.max}` : `${range.min}+`,
                    count: count,
                    percentage: parseFloat((totalUsers > 0 ? (count / totalUsers) * 100 : 0).toFixed(2)),
                    min: range.min,
                    max: range.max
                };
            });
        });

        const results = await Promise.all(aggregation);

        return results;
    }

    async groupByGender(genders: string[]) {
        const totalUsers = await this.userModel.countDocuments({ gender: { $exists: true } });

        const genderCounts = await Promise.all(
            genders.map(async (gender) => {
                const count = await this.userModel.countDocuments({
                    gender
                });
                return {
                    gender,
                    count,
                    percentage: parseFloat(((count / totalUsers) * 100).toFixed(2))
                };
            })
        );

        return genderCounts;
    }

    adjustPercentages(percentages) {
        // Round each percentage and convert to an integer
        const roundedPercentages = percentages.map((e) => Math.round(e));
        // Calculate the sum of the rounded percentages
        const sum = roundedPercentages.reduce((a, b) => a + b, 0);

        // If the sum is not 100, adjust the highest percentage
        if (sum > 0 && sum !== 100) {
            const difference = 100 - sum;
            const maxIndex = roundedPercentages.indexOf(Math.max(...roundedPercentages));
            roundedPercentages[maxIndex] += difference;
        }

        return roundedPercentages;
    }

    async setAgeAndGenderWiseData() {
        try {
            const ageData = await this.groupByAgeRange();
            const genders = await this.genderModel.find().exec();
            const genderTypes = genders.map((gender) => gender.genderType);
            const genderData = await this.groupByGender(genderTypes);

            const agePercentages = ageData.map((age) => age?.percentage || 0);
            const genderPercentages = genderData.map((gender) => gender?.percentage || 0);

            const adjustedAgePercentages = this.adjustPercentages(agePercentages);
            const adjustedGenderPercentages = this.adjustPercentages(genderPercentages);

            ageData.forEach((age, index) => {
                age.percentage = adjustedAgePercentages[index];
            });

            genderData.forEach((gender, index) => {
                gender.percentage = adjustedGenderPercentages[index];
            });

            await this.userInsightsModel.deleteMany();
            await this.userInsightsModel.create({ ageData, genderData });
            return { ageData, genderData };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async getAgeAndGenderWiseData() {
        try {
            const data: any = await this.userInsightsModel.findOne().lean().exec();
            if (!data) {
                return await this.setAgeAndGenderWiseData();
            }
            // Remove unwanted fields from the data object
            delete data._id;
            delete data.createdAt;
            delete data.updatedAt;
            delete data.__v;

            return data;
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async checkUsername(username: string, userId: string) {
        try {
            validateSchema(UsernameSchema, { username });

            if (!username || username.trim().length === 0) {
                throw new BadRequestException(globalErrorObj('Username is required', 'userName', 'any.required'));
            }
            if (typeof username !== 'string' || username.trim() === '') {
                throw new BadRequestException(
                    globalErrorObj('Username is required', 'userName', 'string.pattern.base')
                );
            }

            // Fetch user data
            let user: any = {};
            try {
                user = await this.getUserById(userId);
            } catch (error) {
                throw new BadRequestException(error?.error?.message || 'Error fetching user detail');
            }

            if (user?.username === username) {
                return {
                    isAvailable: true
                };
            }

            const userInDB = await this.userModel.findOne({ username: username });

            if (userInDB?._id) {
                return {
                    isAvailable: false
                };
            }

            return {
                isAvailable: true
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async syncContacts(contactsData: any, userId?: string, currentUser?: any) {
        try {
            const currentUserMobile = currentUser?.mobile || '';
            const currentUserEmail = currentUser?.email || '';
            const userIds = contactsData.map((contact) => contact._id);
            const users = await this.userModel
                .find({ refUserId: { $in: userIds } })
                .select('username profilePicUrl interests refUserId')
                .populate({ path: 'interests', select: '_id name' })
                .exec();

            const newUserIds = users.map((user) => user._id);

            // Fetch follow requests sent by the user or received by the user
            const followRequests = await this.followRequestModel
                .find({ senderId: userId, receiverId: { $in: newUserIds }, isDeleted: false })
                .select('senderId receiverId status')
                .exec();

            const result = [];
            for (const contact of contactsData) {
                const user: any = users.find((u) => {
                    return (u?.refUserId || '').toString() === (contact?._id || '').toString();
                });

                delete contact?._id;

                if (user) {
                    const userObj = {
                        ...user.toObject(),
                        ...contact,
                        isFollowing: false,
                        followRequestSent: false,
                        isCurrentUser: false
                    };

                    // Check if the user is following the contact or if a follow request is sent
                    const followRequest = followRequests.find((req) => {
                        return req.senderId.toString() === userId && req.receiverId.toString() === user._id.toString();
                    });

                    if (followRequest) {
                        userObj.followRequestSent = followRequest.status === FollowRequestStatus.PENDING;
                        userObj.isFollowing = followRequest.status === FollowRequestStatus.ACCEPTED;
                    }

                    if (userObj?.mobile === currentUserMobile) {
                        userObj.isCurrentUser = true;
                    }

                    if (userObj?.email === currentUserEmail) {
                        userObj.isCurrentUser = true;
                    }

                    delete userObj.refUserId;
                    if (userObj?.interests) {
                        userObj.interests = userObj.interests.map((interest) => interest.name);
                    }
                    result.push(userObj);
                }
            }
            return result;
        } catch (error) {
            throw new RpcException(error);
        }
    }
    async getUserProfile(userId: string, currentUserId?: string, token?: string) {
        try {
            // Fetch user data
            let user: any = {};
            try {
                user = await this.getUserById(userId);
            } catch (error) {
                throw new BadRequestException(error?.error?.message || 'Error fetching user detail');
            }

            // if (userId.toString() !== currentUserId.toString()) {
            // throw new UnauthorizedException();
            // }

            const isCurrentUser = userId.toString() === currentUserId.toString();

            let userPersonalInfo = {};
            if (user?.refUserId) {
                try {
                    const res: any = await axios.get(
                        `${process.env.API_GATEWAY_BASEURL}/v1/users/personal-info/${user?.refUserId}`,
                        {
                            headers: {
                                authorization: token
                            }
                        }
                    );
                    userPersonalInfo = res?.data || {};
                } catch (error) {
                    throw new BadRequestException(
                        error?.response?.data?.message || 'Error creating user personal info'
                    );
                }
            }

            // Calculate followersCount
            const followersCount = await this.followRequestModel
                .countDocuments({ receiverId: userId, status: FollowRequestStatus.ACCEPTED, isDeleted: false })
                .exec();

            // Calculate followingCount
            const followingCount = await this.followRequestModel
                .countDocuments({ senderId: userId, status: FollowRequestStatus.ACCEPTED, isDeleted: false })
                .exec();

            // Calculate avgRespondents
            // const avgRespondents = await this.calculateAverageRespondents(userId);

            let followRequestSent = false;
            let isFollowing = false;

            if (userId.toString() !== currentUserId.toString()) {
                // Fetch follow requests between the current user and the profile user
                const followRequest = await this.followRequestModel
                    .findOne({ senderId: currentUserId, receiverId: userId, isDeleted: false })
                    .select('senderId receiverId status')
                    .exec();

                // Set flags for followRequestSent and isFollowing
                followRequestSent =
                    followRequest?.senderId?.toString() === currentUserId?.toString() &&
                    followRequest?.status === FollowRequestStatus.PENDING;
                isFollowing =
                    followRequest?.senderId?.toString() === currentUserId?.toString() &&
                    followRequest?.status === FollowRequestStatus.ACCEPTED;
            }

            // Compute profileCompletionPercentage
            const profileCompletionFields = [
                ProfileCompletionField.USERNAME,
                ProfileCompletionField.FULL_NAME,
                ProfileCompletionField.AGE,
                ProfileCompletionField.MOBILE,
                ProfileCompletionField.EMAIL,
                ProfileCompletionField.PROFILE_PIC_URL,
                ProfileCompletionField.MY_BIO,
                ProfileCompletionField.GENDER,
                ProfileCompletionField.INTERESTS
            ];

            const combinedUser = { ...user, ...userPersonalInfo };

            const completedFields = profileCompletionFields.filter((field) => {
                if (field === ProfileCompletionField.INTERESTS) {
                    // Ensure interests is an array with at least one item
                    return Array.isArray(combinedUser[field]) && combinedUser[field].length > 0;
                }
                // For other fields, check if they are truthy
                return combinedUser[field];
            });
            const profileCompletionPercentage = parseFloat(
                ((completedFields.length / profileCompletionFields.length) * 100).toFixed(2)
            );

            /* eslint-disable */
            const {
                id,
                createdAt,
                updatedAt,
                createdBy,
                updatedBy,
                lastSignedInAt,
                currentSignedInAt,
                authKey,
                role,
                avatar,
                referralCode,
                ...userData
            } = user;
            const {
                id: alisaId,
                createdAt: alisaCreatedAt,
                updatedAt: alisaUpdatedAt,
                ...userPersonalData
            }: any = userPersonalInfo;
            /* eslint-enable */

            // get user settings
            let updatedUserSettings: any = {};

            const userSettings = await this.userSettingsModel.findOne({ userId, isDeleted: false });
            if (isCurrentUser) {
                if (userSettings?._id) {
                    updatedUserSettings = userSettings.toObject();
                    delete updatedUserSettings._id;
                }
            }

            // Construct response object
            return {
                ...userPersonalData,
                ...userData,
                profileCompletionPercentage,
                followersCount,
                followingCount,
                isAnonymous: updatedUserSettings?.useAnonymously || false,
                avgRespondents: 0,
                ...(userId.toString() !== currentUserId.toString() && {
                    followRequestSent,
                    isFollowing
                }),
                ...(isCurrentUser && { settings: updatedUserSettings })
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    // async calculateAverageRespondents(userId: string) {

    //     return 0;
    // }

    async logoutUser(token: string, deviceId: string, userId: string) {
        try {
            // Delete the device
            const result = await this.deviceModel.deleteMany({ deviceId: deviceId, user: userId }).exec();
            if (result.deletedCount === 0) {
                throw new NotFoundException('No matching device found to delete.');
            }

            try {
                await axios.delete(`${process.env.API_GATEWAY_BASEURL}/v1/auth`, {
                    headers: {
                        authorization: `Bearer ${token}`
                    },
                    data: {
                        deviceId,
                        token,
                        userId
                    }
                });
            } catch (error) {
                throw new BadRequestException(error?.response?.data?.message || 'Error logging out user');
            }

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async getUserInterest(userId) {
        try {
            if (!isValidObjectId(userId)) {
                throw new BadRequestException(globalErrorObj('Invalid user id', 'userId', 'string.base'));
            }
            const user: any = await this.getUserById(userId);
            if (!user?.id) {
                throw new NotFoundException(`User not found with user ID: ${userId}`);
            }

            const allInterests = await this.interstsService.findAll();

            allInterests.forEach((interest) => {
                interest.id = interest.id.toString();
            });

            // Get the user's selected interests
            const selectedInterests = (user?.interests || []).map((interest) => interest.id.toString());

            const filteredSelectedInterests = allInterests.filter((interest) =>
                selectedInterests.includes((interest?.id || '').toString())
            );

            // Filter out the selected interests from the full list to get "other interests"
            const otherInterests = allInterests.filter(
                (interest) => !selectedInterests.includes((interest?.id).toString())
            );

            return {
                selectedInterests: filteredSelectedInterests,
                otherInterests: otherInterests
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT, {
        timeZone: 'UTC' // Ensure the cron job runs in UTC
    })
    async updateUsersAge() {
        try {
            const chunkSize = 1000; // Process 1000 users at a time (adjust based on system capacity)
            let skip = 0;
            let users = [];

            do {
                // Fetch users in chunks of chunkSize
                users = await this.userModel
                    .find({ estimatedBirthdate: { $exists: true } })
                    .skip(skip)
                    .limit(chunkSize)
                    .exec();

                if (users?.length > 0) {
                    // Process the users concurrently using Promise.all
                    await Promise.all(
                        users.map(async (user) => {
                            const oldUserAge = user?.age || 18;
                            const estimatedBirthdate = user?.estimatedBirthdate;
                            // calculate users age from estimated birthdate
                            if (estimatedBirthdate) {
                                const ageDifMs = Date.now() - new Date(estimatedBirthdate).getTime();
                                const ageDate = new Date(ageDifMs);
                                const age = Math.abs(ageDate.getUTCFullYear() - 1970);

                                // Update only the age field
                                if (user.age !== age) {
                                    await this.userModel.updateOne(
                                        { _id: user._id },
                                        { $set: { age: age || oldUserAge } }
                                    );
                                }
                            }
                        })
                    );
                }

                // Move to the next chunk of users
                skip += chunkSize;
            } while (users.length > 0); // Continue until no more users are found
        } catch (error) {
            // Throw an error if something goes wrong
            throw new RpcException(error);
        }
    }

    async prepareUserFeed(userId) {
        try {
            this.feedService.prepareUserFeed(userId);
            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async deleteUser(userId: string, currentUserId: string, token: string, deleteUserPayload) {
        try {
            // TODO: Save delete account reason
            validateSchema(DeleteAccountSchema, deleteUserPayload);

            console.log(token);
            if (!isValidObjectId(userId)) {
                throw new BadRequestException(globalErrorObj('Invalid user id', 'userId', 'string.base'));
            }

            if (userId.toString() !== currentUserId.toString()) {
                throw new UnprocessableEntityException('You are not authorized to delete this user');
            }

            //check user or poll or its comment or group is reported or not, if yes then do not allow to delete user
            const userReportCounts = await this.reportedUserModel.countDocuments({ userId }).exec();

            const userPollReportCounts = await this.pollModel
                .aggregate([
                    // Step 1: Match polls created by the specific user
                    {
                        $match: {
                            createdByUserId: mongoose.Types.ObjectId.createFromHexString(userId), // userId is the ID of the user to check
                            isDeleted: false
                        }
                    },
                    // Step 2: Join with ReportedPoll collection on pollId
                    {
                        $lookup: {
                            from: 'reported_polls',
                            localField: '_id',
                            foreignField: 'pollId',
                            as: 'reportedPolls'
                        }
                    },
                    // Step 3: Filter out polls that have not been reported
                    {
                        $match: {
                            'reportedPolls.0': { $exists: true } // Checks if at least one report exists
                        }
                    },
                    // Step 4: Count the number of reported polls
                    {
                        $count: 'reportedPollCount'
                    }
                ])
                .exec();

            // This will return the count of reported polls created by the user
            const hasReportedPolls = userPollReportCounts.length > 0 ? userPollReportCounts[0].reportedPollCount : 0;

            const reportedGroupsCount = await this.groupModel
                .aggregate([
                    // Step 1: Match groups created by the specific user
                    {
                        $match: {
                            createdBy: mongoose.Types.ObjectId.createFromHexString(userId), // userId is the ID of the user to check
                            isDeleted: false
                        }
                    },
                    // Step 2: Join with ReportedGroup collection on groupId
                    {
                        $lookup: {
                            from: 'reported_groups',
                            localField: '_id',
                            foreignField: 'groupId',
                            as: 'reportedGroups'
                        }
                    },
                    // Step 3: Filter out groups that have not been reported
                    {
                        $match: {
                            'reportedGroups.0': { $exists: true } // Checks if at least one report exists
                        }
                    },
                    // Step 4: Count the number of reported groups
                    {
                        $count: 'reportedGroupCount'
                    }
                ])
                .exec();

            // This will return the count of reported groups created by the user
            const hasReportedGroups = reportedGroupsCount.length > 0 ? reportedGroupsCount[0].reportedGroupCount : 0;

            console.log({ hasReportedGroups }, { hasReportedPolls }, { userReportCounts });

            if (userReportCounts + hasReportedPolls + hasReportedGroups > 0) {
                throw new UnprocessableEntityException(
                    'Account deletion is not allowed due to active reports on your account, polls, or groups you manage'
                );
            }

            // TODO: check for comment

            // Fetch user data
            const user = await this.userModel.findById(userId).exec();
            if (!user?._id) {
                throw new NotFoundException(`User not found with user ID: ${userId}`);
            }

            // // Delete the user's tokens
            // // await this.tokenModel.deleteMany({ userId: userId }).exec();

            // // Delete the user's devices
            await this.deviceModel.updateMany({ user: userId }, { isDeleted: true }).exec();

            // // Delete the user's location
            await this.locationModel.updateMany({ userId }, { isDeleted: true }).exec();

            // // Delete the user's follow requests
            await this.followRequestModel
                .updateMany({ $or: [{ senderId: userId }, { receiverId: userId }] }, { isDeleted: true })
                .exec();

            // // Delete the user's settings
            await this.userSettingsModel.updateMany({ userId }, { isDeleted: true, useAnonymously: true }).exec();

            // // Delete the user's username history
            await this.usernameHistoryModel.updateMany({ userId }, { isDeleted: true }).exec();

            // delete bookemarked poll
            await this.bookmarkedPollModel.updateMany({ userId }, { isDeleted: true }).exec();

            // TODO: Delete the user's from redis cache
            // this.redisService.delete(`${userId}:user`);

            // TODO: delete group memeber in consumer

            // remove user comments
            await this.pollCommentModel.updateMany({ commentBy: userId }, { isDeleted: true }).exec();

            await this.deletedAccountModel.create({ userId, reason: deleteUserPayload.reason });

            const eventPayload = {
                eventType: EVENT_TYPE_DELETE_ACCOUNT,
                userId,
                token
            };

            this.eventQueueService.addJobToQueue(eventPayload, EVENT_TYPE_DELETE_ACCOUNT, `${userId}:delete-account`);

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async deleteUserAccount(currentUserId: string, userId: string, token: string) {
        try {
            console.log('currentUserId', currentUserId);
            console.log('userId', userId);

            if (!isValidObjectId(userId)) {
                throw new BadRequestException(globalErrorObj('Invalid user id', 'userId', 'string.base'));
            }

            // get user responses
            // const userResponses = await this.pollResponseModel.find({ userId }).exec();

            // if active public poll -> remove response
            // if active private poll -> remove response
            // if poll ended -> answerAnonymous = true

            const currentDate = new Date();

            const responseStatus = await this.pollResponseModel.aggregate([
                // Match responses by the user ID
                { $match: { userId: mongoose.Types.ObjectId.createFromHexString(userId), isDeleted: false } },

                // Group by pollId and userId to get unique entries for each poll response per user
                {
                    $group: {
                        _id: { pollId: '$pollId', userId: '$userId' },
                        responseId: { $first: '$_id' },
                        questionId: { $first: '$questionId' },
                        answeredAt: { $first: '$createdAt' },
                        answerAnonymous: { $first: '$answerAnonymous' }
                    }
                },

                // Join with the polls collection to get poll details
                {
                    $lookup: {
                        from: 'polls',
                        localField: '_id.pollId',
                        foreignField: '_id',
                        as: 'poll'
                    }
                },

                // Unwind to get poll details from the array
                { $unwind: '$poll' },

                // Project necessary fields
                {
                    $project: {
                        pollId: '$_id.pollId',
                        responseId: '$responseId',
                        questionId: '$questionId',
                        answeredAt: '$answeredAt',
                        pollEndDate: '$poll.endDate',
                        isClosed: '$poll.isClosed',
                        pollVisibility: '$poll.visibility',
                        isAnonymousResponse: '$answerAnonymous'
                    }
                },

                // Add a field to categorize the poll based on the end date and isClosed
                {
                    $addFields: {
                        pollStatus: {
                            $cond: [
                                { $or: [{ $eq: ['$isClosed', true] }, { $lt: ['$pollEndDate', currentDate] }] },
                                'ended',
                                'live'
                            ]
                        }
                    }
                },

                // Group results by status
                {
                    $group: {
                        _id: '$pollStatus',
                        polls: {
                            $push: {
                                pollId: '$pollId',
                                responseId: '$responseId',
                                questionId: '$questionId',
                                answeredAt: '$answeredAt',
                                pollVisibility: '$pollVisibility',
                                isAnonymousResponse: '$isAnonymousResponse'
                            }
                        }
                    }
                }
            ]);

            // Process the response to split into live and ended polls
            const polls = responseStatus.reduce(
                (acc, statusGroup) => {
                    acc[statusGroup._id] = statusGroup.polls;
                    return acc;
                },
                { live: [], ended: [] }
            );

            console.log('polls live count:', polls.live.length);
            console.log('polls ended count:', polls.ended.length);

            // Collect poll IDs from the already available `ended` array
            const endedPollIds = polls.ended.map((poll) => poll.pollId);

            // Run updateMany to set `answerAnonymous` to `true` for responses in ended polls
            await this.pollResponseModel.updateMany(
                { pollId: { $in: endedPollIds } },
                { $set: { answerAnonymous: true } }
            );

            const livePollIds = polls.live.map((poll) => poll.pollId);
            const pollResponsesToDelete = await this.pollResponseModel
                .find({ pollId: { $in: livePollIds }, userId })
                .exec();

            // TODO: remove poll response history as well - DONE
            // remove poll response history
            await this.pollResponseHistoryModel.updateMany(
                {
                    userId,
                    pollId: { $in: livePollIds }
                },
                {
                    isDeleted: true
                }
            );

            // const sharedPollCount = await this.sharedPollModel.countDocuments({
            //     pollId: { $in: livePollIds },
            //     sharedWith: userId
            // });

            await this.sharedPollModel.updateMany(
                {
                    pollId: { $in: livePollIds },
                    sharedWith: userId
                },
                {
                    $set: { isDeleted: true }
                }
            );

            for (const pollResponse of pollResponsesToDelete) {
                await this.responseQueueService.addJobToQueue(
                    { ...pollResponse.toJSON(), removeResponse: true, token },
                    pollResponse?.questionType,
                    pollResponse?.pollId
                );
            }

            const pollResponsesToDeleteIds = pollResponsesToDelete.map((response) => response._id);
            await this.pollResponseModel.deleteMany({ _id: { $in: pollResponsesToDeleteIds } }).exec();

            const privatePolls = await this.pollModel
                .find({ _id: { $in: livePollIds }, visibility: VisibilityTypes.PRIVATE })
                .exec();

            // Create an array of promises for each save operation
            const updatePromises = privatePolls.map((poll) => {
                poll['sharedWithUsersCount'] = Math.max(0, poll['sharedWithUsersCount'] - 1);
                return poll.save(); // Save each poll and return the promise
            });

            // Execute all save operations in parallel
            await Promise.all(updatePromises);

            // TODO: remove user created group - DONE
            const groups = await this.groupModel.find({ createdBy: userId, isDeleted: false }).exec();
            for (const group of groups) {
                if (group?.admin?.length === 1 && group?.admin[0].toString() === userId) {
                    await axios.delete(`${process.env.API_GATEWAY_BASEURL}/v1/groups/${group._id}`, {
                        headers: {
                            authorization: `Bearer ${token}`
                        }
                    });
                }
            }

            // TODO: remove user created live poll - DONE
            const livePollsCreatedByUser = await this.pollModel
                .find({ createdByUserId: userId, isDeleted: false, isActive: true, endDate: { $gt: currentDate } })
                .exec();

            for (const livePoll of livePollsCreatedByUser) {
                await axios.delete(`${process.env.API_GATEWAY_BASEURL}/v1/polls/${livePoll._id}`, {
                    headers: {
                        authorization: `Bearer ${token}`
                    }
                });
            }

            // TODO: for ended poll set createByUsername to anonymous and set isAnonymous=true in poll
            await this.pollModel
                .updateMany(
                    { createdByUserId: userId, isDeleted: false, isActive: true, endDate: { $lt: currentDate } },
                    {
                        $set: { isAnonymous: true, createByUsername: 'Anonymous' }
                    }
                )
                .exec();

            // TODO: remove user token

            const user = await this.userModel.findById(userId);

            const userPersonalDetails = {
                fullName: '',
                mobile: UNSET_VALUE,
                email: UNSET_VALUE,
                countryCode: '',
                facebook: '',
                instagram: '',
                snapchat: '',
                spotify: '',
                website: ''
            };

            await axios.patch(
                `${process.env.API_GATEWAY_BASEURL}/v1/users/personal-info/${user?.refUserId}`,
                {
                    ...userPersonalDetails
                },
                {
                    headers: {
                        authorization: `Bearer ${token}`
                    }
                }
            );

            await this.userModel.updateOne({ _id: userId }, { $unset: { username: '', age: '' } }).exec();

            // Delete the user
            await this.userModel
                .findByIdAndUpdate(userId, {
                    isDeleted: true,
                    isActive: false,
                    gender: '',
                    myBio: '',
                    profilePicUrl: ''
                })
                .exec();

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async getAllUsers({ paginateOptions, search, isAnonymous, searchBy, token, groupId }) {
        try {
            const pipeline: any[] = [];

            const matchConditions: any = {
                isActive: true,
                isDeleted: false
            };

            // Join the user_settings collection to access useAnonymously field
            pipeline.push({
                $lookup: {
                    from: 'user_settings',
                    localField: '_id',
                    foreignField: 'userId',
                    as: 'settings'
                }
            });

            // Unwind settings to make it a single object (assuming each user has exactly one settings document)
            pipeline.push({ $unwind: '$settings' });

            if (isAnonymous === 'true') {
                matchConditions['$or'] = [{ 'settings.useAnonymously': true }, { 'settings.useAnonymously': false }];
            } else {
                matchConditions['settings.useAnonymously'] = false;
            }

            if (search && searchBy === 'username') {
                matchConditions.username = { $regex: search, $options: 'i' };
            }

            matchConditions['isOnboarded'] = true;

            pipeline.push({ $match: matchConditions });

            // Sort usernames alphabetically in ascending order
            pipeline.push({ $sort: { username: 1 } });

            pipeline.push(
                { $skip: (paginateOptions.page - 1) * paginateOptions.limit },
                { $limit: paginateOptions.limit }
            );

            const results = await this.userModel.aggregate(pipeline).exec();
            let countPipeline = [{ $match: matchConditions }];
            countPipeline = pipeline.slice(0, -2); // Remove pagination stages
            const totalResults = await this.userModel.aggregate(countPipeline).count('totalCount');

            let formattedResults = await Promise.all(
                results.map(async (user) => {
                    let fullName = '';
                    try {
                        const res: any = await axios.get(
                            `${process.env.API_GATEWAY_BASEURL}/v1/users/personal-info/${user.refUserId}`,
                            { headers: { authorization: token } }
                        );
                        fullName = res?.data?.fullName || '';
                    } catch (error) {
                        throw new BadRequestException(
                            error?.response?.data?.message || 'Error fetching user personal info'
                        );
                    }

                    return {
                        userId: user._id,
                        username: user.username || '',
                        fullName: fullName || '',
                        profilePicUrl: user.profilePicUrl || '',
                        interests: user.interests || []
                    };
                })
            );

            const allInterests = await this.interestModel.find().exec();

            formattedResults.forEach((user: any) => {
                user.interests = user.interests.map((interestId) => {
                    const interest = allInterests.find((i) => i._id.toString() === interestId.toString());
                    return interest?.name || '';
                });
            });

            const userIds = formattedResults.map((user) => user.userId);

            if (groupId) {
                // Fetch group members for the users
                const groupMembers = await this.groupMemberModel
                    .find({ groupId, userId: { $in: userIds }, isDeleted: false, isActive: true })
                    .exec();

                // Create a set of userIds who are group members for easier lookup
                const groupMemberUserIds = new Set(groupMembers.map((member) => member.userId.toString()));

                // Add the `isGroupMember` flag to formatted results
                formattedResults = formattedResults.map((result) => ({
                    ...result,
                    isGroupMember: groupMemberUserIds.has(result.userId.toString()) // Check if user is in group
                }));
            }

            // Apply client-side filtering if `searchBy` is `fullName` or both fields
            const finalResults = formattedResults.filter((user) => {
                if (!search) return true;
                if (searchBy === 'fullName') {
                    return user.fullName.toLowerCase().includes(search.toLowerCase());
                }
                if (!searchBy) {
                    return (
                        user.username.toLowerCase().includes(search.toLowerCase()) ||
                        user.fullName.toLowerCase().includes(search.toLowerCase())
                    );
                }
                return true;
            });

            return {
                docs: finalResults,
                page: paginateOptions.page,
                limit: paginateOptions.limit,
                totalPages: Math.ceil(totalResults[0]?.totalCount / paginateOptions.limit) || 0,
                totalResults: totalResults[0]?.totalCount || 0
            };
        } catch (error) {
            console.log('error', error);
            throw new RpcException(error);
        }
    }

    async updateUserGender(userId: string, currentUserId: string, gender: string, token: string) {
        try {
            // get all poll responses and poll is live
            const currentDate = new Date();

            // Aggregation to fetch poll responses where the poll is still live
            const userLivePollResponses = await this.pollResponseModel
                .aggregate([
                    {
                        // Match responses by user ID
                        $match: { userId: mongoose.Types.ObjectId.createFromHexString(userId) }
                    },
                    {
                        // Lookup to join with the Poll collection to check if the poll is live
                        $lookup: {
                            from: 'polls', // Collection name for Poll
                            localField: 'pollId', // Field in poll_responses
                            foreignField: '_id', // Field in polls
                            as: 'pollDetails'
                        }
                    },
                    {
                        // Unwind the joined poll array to simplify filtering
                        $unwind: '$pollDetails'
                    },
                    {
                        // Filter only those poll responses where the poll is live
                        $match: {
                            'pollDetails.endDate': { $gt: currentDate },
                            'pollDetails.isDeleted': false,
                            'pollDetails.isActive': true
                        }
                    }
                ])
                .exec();

            for (const livePollResponse of userLivePollResponses) {
                gender &&
                    (await this.responseQueueService.addJobToQueue(
                        {
                            ...livePollResponse,
                            removeResponse: false,
                            token,
                            updateGender: true,
                            updatedGender: gender
                        },
                        livePollResponse?.questionType,
                        livePollResponse?.pollId
                    ));
            }
            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
