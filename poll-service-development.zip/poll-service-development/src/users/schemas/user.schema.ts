import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument, Schema as mongooseSchema, Types } from 'mongoose';
import { Interest } from 'src/interests/schemas/interest.schema';

export enum SignInMethods {
    SIGN_IN_WITH_OTP = 'Sign in with mobile',
    SIGN_IN_WITH_GOOGLE = 'Sign in with google',
    SIGN_IN_WITH_APPLE = 'Sign in with apple'
}

export enum OnboardedStatus {
    NOT_ONBOARDED = 'Not onboarded',
    PERSONAL_INFO_COMPLETED = 'Personal info completed',
    AGE_GENDER_COMPLETED = 'Age gender completed',
    INTEREST_COMPLETED = 'Interest completed',
    CONTACT_COMPLETED = 'Contact completed'
}

@Schema({ timestamps: true, versionKey: false })
export class User {
    @Prop({ maxlength: 250 })
    username: string;

    @Prop({ min: 18, max: 200 })
    age: number;

    @Prop()
    countryName: string;

    @Prop({ type: Boolean, default: false })
    isMobileVerified: boolean;

    @Prop({ type: Boolean, default: false })
    isEmailVerified: boolean;

    @Prop()
    profilePicUrl: string;

    @Prop()
    accountDeletedAt: Date;

    @Prop()
    myBio: string;

    @Prop()
    gender: string;

    @Prop()
    uniqueUserId: string;

    @Prop()
    inviteLink: string;

    @Prop({ enum: SignInMethods })
    signInMethod: string;

    @Prop({ type: Boolean })
    isAuthenticated: boolean;

    @Prop({ type: Boolean })
    isOnboarded: boolean;

    @Prop()
    estimatedBirthdate: Date;

    @Prop({ type: [Types.ObjectId], ref: Interest.name })
    interests: Types.ObjectId[];

    @Prop({ type: Boolean, default: true })
    isActive: boolean;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    createdBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    updatedBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    refUserId: string;

    @Prop({ default: OnboardedStatus.NOT_ONBOARDED })
    onBoardedStatus: string;

    @Prop({ type: Boolean })
    isAnonymous: boolean;
}

const UserSchema = SchemaFactory.createForClass(User);

UserSchema.index({ username: 1 }, { unique: true, sparse: true });
UserSchema.index({ fullName: 1 });
UserSchema.index({ mobile: 1 }, { unique: true, sparse: true });
UserSchema.index({ email: 1 }, { unique: true, sparse: true });
UserSchema.index({ uniqueUserId: 1 }, { unique: true, sparse: true });
UserSchema.index({ age: 1 });
UserSchema.index({ gender: 1 });
UserSchema.index({ isActive: 1 });
UserSchema.index({ isDeleted: 1 });
UserSchema.index({ accountDeletedAt: 1 });
UserSchema.index({ signInMethod: 1 });
UserSchema.index({ isOnboarded: 1 });
UserSchema.index({ isAuthenticated: 1 });
UserSchema.index({ isActive: 1, isDeleted: 1 });
UserSchema.index({ estimatedBirthdate: 1 });

UserSchema.set('toJSON', { getters: true, virtuals: true });

UserSchema.method('toClient', function () {
    const obj: any = this.toObject();

    //Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

UserSchema.pre('save', function (next) {
    if (this.interests && Array.isArray(this.interests)) {
        this.interests = this.interests.map((interest) => {
            return typeof interest === 'string' ? mongoose.Types.ObjectId.createFromHexString(interest) : interest;
        });
    }
    next();
});
export type UserDocument = HydratedDocument<User>;

export default UserSchema;
