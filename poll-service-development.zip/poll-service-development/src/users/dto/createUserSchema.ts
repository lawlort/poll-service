import * as Joi from 'joi';
import { SignInMethods } from '../schemas/user.schema';

export const CreateUserSchema = Joi.object({
    countryCode: Joi.string().max(10),
    countryName: Joi.string().max(50),
    signInMethod: Joi.string().valid(...Object.values(SignInMethods)),
    mobile: Joi.string()
        .regex(/^[0-9]{9,20}$/)
        .max(20),
    isMobileVerified: Joi.boolean(),
    isAuthenticated: Joi.boolean(),
    email: Joi.string().email().max(100),
    isEmailVerified: Joi.boolean()
})
    .and('email', 'isEmailVerified')
    .and('mobile', 'isMobileVerified', 'countryCode')
    .and('countryCode', 'mobile')
    .or('email', 'mobile')
    .options({ abortEarly: true });
