import * as Joi from 'joi';

const usernameRegex = /^(?=.*[a-z])[a-z0-9_]{3,30}$/;

const UsernameSchema = Joi.object({
    username: Joi.string()
        .optional()
        .regex(usernameRegex)
        .message(
            'Username must be alphanumeric, contain at least one letter, can contain underscores, and be between 3 and 30 characters'
        )
}).options({ abortEarly: true });

export default UsernameSchema;
