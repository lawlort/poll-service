import * as Joi from 'joi';
import { OnboardedStatus } from '../schemas/user.schema';
// Regex pattern for MongoDB ObjectId
const objectIdRegex = /^[0-9a-fA-F]{24}$/;

const usernameRegex = /^(?=.*[a-z])[a-z0-9_]{3,30}$/;

const UpdateUserSchema = Joi.object({
    username: Joi.string()
        .optional()
        .regex(usernameRegex)
        .message(
            'Username must be alphanumeric, contain at least one letter, can contain underscores, and be between 3 and 30 characters'
        ),
    fullName: Joi.string().optional().max(256).allow(''),
    myBio: Joi.string().optional().max(256).allow(''),
    email: Joi.string().email().optional().max(100),
    age: Joi.number().integer().min(18).max(100).optional(),
    gender: Joi.string().optional().max(100),
    interests: Joi.array().items(Joi.string().pattern(objectIdRegex)).optional(),
    profilePicUrl: Joi.string().uri().optional().allow(''),
    onBoardedStatus: Joi.string()
        .optional()
        .valid(...Object.values(OnboardedStatus)),
    countryCode: Joi.string().max(10).optional(),
    mobile: Joi.string()
        .regex(/^[0-9]{1,20}$/)
        .max(20)
        .optional(),
    isMobileVerified: Joi.boolean(),
    isEmailVerified: Joi.boolean(),
    isOnboarded: Joi.boolean(),
    isAnonymous: Joi.boolean(),
    facebook: Joi.string().uri().message('Please enter a valid Facebook URL').optional().allow(''),
    instagram: Joi.string().uri().message('Please enter a valid Instagram URL').optional().allow(''),
    snapchat: Joi.string().uri().message('Please enter a valid Snapchat URL').optional().allow(''),
    spotify: Joi.string().uri().message('Please enter a valid Spotify URL').optional().allow(''),
    website: Joi.string().uri().message('Please enter a valid Website URL').optional().allow('')
}).options({ abortEarly: true });

export default UpdateUserSchema;
