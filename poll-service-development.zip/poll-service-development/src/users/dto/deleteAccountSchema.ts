import * as Joi from 'joi';

const DeleteAccountSchema = Joi.object({
    reason: Joi.string().required()
}).options({ abortEarly: true });

export default DeleteAccountSchema;
