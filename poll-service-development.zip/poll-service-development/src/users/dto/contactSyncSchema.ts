import * as Joi from 'joi';

export const ContactSyncSchema = Joi.object({
    contacts: Joi.required()
}).options({ abortEarly: true });
