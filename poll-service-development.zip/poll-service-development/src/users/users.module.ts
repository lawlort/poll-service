import { forwardRef, Module } from '@nestjs/common';
import { UsersService } from './users.service';
import { UsersController } from './users.controller';
import { MongooseModule } from '@nestjs/mongoose';
import UserSchema, { User } from './schemas/user.schema';
import UserInsightsSchema, { UserInsight } from 'src/user-insights/schemas/userInsights.schema';
import GenderSchema, { Gender } from 'src/genders/schemas/gender.schema';
import { GendersModule } from 'src/genders/genders.module';
import { InterestsModule } from 'src/interests/interests.module';
import FollowRequestSchema, { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';
import DeviceSchema, { Device } from 'src/devices/schemas/device.schema';
import { PollResponsesModule } from 'src/poll-responses/poll-responses.module';
import UserSettingsSchema, { UserSettings } from 'src/settings/schemas/user-settings.schema';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';
import UsernameHistorySchema, { UsernameHistory } from 'src/username-history/schema/username-history.schema';
import { LocationsModule } from 'src/locations/locations.module';
import { EventQueuesModule } from 'src/event-queues/event-queues.module';
import PollResponseSchema, { PollResponse } from 'src/poll-responses/schema/poll-response.schema';
import { FeedModule } from 'src/feed/feed.module';
import InterestSchema, { Interest } from 'src/interests/schemas/interest.schema';
import { ResponseQueuesModule } from 'src/response-queues/response-queues.module';
import PollResponseHistorySchema, {
    PollResponseHistory
} from 'src/poll-response-history/schemas/poll-response-history.schema';
import SharedPollSchema, { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import DeletedAccountSchema, { DeletedAccount } from 'src/deleted_accounts/schemas/deleted_account.schema';
import LocationSchema, { Location } from 'src/locations/schemas/location.schema';
import BookmarkedPollSchema, { BookmarkedPoll } from 'src/bookmarked-polls/schemas/bookmarked-poll.schema';
import PollCommentSchema, { PollComment } from 'src/poll-comments/schemas/poll-comment.schema';
import GroupSchema, { Group } from 'src/groups/schemas/group.schema';
import ReportedUserSchema, { ReportedUser } from 'src/reported-users/schemas/reported-user.schema';
import GroupMemberSchema, { GroupMember } from 'src/group-members/schemas/group-members.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: User.name, schema: UserSchema },
            { name: UserInsight.name, schema: UserInsightsSchema },
            { name: Gender.name, schema: GenderSchema },
            { name: FollowRequest.name, schema: FollowRequestSchema },
            { name: Device.name, schema: DeviceSchema },
            { name: UserSettings.name, schema: UserSettingsSchema },
            { name: Poll.name, schema: PollSchema },
            { name: UsernameHistory.name, schema: UsernameHistorySchema },
            { name: Interest.name, schema: InterestSchema },
            { name: PollResponse.name, schema: PollResponseSchema },
            { name: PollResponseHistory.name, schema: PollResponseHistorySchema },
            { name: SharedPoll.name, schema: SharedPollSchema },
            { name: DeletedAccount.name, schema: DeletedAccountSchema },
            { name: Location.name, schema: LocationSchema },
            { name: BookmarkedPoll.name, schema: BookmarkedPollSchema },
            { name: PollComment.name, schema: PollCommentSchema },
            { name: Group.name, schema: GroupSchema },
            { name: ReportedUser.name, schema: ReportedUserSchema },
            { name: GroupMember.name, schema: GroupMemberSchema }
        ]),
        GendersModule,
        InterestsModule,
        forwardRef(() => PollResponsesModule),
        LocationsModule,
        EventQueuesModule,
        forwardRef(() => FeedModule),
        ResponseQueuesModule
    ],
    controllers: [UsersController],
    providers: [UsersService],
    exports: [UsersService]
})
export class UsersModule {}
