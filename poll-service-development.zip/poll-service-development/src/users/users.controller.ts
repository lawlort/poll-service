import { Controller, Body } from '@nestjs/common';
import { UsersService } from './users.service';
import { MessagePattern } from '@nestjs/microservices';
import {
    CMD_CREATE_USER,
    CMD_GET_APP_USERS_DATA,
    CMD_GET_USER_BY_ID,
    CMD_SET_AGE_AND_GENDER_WISE_DATA,
    CMD_UPDATE_USER,
    CMD_CHECK_USERNAME_AVAILABILITY,
    CMD_SYNC_CONTACTS,
    CMD_GET_USER_INFO_BY_ID,
    CMD_LOGOUT_USER,
    CMD_USER_INTERESTS,
    CMD_GET_USER_FOR_AUTH,
    CMD_UPDATE_USER_IN_CACHE,
    CMD_DELETE_USER,
    CMD_DELETE_USER_ACCOUNT,
    CMD_PREPARE_USER,
    CMD_GET_ALL_USERS,
    CMD_UPDATE_USER_GENDER
} from 'src/utils/constants/commands';

@Controller('users')
export class UsersController {
    constructor(private readonly usersService: UsersService) {}

    @MessagePattern({ cmd: CMD_GET_USER_FOR_AUTH })
    async getUserForAuth(@Body() payload) {
        const { id = '' } = payload;
        return await this.usersService.getUserForAuth(id);
    }

    @MessagePattern({ cmd: CMD_GET_USER_INFO_BY_ID })
    async getUserById(@Body() payload) {
        const { id = '' } = payload;
        return await this.usersService.getUserById(id);
    }

    @MessagePattern({ cmd: CMD_UPDATE_USER_IN_CACHE })
    async updateUserInCache(@Body() payload) {
        const { id = '' } = payload;
        return await this.usersService.updateUserInCache(id);
    }

    @MessagePattern({ cmd: CMD_GET_USER_BY_ID })
    async getUserProfile(@Body() payload) {
        const { id = '', userId = '', token = '' } = payload;
        return await this.usersService.getUserProfile(id, userId, token);
    }

    @MessagePattern({ cmd: CMD_UPDATE_USER })
    async updateUser(@Body() payload) {
        const { id = '', body = {}, userId = '', token = '' } = payload;
        return this.usersService.updateUser(id, body, userId, token);
    }

    @MessagePattern({ cmd: CMD_UPDATE_USER_GENDER })
    async updateUserGender(@Body() payload) {
        const { body: { userId = '', gender = '', token = '' } = {}, currentUserId = '' } = payload;
        return this.usersService.updateUserGender(userId, currentUserId, gender, token);
    }

    @MessagePattern({ cmd: CMD_SET_AGE_AND_GENDER_WISE_DATA })
    async setAgeAndGenderWiseData() {
        return this.usersService.setAgeAndGenderWiseData();
    }

    @MessagePattern({ cmd: CMD_CREATE_USER })
    async createUser(@Body() payload) {
        const { body = {}, token = '', ip } = payload;
        return this.usersService.createUser(body, token, ip);
    }

    @MessagePattern({ cmd: CMD_GET_APP_USERS_DATA })
    async getAgeAndGenderWiseData() {
        return this.usersService.getAgeAndGenderWiseData();
    }

    @MessagePattern({ cmd: CMD_CHECK_USERNAME_AVAILABILITY })
    async checkUsername(@Body() payload) {
        const { username = '', userId = '' } = payload;
        return await this.usersService.checkUsername(username, userId);
    }

    @MessagePattern({ cmd: CMD_SYNC_CONTACTS })
    async syncContacts(@Body() payload) {
        const contactData = payload?.body || {};
        const userId = payload?.userId;
        const user = payload?.user || {};
        return this.usersService.syncContacts(contactData, userId, user);
    }

    @MessagePattern({ cmd: CMD_LOGOUT_USER })
    async logout(@Body() payload) {
        const { token = '', deviceId = '', userId = '' } = payload;
        return this.usersService.logoutUser(token, deviceId, userId);
    }

    @MessagePattern({ cmd: CMD_USER_INTERESTS })
    async getUserInterests(@Body() payload) {
        const { userId = '' } = payload;
        return this.usersService.getUserInterest(userId);
    }

    @MessagePattern({ cmd: CMD_DELETE_USER })
    async deleteUser(@Body() payload) {
        const { currentUserId = '', id = '', token = '', body = {} } = payload;
        return this.usersService.deleteUser(currentUserId, id, token, body);
    }

    @MessagePattern({ cmd: CMD_DELETE_USER_ACCOUNT })
    async deleteUserAccount(@Body() payload) {
        const { currentUserId = '', body: { userId = '', token = '' } = {} } = payload;
        return this.usersService.deleteUserAccount(currentUserId, userId, token);
    }

    @MessagePattern({ cmd: CMD_PREPARE_USER })
    async getPrepareFeed(@Body() payload) {
        const { userId = '' } = payload;
        return this.usersService.prepareUserFeed(userId);
    }

    @MessagePattern({ cmd: CMD_GET_ALL_USERS })
    async getAllUsers(@Body() payload) {
        const { paginateOptions, search, isAnonymous, searchBy, token = '', groupId } = payload?.body || {};
        return await this.usersService.getAllUsers({
            paginateOptions,
            search,
            isAnonymous,
            searchBy,
            token,
            groupId
        });
    }
}
