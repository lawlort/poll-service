import { Controller } from '@nestjs/common';
import { GendersService } from './genders.service';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { CMD_GET_ALL_GENDERS } from 'src/utils/constants/commands';

@Controller('genders')
export class GendersController {
    constructor(private readonly gendersService: GendersService) {}

    @MessagePattern({ cmd: CMD_GET_ALL_GENDERS })
    async findAll(@Payload() payload: any) {
        const { search } = payload.body;
        return await this.gendersService.findAll(search);
    }
}
