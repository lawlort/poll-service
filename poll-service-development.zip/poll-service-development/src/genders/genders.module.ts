import { Module } from '@nestjs/common';
import { GendersService } from './genders.service';
import { GendersController } from './genders.controller';
import { MongooseModule } from '@nestjs/mongoose';
import GenderSchema, { Gender } from './schemas/gender.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: Gender.name, schema: GenderSchema }])],
    controllers: [GendersController],
    providers: [GendersService],
    exports: [GendersService]
})
export class GendersModule {}
