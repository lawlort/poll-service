import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Gender, GenderDocument } from './schemas/gender.schema';
import { RpcException } from '@nestjs/microservices';
import { Model } from 'mongoose';
import { removeFieldsFromArrayOfObjects } from 'src/utils/common/mongoose/removeFields';

@Injectable()
export class GendersService {
    constructor(
        @InjectModel(Gender.name)
        private genderModel: Model<GenderDocument>
    ) {}

    async findAll(searchTerm?: string) {
        try {
            // Define the initial aggregation pipeline with a $match stage
            const pipeline: any[] = [
                { $match: { isDeleted: false, isActive: true } },
                {
                    $project: {
                        genderType: 1, // include only the name field
                        _id: 1 // exclude the _id field if not needed
                    }
                }
            ];

            // Add a $match stage to filter by genderType if searchTerm is provided
            if (searchTerm) {
                pipeline.push({ $match: { genderType: searchTerm } });
            }

            // Execute the aggregation pipeline
            const aggregate = this.genderModel.aggregate(pipeline);
            const result = await aggregate.exec();

            // Transform the response to the desired format

            return removeFieldsFromArrayOfObjects(result, []);
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
