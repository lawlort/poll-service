import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, versionKey: false })
export class Gender {
    @Prop({ required: true })
    genderType: string;

    @Prop({ type: Boolean, default: true })
    isActive: boolean;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    createdBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    updatedBy: string;
}

const GenderSchema = SchemaFactory.createForClass(Gender);

GenderSchema.index({ genderType: 1 }, { unique: true });

export type GenderDocument = HydratedDocument<Gender>;

export default GenderSchema;
