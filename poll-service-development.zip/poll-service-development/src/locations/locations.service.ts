import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import axios from 'axios';
import * as dotenv from 'dotenv';
import { Location, LocationEventType } from './schemas/location.schema';
import { Model } from 'mongoose';
dotenv.config();

@Injectable()
export class LocationsService {
    constructor(@InjectModel(Location.name) private locationModel: Model<Location>) {}

    async getLocationDetails(ip) {
        try {
            if (ip) {
                const url = `${process.env.IP_API_BASEURL}/json/${ip}?key=${process.env.IP_API_KEY}`;
                const result = await axios.get(url);
                return result;
            } else {
                return {};
            }
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async create(createLocationPayload) {
        try {
            const result: any = await this.locationModel.create(createLocationPayload);
            return { id: result._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async saveUsersLocation(userId, ip) {
        try {
            let locationPayload: any = {};
            const locationDetails: any = await this.getLocationDetails(ip);
            if (!(locationDetails?.data?.status === 'fail')) {
                const locationData = locationDetails?.data || {};
                if (Object.keys(locationData).length) {
                    locationPayload = {
                        eventType: LocationEventType.USER_LOGIN,
                        userId,
                        ...locationData
                    };
                }
            }
            // add location table entry
            if (Object.keys(locationPayload).length) {
                await this.create(locationPayload);
            }
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
