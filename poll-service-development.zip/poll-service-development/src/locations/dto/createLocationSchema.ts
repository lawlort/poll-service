import * as Joi from 'joi';
import { LocationEventType } from '../schemas/location.schema';

export const locationJoiSchema = Joi.object({
    eventType: Joi.string()
        .valid(...Object.values(LocationEventType))
        .required(),
    pollId: Joi.string().optional(),
    userId: Joi.string().optional(),
    as: Joi.string().optional(),
    city: Joi.string().optional(),
    country: Joi.string().optional(),
    countryCode: Joi.string().optional(),
    isp: Joi.string().optional(),
    lat: Joi.number().optional(),
    lon: Joi.number().optional(),
    org: Joi.string().optional(),
    query: Joi.string().optional(),
    region: Joi.string().optional(),
    regionName: Joi.string().optional(),
    status: Joi.string().optional(),
    timezone: Joi.string().optional(),
    zip: Joi.string().optional()
});

export default locationJoiSchema;
