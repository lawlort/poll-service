import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

export enum LocationEventType {
    CREATE_POLL = 'create_poll',
    USER_LOGIN = 'user_login',
    POLL_RESPONSE = 'poll_response'
}

@Schema({ timestamps: true, versionKey: false })
export class Location {
    @Prop({ required: true, enum: Object.values(LocationEventType) })
    eventType: string;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    pollId: string;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    userId: string;

    @Prop()
    as: string;

    @Prop()
    city: string;

    @Prop()
    country: string;

    @Prop()
    countryCode: string;

    @Prop()
    isp: string;

    @Prop()
    lat: number;

    @Prop()
    lon: number;

    @Prop()
    org: string;

    @Prop()
    query: string;

    @Prop()
    region: string;

    @Prop()
    regionName: string;

    @Prop()
    status: string;

    @Prop()
    timezone: string;

    @Prop()
    zip: string;

    @Prop({ default: false })
    isDeleted: boolean;
}

const LocationSchema = SchemaFactory.createForClass(Location);

// LocationSchema.index({ name: 1 }, { unique: true });

LocationSchema.method('toClient', function () {
    const obj: any = this.toObject();

    //Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type LocationDocument = HydratedDocument<Location>;

export default LocationSchema;
