import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Interest } from './schemas/interest.schema';
import { RpcException } from '@nestjs/microservices';
import { Model } from 'mongoose';
import { User } from 'src/users/schemas/user.schema';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { UpdateInterestSchema } from './dto/updateInterestSchema';
import { removeFieldsFromArrayOfObjects } from 'src/utils/common/mongoose/removeFields';

@Injectable()
export class InterestsService {
    constructor(
        @InjectModel(Interest.name)
        private interestModel: Model<Interest>,
        @InjectModel(User.name)
        private usersModel: Model<User>
    ) {}

    async findAll(searchTerm?: string) {
        try {
            // Define the initial aggregation pipeline with a $match stage
            const pipeline: any[] = [
                { $match: { isActive: true } },
                { $match: { isDeleted: false } },
                {
                    $project: {
                        name: 1, // include only the name field
                        _id: 1 // exclude the _id field if not needed
                    }
                }
            ];

            // Add a $match stage to filter by interest if searchTerm is provided
            if (searchTerm) {
                pipeline.push({ $match: { name: searchTerm } });
            }

            // Execute the aggregation pipeline
            const aggregate = this.interestModel.aggregate(pipeline);
            const interests: any = await aggregate.exec();
            return removeFieldsFromArrayOfObjects(interests, []);
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async update(interestId: string, data: any) {
        try {
            validateSchema(UpdateInterestSchema, data);

            const interest = await this.interestModel.findById(interestId);

            const updatedInterest = await this.interestModel.findByIdAndUpdate(interestId, data, {
                new: true
            });
            if (!updatedInterest?._id) {
                throw new NotFoundException('Interest not found');
            }

            const oldInterestName = interest?.name;
            const newInterestName = updatedInterest?.name;

            if (oldInterestName !== newInterestName) {
                // await this.updateInterestWhereItIsUsed(oldInterestName, newInterestName);
            }

            return { id: updatedInterest?._id, name: updatedInterest?.name };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async updateInterestWhereItIsUsed(oldInterestName: string, newInterestName: string) {
        try {
            let hasMore = true;
            let page = 0;
            const batchSize = 1000;

            while (hasMore) {
                const users = await this.usersModel
                    .find({ interests: oldInterestName })
                    .skip(page * batchSize)
                    .limit(batchSize)
                    .exec();

                if (users.length === 0) {
                    hasMore = false;
                    continue;
                }

                const userIds = users.map((user) => user._id);

                await this.usersModel.updateMany(
                    { _id: { $in: userIds } },
                    {
                        $set: { 'interests.$[element]': newInterestName }
                    },
                    {
                        arrayFilters: [{ element: oldInterestName }]
                    }
                );
                page++;
            }
        } catch (error) {
            throw error;
        }
    }
}
