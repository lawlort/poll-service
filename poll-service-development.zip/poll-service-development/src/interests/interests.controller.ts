import { Body, Controller } from '@nestjs/common';
import { InterestsService } from './interests.service';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { CMD_GET_ALL_INTERESTS, CMD_UPDATE_INTEREST } from 'src/utils/constants/commands';

@Controller('interests')
export class InterestsController {
    constructor(private readonly interestsService: InterestsService) {}

    @MessagePattern({ cmd: CMD_GET_ALL_INTERESTS })
    async findAll(@Payload() payload: any) {
        const { search } = payload.body;

        return await this.interestsService.findAll(search);
    }

    @MessagePattern({ cmd: CMD_UPDATE_INTEREST })
    async update(@Body() payload) {
        const { id = '', body = {} } = payload;
        return await this.interestsService.update(id, body);
    }
}
