import { Module } from '@nestjs/common';
import { InterestsService } from './interests.service';
import { InterestsController } from './interests.controller';
import { MongooseModule } from '@nestjs/mongoose';
import InterestSchema, { Interest } from './schemas/interest.schema';
import UserSchema, { User } from 'src/users/schemas/user.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: Interest.name, schema: InterestSchema },
            { name: User.name, schema: UserSchema }
        ])
    ],
    controllers: [InterestsController],
    providers: [InterestsService],
    exports: [InterestsService]
})
export class InterestsModule {}
