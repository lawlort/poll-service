import * as Joi from 'joi';

export const UpdateInterestSchema = Joi.object({
    name: Joi.string().max(255)
}).options({ abortEarly: true });
