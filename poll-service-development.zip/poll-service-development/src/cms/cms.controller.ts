import { Controller, Body } from '@nestjs/common';
import { CmsService } from './cms.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_GET_CMS_BY_SLUG } from 'src/utils/constants/commands';

@Controller('cms')
export class CmsController {
    constructor(private readonly cmsService: CmsService) {}

    @MessagePattern({ cmd: CMD_GET_CMS_BY_SLUG })
    async findOne(@Body() payload) {
        const { slug = '' } = payload;
        return await this.cmsService.findOne(slug);
    }
}
