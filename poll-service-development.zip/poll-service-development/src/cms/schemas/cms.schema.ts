import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, versionKey: false })
export class Cms {
    @Prop({ required: true })
    key: string;

    @Prop({ required: true })
    slug: string;

    @Prop({ required: true })
    value: string;

    @Prop({ default: false })
    isDeleted: boolean;

    @Prop({ default: true })
    isActive: boolean;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    createdBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId })
    updatedBy: string;
}

const CmsSchema = SchemaFactory.createForClass(Cms);

CmsSchema.index({ key: 1 }, { unique: true });
CmsSchema.index({ slug: 1 }, { unique: true });

CmsSchema.set('toJSON', { getters: true, virtuals: true });

CmsSchema.method('toClient', function () {
    const obj: any = this.toObject();

    //Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type FollowDocument = HydratedDocument<Cms>;

export default CmsSchema;
