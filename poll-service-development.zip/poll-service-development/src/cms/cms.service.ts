import { Injectable, NotFoundException } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Cms } from './schemas/cms.schema';

@Injectable()
export class CmsService {
    constructor(
        @InjectModel(Cms.name)
        private cmsModel: Model<Cms>
    ) {}

    async findOne(slug: string) {
        try {
            const cms: any = await this.cmsModel.findOne({ slug, isDeleted: false, isActive: true });
            if (!cms) {
                throw new NotFoundException('Cms not found');
            }

            const transformedCms = cms.toClient();

            // Remove unwanted fields from the data object
            delete transformedCms.key;
            delete transformedCms.slug;
            delete transformedCms.isDeleted;

            return transformedCms;
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
