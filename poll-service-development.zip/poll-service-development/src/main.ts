import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Transport } from '@nestjs/microservices';
import * as dotenv from 'dotenv';
import { NewRelicMiddleware } from './midddlewares/newrelic.middleware';
dotenv.config();

// This is the port defined in API gateway to interact with poll service
const POLL_MICROSERVICE_TCP_PORT = Number(process.env.POLL_MICROSERVICE_TCP_PORT);
const POLL_MICROSERVICE_PORT = Number(process.env.POLL_MICROSERVICE_PORT || 7003);
async function bootstrap() {
    const app = await NestFactory.create(AppModule);

    app.connectMicroservice({
        transport: Transport.TCP,
        options: {
            host: process.env.POLL_SERVICE_HOST,
            port: POLL_MICROSERVICE_TCP_PORT
        }
    });
    app.use(new NewRelicMiddleware().use);
    await app.startAllMicroservices();
    await app.listen(POLL_MICROSERVICE_PORT);

    function logMemoryUsage() {
        const memoryUsage = process.memoryUsage();

        console.log('Memory Usage (in MB):');
        console.log(`RSS: ${(memoryUsage.rss / 1024 / 1024).toFixed(2)} MB`);
        console.log(`Heap Total: ${(memoryUsage.heapTotal / 1024 / 1024).toFixed(2)} MB`);
        console.log(`Heap Used: ${(memoryUsage.heapUsed / 1024 / 1024).toFixed(2)} MB`);
        console.log(`External: ${(memoryUsage.external / 1024 / 1024).toFixed(2)} MB`);
    }

    // setInterval(() => {
    logMemoryUsage();
    // }, 60000); // Log memory usage every 60 seconds
}
bootstrap();
