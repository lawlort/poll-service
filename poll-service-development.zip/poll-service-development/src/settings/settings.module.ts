// src/settings/settings.module.ts
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SettingsService } from './settings.service';
import { SettingsController } from './settings.controller';
import UserSettingsSchema, { UserSettings } from './schemas/user-settings.schema';
import { UsersModule } from 'src/users/users.module';

@Module({
    imports: [MongooseModule.forFeature([{ name: UserSettings.name, schema: UserSettingsSchema }]), UsersModule],
    controllers: [SettingsController],
    providers: [SettingsService]
})
export class SettingsModule {}
