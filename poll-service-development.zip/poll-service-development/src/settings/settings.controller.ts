import { Controller, Body } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_USER_SETTINGS } from 'src/utils/constants/commands';
import { SettingsService } from './settings.service';

@Controller('settings')
export class SettingsController {
    constructor(private readonly settingsService: SettingsService) {}

    @MessagePattern({ cmd: CMD_USER_SETTINGS })
    async updateSettings(@Body() body) {
        const { userId = '', payload = {} } = body;
        return this.settingsService.updateUserSettings(userId, payload);
    }
}
