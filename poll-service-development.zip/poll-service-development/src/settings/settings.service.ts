import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { RpcException } from '@nestjs/microservices';
import { UserSettings, UserSettingsDocument } from './schemas/user-settings.schema';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import UpdateSettingsSchema from './dto/updateSettingsSchema';
import { DefaultUserSettings } from 'src/utils/constants/string';
import { UsersService } from 'src/users/users.service';

@Injectable()
export class SettingsService {
    constructor(
        @InjectModel(UserSettings.name) private userSettingsModel: Model<UserSettingsDocument>,
        private userService: UsersService
    ) {}

    async updateUserSettings(userId: string, updateSettingsData: any) {
        try {
            try {
                await this.userService.getUserById(userId);
            } catch (error) {
                throw new BadRequestException(error?.error?.message || 'Error fetching user detail');
            }

            // Validate the input using Joi schema
            validateSchema(UpdateSettingsSchema, updateSettingsData);

            // Check if user settings already exist
            let existingSettings = await this.userSettingsModel.findOne({ userId, isDeleted: false });

            // If no settings exist, create a new record with default values
            if (!existingSettings) {
                const defaultSettings = {
                    userId,
                    useAnonymously: DefaultUserSettings.USE_ANONYMOUSLY,
                    emailNotification: DefaultUserSettings.EMAIL_NOTIFICATION,
                    inAppNotification: DefaultUserSettings.IN_APP_NOTIFICATION,
                    followNotification: DefaultUserSettings.FOLLOW_NOTIFICATION,
                    likeNotification: DefaultUserSettings.LIKE_NOTIFICATION,
                    commentNotification: DefaultUserSettings.COMMENT_NOTIFICATION,
                    newPollNotification: DefaultUserSettings.NEW_POLL_NOTIFICATION,
                    pollInsightsNotification: DefaultUserSettings.POLL_INSIGHTS_NOTIFICATION,
                    ...updateSettingsData // Merge any updates passed in request
                };

                existingSettings = new this.userSettingsModel(defaultSettings);
            } else {
                // Update the fields with the new data
                Object.assign(existingSettings, updateSettingsData);
            }

            // Save the settings (either newly created or updated)
            const transformedData = await existingSettings.save();
            return {
                userId: transformedData.userId,
                useAnonymously: transformedData.useAnonymously,
                emailNotification: transformedData.emailNotification,
                inAppNotification: transformedData.inAppNotification,
                followNotification: transformedData.followNotification,
                likeNotification: transformedData.likeNotification,
                commentNotification: transformedData.commentNotification,
                newPollNotification: transformedData.newPollNotification,
                pollInsightsNotification: transformedData.pollInsightsNotification
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
