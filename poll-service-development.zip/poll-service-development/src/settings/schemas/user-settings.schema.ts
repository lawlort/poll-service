// src/settings/schemas/user-settings.schema.ts
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, versionKey: false, collection: 'user_settings' })
export class UserSettings extends Document {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    userId: string;

    @Prop()
    useAnonymously: boolean;

    @Prop()
    emailNotification: boolean;

    @Prop()
    inAppNotification: boolean;

    @Prop()
    followNotification: boolean;

    @Prop()
    likeNotification: boolean;

    @Prop()
    commentNotification: boolean;

    @Prop()
    newPollNotification: boolean;

    @Prop()
    pollInsightsNotification: boolean;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;
}
export const UserSettingsSchema = SchemaFactory.createForClass(UserSettings);

UserSettingsSchema.set('toJSON', { getters: true, virtuals: true });

UserSettingsSchema.method('toClient', function () {
    const obj: any = this.toObject();

    //Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type UserSettingsDocument = HydratedDocument<UserSettings>;

export default UserSettingsSchema;
