import * as Joi from 'joi';

const UpdateSettingsSchema = Joi.object({
    useAnonymously: Joi.boolean().optional(),
    emailNotification: Joi.boolean().optional(),
    inAppNotification: Joi.boolean().optional(),
    followNotification: Joi.boolean().optional(),
    likeNotification: Joi.boolean().optional(),
    commentNotification: Joi.boolean().optional(),
    newPollNotification: Joi.boolean().optional(),
    pollInsightsNotification: Joi.boolean().optional()
}).options({ abortEarly: true });

export default UpdateSettingsSchema;
