import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { SQSClient, SendMessageCommand, SendMessageCommandInput } from '@aws-sdk/client-sqs'; // v3 SDK imports
import { QuestionTypes } from 'src/polls/schemas/poll.schema';
import * as dotenv from 'dotenv';
dotenv.config();
@Injectable()
export class ResponseQueuesService {
    private sqsClient: SQSClient;

    // Centralized queue URLs for each poll question type
    private queueUrls = {
        [QuestionTypes.THIS_THAT]: process.env.THIS_THAT_QUEUE_URL,
        [QuestionTypes.SINGLE_CHOICE]: process.env.SINGLE_CHOICE_QUEUE_URL,
        [QuestionTypes.SLIDER]: process.env.SLIDER_QUEUE_URL,
        [QuestionTypes.LIGHT_METER]: process.env.LIGHT_METER_QUEUE_URL,
        [QuestionTypes.MULTIPLE_CHOICE]: process.env.MULTIPLE_CHOICE_QUEUE_URL,
        [QuestionTypes.DATE]: process.env.DATE_QUEUE_URL,
        [QuestionTypes.RANKING]: process.env.RANKING_QUEUE_URL
    };

    constructor() {
        // Initialize a single SQSClient instance for reuse
        this.sqsClient = new SQSClient({
            region: process.env.RESPONSE_QUEUE_REGION,
            credentials: {
                accessKeyId: process.env.RESPONSE_QUEUE_ACCESS_KEY_ID,
                secretAccessKey: process.env.RESPONSE_QUEUE_SECRET_KEY
            }
        });
    }
    // Function to add a job to the appropriate queue based on the poll question type
    async addJobToQueue(payload: any, pollQuestionType: string, messageGroupId: string) {
        try {
            console.log('addJobToQueue:', payload, pollQuestionType, messageGroupId);
            const queueUrl = this.queueUrls[pollQuestionType];

            // Check if the poll question type has a corresponding queue URL
            if (!queueUrl) {
                throw new RpcException(`Invalid poll question type: ${pollQuestionType}`);
            }

            // Check if the queue is FIFO
            const isFifoQueue = queueUrl.endsWith('.fifo');

            // Build the parameters for the SQS message
            const params: SendMessageCommandInput = {
                QueueUrl: queueUrl,
                MessageBody: JSON.stringify({ ...payload, MessageGroupId: messageGroupId })
            };

            // If FIFO queue, add MessageGroupId and MessageDeduplicationId
            if (isFifoQueue) {
                params.MessageGroupId = messageGroupId;
                params.MessageDeduplicationId = new Date().getTime().toString(); // Unique deduplication ID
            }

            // console.log('Sending message to SQS:', params);

            // Send the message to SQS
            const command = new SendMessageCommand(params);
            const result = await this.sqsClient.send(command);

            console.log('Message sent successfully:', result);
            return { status: 'Message is being sent', result };
        } catch (error) {
            console.error('Error sending message to SQS:', error);
            throw new RpcException(error);
        }
    }
}
