import { Module } from '@nestjs/common';
import { ResponseQueuesService } from './response-queues.service';

@Module({
    providers: [ResponseQueuesService],
    exports: [ResponseQueuesService]
})
export class ResponseQueuesModule {}
