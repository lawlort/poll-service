import { Body, Controller } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import {
    CMD_CREATE_GROUP_MEMBER,
    CMD_GET_ALL_GROUP_MEMBERS,
    CMD_LEAVE_GROUP_MEMBERS,
    CMD_REMOVE_GROUP_MEMBERS
} from 'src/utils/constants/commands';
import { GroupMembersService } from './group-members.service';

@Controller('group-members')
export class GroupMembersController {
    constructor(private readonly groupMembersService: GroupMembersService) {}

    @MessagePattern({ cmd: CMD_REMOVE_GROUP_MEMBERS })
    async remove(@Body() payload) {
        const { groupId = '', userId = '', body = {}, token = '' } = payload;
        return await this.groupMembersService.removeGroupMembers(userId, groupId, body, token);
    }

    @MessagePattern({ cmd: CMD_CREATE_GROUP_MEMBER })
    async add(@Body() payload) {
        const { groupId = '', userId = '', body = {} } = payload;
        return await this.groupMembersService.addGroupMembers(userId, groupId, body);
    }

    @MessagePattern({ cmd: CMD_LEAVE_GROUP_MEMBERS })
    async leave(@Body() payload) {
        const { groupId = '', userId = '', token = '' } = payload;
        return await this.groupMembersService.leaveGroupMembers(userId, groupId, token);
    }

    @MessagePattern({ cmd: CMD_GET_ALL_GROUP_MEMBERS })
    async findAll(@Body() payload) {
        const { paginateOptions, search, userId, groupId } = payload?.body || {};
        return await this.groupMembersService.findAll({
            paginateOptions,
            search,
            userId,
            groupId
        });
    }
}
