import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ collection: 'group_members', timestamps: true })
export class GroupMember {
    @Prop({ required: true, type: mongooseSchema.Types.ObjectId })
    groupId: string;

    @Prop({ required: true, type: mongooseSchema.Types.ObjectId, ref: 'User' })
    userId: string;

    @Prop({ type: Boolean, default: true })
    isActive: boolean;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: false })
    createdBy?: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: false })
    updatedBy?: string;
}

const GroupMemberSchema = SchemaFactory.createForClass(GroupMember);

// Add indexes
GroupMemberSchema.index({ groupId: 1, userId: 1 });
GroupMemberSchema.index({ groupId: 1 });
GroupMemberSchema.index({ userId: 1 });

export type GroupMemberDocument = HydratedDocument<GroupMember>;

export default GroupMemberSchema;
