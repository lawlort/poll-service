import { Module } from '@nestjs/common';
import { GroupMembersController } from './group-members.controller';
import { GroupMembersService } from './group-members.service';
import { MongooseModule } from '@nestjs/mongoose';
import GroupMemberSchema, { GroupMember } from './schemas/group-members.schema';
import GroupSchema, { Group } from 'src/groups/schemas/group.schema';
import { FollowRequestsModule } from 'src/follow-requests/follow-requests.module';
import UserSchema, { User } from 'src/users/schemas/user.schema';
import { EventQueuesModule } from 'src/event-queues/event-queues.module';
import GroupPollSchema, { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';
import SharedPollSchema, { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import { FeedModule } from 'src/feed/feed.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: GroupMember.name, schema: GroupMemberSchema },
            { name: Group.name, schema: GroupSchema },
            { name: User.name, schema: UserSchema },
            { name: GroupPoll.name, schema: GroupPollSchema },
            { name: Poll.name, schema: PollSchema },
            { name: SharedPoll.name, schema: SharedPollSchema }
        ]),
        FollowRequestsModule,
        EventQueuesModule,
        FeedModule
    ],
    controllers: [GroupMembersController],
    providers: [GroupMembersService]
})
export class GroupMembersModule {}
