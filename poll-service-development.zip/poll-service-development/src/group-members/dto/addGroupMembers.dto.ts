import * as Joi from 'joi';

// Regular expression for a valid MongoDB ObjectId
const objectIdPattern = /^[0-9a-fA-F]{24}$/;

export const CreateGroupMemberSchema = Joi.object({
    memberIds: Joi.array().items(Joi.string().pattern(objectIdPattern).required()),
    isAllFollowers: Joi.boolean()
})
    .xor('memberIds', 'isAllFollowers') // Ensures that either memberIds or isAllFollowers is required
    .when(Joi.object({ isAllFollowers: Joi.boolean().valid(false) }).unknown(), {
        then: Joi.object({
            memberIds: Joi.array().min(1).required() // memberIds must be provided if isAllFollowers is false
        })
    })
    .options({ abortEarly: true });
