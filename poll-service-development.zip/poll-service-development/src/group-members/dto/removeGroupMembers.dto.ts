import * as Joi from 'joi';

// Regular expression for a valid MongoDB ObjectId
const objectIdPattern = /^[0-9a-fA-F]{24}$/;

export const DeleteGroupMemberSchema = Joi.object({
    memberIds: Joi.array().items(Joi.string().pattern(objectIdPattern).required()).required()
}).options({ abortEarly: true });
