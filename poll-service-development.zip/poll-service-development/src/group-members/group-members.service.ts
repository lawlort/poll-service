import { BadRequestException, Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { GroupMember } from './schemas/group-members.schema';
import mongoose, { isValidObjectId, Model } from 'mongoose';
import { CreateGroupMemberSchema } from './dto/addGroupMembers.dto';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { globalErrorObj } from 'src/utils/common/globalErrorRes';
import { RpcException } from '@nestjs/microservices';
import { Group } from 'src/groups/schemas/group.schema';
import { FollowRequestsService } from 'src/follow-requests/follow-requests.service';
import { DeleteGroupMemberSchema } from './dto/removeGroupMembers.dto';
import { User, UserDocument } from 'src/users/schemas/user.schema';
import { VisibilityTypes } from 'src/groups/dto/createGroupSchema';
import { EventQueuesService } from 'src/event-queues/event-queues.service';
import { EVENT_TYPE_REMOVE_USER_FROM_GROUP } from 'src/utils/constants/events';
import { GroupPoll } from 'src/group-polls/schemas/group-polls.schema';
import axios from 'axios';
import { FeedServiceV4 } from 'src/feed/v4/feed.service';
// import { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
// import { Poll } from 'src/polls/schemas/poll.schema';

@Injectable()
export class GroupMembersService {
    constructor(
        @InjectModel(GroupMember.name)
        private groupMembersModel: Model<GroupMember>,
        @InjectModel(Group.name) private groupModel: Model<Group>,
        @InjectModel(GroupPoll.name) private groupPollModel: Model<GroupPoll>,
        // @InjectModel(SharedPoll.name) private sharedPollModel: Model<SharedPoll>,
        // @InjectModel(Poll.name) private pollModel: Model<Poll>,
        private followRequestsService: FollowRequestsService,
        @InjectModel(User.name)
        private userModel: Model<UserDocument>,
        private eventQueueService: EventQueuesService,
        private feedServiceV4: FeedServiceV4
    ) {}

    async removeGroupMembers(userId: string, groupId: string, body: any, token: string) {
        try {
            if (!isValidObjectId(groupId)) {
                throw new BadRequestException(globalErrorObj('Group id is invalid', 'userId', 'string.base'));
            }

            const group = await this.groupModel.findById(groupId);
            if (!group?._id) {
                throw new NotFoundException('Group not found');
            }

            // Check if userId is in the admin array
            if (!(group?.admin || []).includes(userId)) {
                throw new UnprocessableEntityException('You are not authorized');
            }

            // Validate the request body
            const { memberIds = [] } = body;
            validateSchema(DeleteGroupMemberSchema, { memberIds });

            const invalidUserId = [];
            const selfRequest = [];
            const userNotFound = [];

            // Make memberIds unique
            const uniqueMemberIds = Array.from(new Set(memberIds.flatMap((id) => id.split(','))));

            // Validate and check for self-requests
            uniqueMemberIds.forEach((memberId) => {
                if (!isValidObjectId(memberId)) {
                    invalidUserId.push(memberId);
                } else if (userId.toString() === memberId.toString()) {
                    selfRequest.push(memberId);
                }
            });

            if (invalidUserId.length) {
                throw new BadRequestException(
                    globalErrorObj(`Invalid user id: [ ${invalidUserId.join(', ')} ]`, 'userId', 'string.base')
                );
            }
            if (selfRequest.length) {
                throw new BadRequestException(
                    globalErrorObj(`Cannot remove yourself in group`, 'memberId', 'string.base')
                );
            }

            // Check if users exist
            const userChecks = uniqueMemberIds.map(async (memberId) => {
                // do not use getUerById function because it will throw error if user is not present in database
                const user = await this.userModel.findById(memberId).exec();
                if (!user?._id) {
                    userNotFound.push(memberId);
                }
            });

            await Promise.all(userChecks);

            if (userNotFound.length) {
                throw new NotFoundException(`User not found with user ID: [ ${userNotFound.join(', ')} ]`);
            }

            // Delete the group members
            await this.groupMembersModel.updateMany(
                { groupId, userId: { $in: memberIds } },
                {
                    $set: {
                        isActive: false,
                        isDeleted: true,
                        updatedBy: userId
                    }
                }
            );

            for (const userId of memberIds) {
                // call event queue service to remove user responses
                const eventPayload = {
                    eventType: EVENT_TYPE_REMOVE_USER_FROM_GROUP,
                    groupId,
                    userId,
                    token
                };

                await this.eventQueueService.addJobToQueue(eventPayload, EVENT_TYPE_REMOVE_USER_FROM_GROUP, groupId);
                this.feedServiceV4.prepareUserFeed(userId);
            }
            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async addGroupMembers(userId, groupId, body) {
        try {
            validateSchema(CreateGroupMemberSchema, body);

            // Validate ObjectId format
            if (!isValidObjectId(groupId)) {
                throw new BadRequestException(globalErrorObj('Group id is invalid', 'groupId', 'string.base'));
            }

            // Fetch group details
            const group = await this.groupModel.findOne({
                _id: groupId,
                isDeleted: false,
                isActive: true
            });

            if (!group) {
                throw new NotFoundException('Group not found');
            }

            const invalidUserId = [];
            const userNotFound = [];
            const selfRequest = [];

            const { memberIds = [], isAllFollowers = false } = body;

            // Make memberIds unique
            const uniqueMemberIds = Array.from(new Set(memberIds.flatMap((id) => id.split(','))));

            // Validate and check for self-requests
            uniqueMemberIds.forEach((memberId) => {
                if (!isValidObjectId(memberId)) {
                    invalidUserId.push(memberId);
                } else if (group.groupType === VisibilityTypes.PRIVATE && userId.toString() === memberId.toString()) {
                    selfRequest.push(memberId);
                }
            });

            if (invalidUserId.length) {
                throw new BadRequestException(
                    globalErrorObj(`Invalid user id: [ ${invalidUserId.join(', ')} ]`, 'userId', 'string.base')
                );
            }
            if (selfRequest.length) {
                throw new BadRequestException(
                    globalErrorObj(
                        `Cannot add yourself in group: [ ${selfRequest.join(', ')} ]`,
                        'memberId',
                        'string.base'
                    )
                );
            }

            // Check if users exist
            const userChecks = uniqueMemberIds.map(async (memberId) => {
                // do not use getUerById function because it will throw error if user is not present in database
                const user = await this.userModel.findById(memberId).exec();
                if (!user?._id) {
                    userNotFound.push(memberId);
                }
            });

            await Promise.all(userChecks);

            if (userNotFound.length) {
                throw new NotFoundException(`User not found with user ID: [ ${userNotFound.join(', ')} ]`);
            }

            // Add all followers if isAllFollowers is true
            let membersToAdd = uniqueMemberIds;
            if (isAllFollowers) {
                const allFollowers = await this.followRequestsService.getAllFollowers(userId);
                membersToAdd = allFollowers.map((follower) => follower.userId);
            }

            // Check if any members are already in the group
            const existingMembers = await this.groupMembersModel
                .find({
                    groupId: groupId,
                    userId: { $in: membersToAdd },
                    isDeleted: false
                })
                .exec();

            if (existingMembers.length > 0) {
                const existingMemberIds = existingMembers.map((member) => member.userId.toString());
                throw new BadRequestException(
                    `Members with the following IDs are already in the group: ${existingMemberIds.join(', ')}`
                );
            }

            // Add members to the group
            const groupMembers = membersToAdd.map((memberId) => ({
                groupId: groupId,
                userId: memberId,
                createdBy: userId,
                updatedBy: userId
            }));

            // if group is public, allow anyone to join

            if (group.groupType === VisibilityTypes.PRIVATE) {
                // Check if logged/current user is admin of the group
                if (!(group?.admin || []).includes(userId)) {
                    throw new UnprocessableEntityException('You are not authorized');
                }
            }

            await this.groupMembersModel.insertMany(groupMembers);

            // check group is public or private
            // if private then check number of poll shared in group and are active
            // get users with whom poll is not shared ( check from poll creation shares table ) and udpate count of poll shared in group

            // let activePollIds = [];
            let activePolls = [];
            if (group.groupType === VisibilityTypes.PRIVATE) {
                const currentDate = new Date();

                activePolls = await this.groupPollModel.aggregate([
                    // Match the group by `groupId` and check if the `GroupPoll` document is not deleted
                    {
                        $match: {
                            groupId: mongoose.Types.ObjectId.createFromHexString(groupId),
                            isDeleted: false
                        }
                    },
                    // Join with the Poll collection to retrieve poll details
                    {
                        $lookup: {
                            from: 'polls', // Name of the Poll collection
                            localField: 'pollId',
                            foreignField: '_id',
                            as: 'pollDetails'
                        }
                    },
                    // Unwind to convert the pollDetails array into a single object
                    { $unwind: '$pollDetails' },
                    // Apply the poll filters: isDeleted, isActive, and endDate
                    {
                        $match: {
                            'pollDetails.isDeleted': false,
                            'pollDetails.isActive': true,
                            'pollDetails.endDate': { $gt: currentDate }
                        }
                    },
                    // Project fields as needed (optional)
                    {
                        $project: {
                            groupId: 1,
                            pollId: 1,
                            sharedBy: 1,
                            'pollDetails.endDate': 1,
                            'pollDetails.isActive': 1,
                            'pollDetails.isDeleted': 1,
                            'pollDetails.visibility': 1,
                            'pollDetails.createdByUserId': 1
                        }
                    }
                ]);
                console.log('activePolls', activePolls);
                // activePollIds = activePolls.map((poll) => poll.pollId);
            }

            // if (activePollIds?.length) {
            //     for (const memberId of membersToAdd) {
            //         for (const poll of activePolls)
            //             this.increasePollSharedCount(memberId.toString(), groupId, poll?.createdByUserId?.toString());
            //     }
            // }

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    // async increasePollSharedCount(userId: string, pollId: string, createdByUserId: string) {
    //     try {
    //         const isPollAlreadySharedWithUser = await this.sharedPollModel
    //             .find({ sharedWith: userId, pollId, isDeleted: false })
    //             .exec();

    //         if (isPollAlreadySharedWithUser.length) {
    //             return;
    //         } else {
    //             await this.sharedPollModel.create({
    //                 sharedWith: userId,
    //                 pollId,
    //                 sharedBy: createdByUserId
    //             });
    //             await this.pollModel.updateOne({ _id: pollId }, { $inc: { sharedWithUsersCount: 1 } });
    //         }
    //     } catch (error) {
    //         throw new RpcException(error);
    //     }
    // }

    async leaveGroupMembers(userId: string, groupId: string, token: string) {
        try {
            if (!isValidObjectId(groupId)) {
                throw new BadRequestException(globalErrorObj('Group id is invalid', 'groupId', 'string.base'));
            }

            const group = await this.groupModel.findOne({
                _id: groupId,
                isDeleted: false,
                isActive: true
            });
            if (!group) {
                throw new NotFoundException('Group not found');
            }

            // Check if userId is a member of the group
            const member = await this.groupMembersModel.findOne({ groupId, userId, isDeleted: false });
            if (!member) {
                throw new UnprocessableEntityException('User is not a member of the group.');
            }

            // Check if userId is in the admin array
            if ((group.admin || []).includes(userId)) {
                if (group?.admin?.length === 1) {
                    // If there's only one admin, don't allow them to leave
                    throw new BadRequestException(`Admin can't leave the group`);
                }

                // Remove userId from the admin array
                await this.groupModel.updateOne({ _id: groupId }, { $pull: { admin: userId } });
            }

            // Delete the group member
            await this.groupMembersModel.updateMany(
                { groupId, userId },
                {
                    $set: {
                        isActive: false,
                        isDeleted: true,
                        updatedBy: userId
                    }
                }
            );

            const eventPayload = {
                eventType: EVENT_TYPE_REMOVE_USER_FROM_GROUP,
                groupId,
                userId,
                token
            };

            this.eventQueueService.addJobToQueue(eventPayload, EVENT_TYPE_REMOVE_USER_FROM_GROUP, groupId);
            // prepare feed
            axios.get(`${process.env.API_GATEWAY_BASEURL}/v1/users/prepare-feed`, {
                headers: {
                    authorization: `Bearer ${token}`
                }
            });

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async findAll({
        paginateOptions,
        search,
        userId,
        groupId
    }: {
        paginateOptions: { page: number; limit: number; paginate: boolean };
        search?: string;
        userId: string;
        groupId: string;
    }): Promise<any> {
        try {
            if (!isValidObjectId(groupId)) {
                throw new BadRequestException(globalErrorObj('Group id is invalid', 'groupId', 'string.base'));
            }

            const group = await this.groupModel.findOne({
                _id: groupId,
                isDeleted: false,
                isActive: true
            });
            if (!group) {
                throw new NotFoundException('Group not found');
            }

            // Check if userId is a member of the group
            const member = await this.groupMembersModel.findOne({ groupId, userId, isDeleted: false });
            if (!member) {
                throw new UnprocessableEntityException('You are not a member of the group.');
            }

            const matchConditions: any = {
                isActive: true,
                isDeleted: false,
                groupId: groupId
            };

            // Create the query to find group members
            const query = this.groupMembersModel
                .find(matchConditions)
                .populate({
                    path: 'userId',
                    match: search
                        ? {
                              username: { $regex: search, $options: 'i' }
                          }
                        : {},
                    select: 'username profilePicUrl interests',
                    populate: {
                        path: 'interests', // Populate the interests field
                        select: 'name' // Specify fields to include from the interests model
                    }
                })
                .sort({ createdAt: -1 });

            if (paginateOptions.paginate) {
                const count = await query.clone().countDocuments();
                const results = await query
                    .skip((paginateOptions.page - 1) * paginateOptions.limit)
                    .limit(paginateOptions.limit)
                    .exec();

                // Manually transform data to include user details
                const transformedData = results
                    .filter((member: any) => member.userId)
                    .map((member: any) => ({
                        userId: member.userId._id.toString(),
                        username: member.userId.username,
                        profilePicUrl: member.userId.profilePicUrl,
                        interests: (member?.userId?.interests || []).map((interest) => interest.name)
                    }));

                return {
                    data: transformedData,
                    total: count,
                    limit: paginateOptions.limit,
                    page: paginateOptions.page,
                    totalPages: Math.ceil(count / paginateOptions.limit),
                    pagingCounter: (paginateOptions.page - 1) * paginateOptions.limit + 1,
                    hasPrevPage: paginateOptions.page > 1,
                    hasNextPage: paginateOptions.page * paginateOptions.limit < count,
                    prevPage: paginateOptions.page > 1 ? paginateOptions.page - 1 : null,
                    nextPage: paginateOptions.page * paginateOptions.limit < count ? paginateOptions.page + 1 : null
                };
            } else {
                const results = await query.exec();

                // Transform data without pagination
                const transformedData = results
                    .filter((member: any) => member.userId)
                    .map((member: any) => ({
                        userId: member.userId._id.toString(),
                        username: member.userId.username,
                        profilePicUrl: member.userId.profilePicUrl,
                        interests: member.userId.interests
                    }));

                return {
                    data: transformedData,
                    total: transformedData.length,
                    limit: transformedData.length,
                    page: 1,
                    totalPages: 1,
                    pagingCounter: 1,
                    hasPrevPage: false,
                    hasNextPage: false,
                    prevPage: null,
                    nextPage: null
                };
            }
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
