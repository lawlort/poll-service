import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { PollsModule } from './polls/polls.module';
import { MongooseModule } from '@nestjs/mongoose';
import * as dotenv from 'dotenv';
import { CmsModule } from './cms/cms.module';
import { DevicesModule } from './devices/devices.module';
import { FollowRequestsModule } from './follow-requests/follow-requests.module';
import { GendersModule } from './genders/genders.module';
import { InterestsModule } from './interests/interests.module';
import { UsersModule } from './users/users.module';
import { UserInsight } from './user-insights/schemas/userInsights.schema';
import { RedisModule } from './redis/redis.module';
import { GroupsModule } from './groups/groups.module';
import { FeedModule } from './feed/feed.module';
import { PollViewsModule } from './poll-views/poll-views.module';
import { PollResponsesModule } from './poll-responses/poll-responses.module';
import { PollRangeLabelsModule } from './poll-range-labels/poll-range-labels.module';
import { GroupMembersModule } from './group-members/group-members.module';
import { LocationsModule } from './locations/locations.module';
import { ReportCommentReasonsModule } from './report-comment-reasons/report-comment-reasons.module';
import { BookmarkedPollsModule } from './bookmarked-polls/bookmarked-polls.module';
import { ReportUserReasonsModule } from './report-user-reasons/report-user-reasons.module';
import { PollCommentsModule } from './poll-comments/poll-comments.module';
import { ReportedPollCommentsModule } from './reported-poll-comments/reported-poll-comments.module';
import { ReportedUsersModule } from './reported-users/reported-user.module';
import { ReportedPollsModule } from './reported-polls/reported-polls.module';
import { ReportPollReasonsModule } from './report-poll-reasons/report-poll-reasons.module';
import { PollInsightsModule } from './poll-insights/poll-insights.module';
import { ScheduleModule } from '@nestjs/schedule';
import { PollResponseHistoryModule } from './poll-response-history/poll-response-history.module';
import { MediaMappingModule } from './media-mapping/media-mapping.module';
import { SettingsModule } from './settings/settings.module';
import { UsernameHistoryModule } from './username-history/username-history.module';
import { ResponseQueuesModule } from './response-queues/response-queues.module';
import { GroupPollsModule } from './group-polls/group-polls.module';
import { SharedPollsModule } from './shared-polls/shared-polls.module';
import { SharedPollWithUsersModule } from './shared-poll-with-users/shared-poll-with-users.module';
import { ReportGroupReasonsModule } from './report-group-reasons/report-group-reasons.module';
import { ReportedGroupsModule } from './reported-groups/reported-groups.module';
import { EventQueuesModule } from './event-queues/event-queues.module';
import { DeleteAccountReasonsModule } from './delete-account-reasons/delete-account-reasons.module';
import { DeletedAccountsModule } from './deleted_accounts/deleted_accounts.module';

dotenv.config();

@Module({
    imports: [
        MongooseModule.forRoot(process.env.DOCUMENT_DB_CONNECTION_URL, {
            retryWrites: false
        }),
        PollsModule,
        CmsModule,
        DevicesModule,
        FollowRequestsModule,
        GendersModule,
        InterestsModule,
        UsersModule,
        UserInsight,
        RedisModule,
        GroupsModule,
        FeedModule,
        PollViewsModule,
        PollResponsesModule,
        PollRangeLabelsModule,
        GroupMembersModule,
        LocationsModule,
        ReportCommentReasonsModule,
        BookmarkedPollsModule,
        ReportUserReasonsModule,
        PollCommentsModule,
        ReportedPollCommentsModule,
        ReportedUsersModule,
        ReportedPollsModule,
        ReportPollReasonsModule,
        PollInsightsModule,
        ScheduleModule.forRoot(),
        PollResponseHistoryModule,
        MediaMappingModule,
        SettingsModule,
        UsernameHistoryModule,
        ResponseQueuesModule,
        GroupPollsModule,
        SharedPollsModule,
        SharedPollWithUsersModule,
        ReportGroupReasonsModule,
        ReportedGroupsModule,
        EventQueuesModule,
        DeleteAccountReasonsModule,
        DeletedAccountsModule
    ],
    controllers: [AppController],
    providers: [AppService]
})
export class AppModule {}
