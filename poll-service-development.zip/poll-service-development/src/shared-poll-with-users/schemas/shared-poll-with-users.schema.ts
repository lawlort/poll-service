import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';
import { Poll } from 'src/polls/schemas/poll.schema';
import { User } from 'src/users/schemas/user.schema';

@Schema({ timestamps: true, collection: 'shared_poll_with_users', versionKey: false })
export class SharedPollWithUsers {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true, ref: Poll.name })
    pollId: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true, ref: User.name })
    sharedBy: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true, ref: User.name })
    sharedWith: string;

    @Prop({ default: false })
    isDeleted: boolean;
}

export const SharedPollWithUsersSchema = SchemaFactory.createForClass(SharedPollWithUsers);

SharedPollWithUsersSchema.index({ sharedBy: 1, sharedWith: 1, pollId: 1 });
SharedPollWithUsersSchema.index({ sharedBy: 1 });
SharedPollWithUsersSchema.index({ pollId: 1 });
SharedPollWithUsersSchema.index({ sharedWith: 1 });

export type SharedPollWithUsersDocument = HydratedDocument<SharedPollWithUsers>;

export default SharedPollWithUsersSchema;
