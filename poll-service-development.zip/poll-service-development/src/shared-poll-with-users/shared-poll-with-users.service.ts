import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { SharedPollWithUsers } from './schemas/shared-poll-with-users.schema';
import { SharedPoll } from 'src/shared-polls/schemas/shared-polls.schema';
import { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';
import { Model } from 'mongoose';
import { FollowRequestStatus } from 'src/utils/constants/string';

@Injectable()
export class SharedPollWithUsersService {
    constructor(
        @InjectModel(SharedPollWithUsers.name) private sharedPollWithUsersModel: Model<SharedPoll>,
        @InjectModel(FollowRequest.name) private followRequestModel: Model<FollowRequest>
    ) {}

    async sharePollWithUsers(
        pollId: string,
        sharedBy: string,
        sharedWithUserIds: string[],
        shareWithAllFollowers: boolean = false
    ) {
        if (shareWithAllFollowers) {
            // Batch size to process followers
            const batchSize = 1000;

            // Fetch all followers for the user in one go
            const followers = await this.followRequestModel
                .find({ receiverId: sharedBy, status: FollowRequestStatus.ACCEPTED, isDeleted: false })
                .select('senderId') // Only fetch senderId to save bandwidth
                .exec();

            const userIds = followers.map((f) => f.senderId.toString());

            // Create shared poll entries in batches
            for (let i = 0; i < userIds.length; i += batchSize) {
                const batchUserIds = userIds.slice(i, i + batchSize);
                const sharedPolls = batchUserIds.map((userId) => ({
                    pollId,
                    sharedBy,
                    sharedWith: userId
                }));

                // Bulk insert shared poll entries
                await this.sharedPollWithUsersModel.insertMany(sharedPolls);
            }
        } else if (sharedWithUserIds?.length) {
            const sharedPolls = [];
            for (let i = 0; i < sharedWithUserIds.length; i++) {
                const sharedPoll = {
                    pollId,
                    sharedBy,
                    sharedWith: sharedWithUserIds[i]
                };
                sharedPolls.push(sharedPoll);
                await this.sharedPollWithUsersModel.insertMany(sharedPolls);
            }
        }
    }
}
