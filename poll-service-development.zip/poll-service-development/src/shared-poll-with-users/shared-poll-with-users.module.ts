import { Module } from '@nestjs/common';
import { SharedPollWithUsersService } from './shared-poll-with-users.service';
import { SharedPollWithUsersController } from './shared-poll-with-users.controller';
import { MongooseModule } from '@nestjs/mongoose';
import SharedPollWithUsersSchema, { SharedPollWithUsers } from './schemas/shared-poll-with-users.schema';
import FollowRequestSchema, { FollowRequest } from 'src/follow-requests/schemas/follow-request.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: SharedPollWithUsers.name, schema: SharedPollWithUsersSchema },
            { name: FollowRequest.name, schema: FollowRequestSchema }
        ])
    ],
    controllers: [SharedPollWithUsersController],
    providers: [SharedPollWithUsersService],
    exports: [SharedPollWithUsersService]
})
export class SharedPollWithUsersModule {}
