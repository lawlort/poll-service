import { Controller } from '@nestjs/common';
import { SharedPollWithUsersService } from './shared-poll-with-users.service';

@Controller('shared-poll-with-users')
export class SharedPollWithUsersController {
    constructor(private readonly sharedPollWithUsersService: SharedPollWithUsersService) {}
}
