import { Controller, Body } from '@nestjs/common';
import { ReportedPollCommentsService } from './reported-poll-comments.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_REPORT_POLL_COMMENT } from 'src/utils/constants/commands';

@Controller('reported-poll-comments')
export class ReportedPollCommentsController {
    constructor(private readonly reportedPollCommentsService: ReportedPollCommentsService) {}

    @MessagePattern({ cmd: CMD_REPORT_POLL_COMMENT })
    async create(@Body() payload) {
        const { body = {}, userId, pollId, commentId } = payload;
        return await this.reportedPollCommentsService.create(body, userId, pollId, commentId);
    }
}
