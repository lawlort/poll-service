import { Module } from '@nestjs/common';
import { ReportedPollCommentsService } from './reported-poll-comments.service';
import { ReportedPollCommentsController } from './reported-poll-comments.controller';
import { MongooseModule } from '@nestjs/mongoose';
import ReportedPollCommentSchema, { ReportedPollComment } from './schemas/reported-poll-comment.schema';
import PollCommentSchema, { PollComment } from 'src/poll-comments/schemas/poll-comment.schema';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';
import { PollsModule } from 'src/polls/polls.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: ReportedPollComment.name, schema: ReportedPollCommentSchema },
            { name: PollComment.name, schema: PollCommentSchema },
            { name: Poll.name, schema: PollSchema }
        ]),
        PollsModule
    ],
    controllers: [ReportedPollCommentsController],
    providers: [ReportedPollCommentsService]
})
export class ReportedPollCommentsModule {}
