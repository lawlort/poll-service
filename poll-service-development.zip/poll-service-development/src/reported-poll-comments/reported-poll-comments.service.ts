import { Injectable, NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ReportedPollComment } from './schemas/reported-poll-comment.schema';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreateReportedPollCommentJoiSchema } from './dto/CreateReportedPollCommentSchema';
import { PollComment } from 'src/poll-comments/schemas/poll-comment.schema';
import { Poll } from 'src/polls/schemas/poll.schema';
import { PollsService } from 'src/polls/polls.service';

@Injectable()
export class ReportedPollCommentsService {
    constructor(
        @InjectModel(ReportedPollComment.name) private reportedPollCommentModel: Model<ReportedPollComment>,
        @InjectModel(PollComment.name) private pollCommentModel: Model<PollComment>,
        @InjectModel(Poll.name) private pollModel: Model<Poll>,
        private pollService: PollsService
    ) {}

    async create(createReportedPollCommentDto, userId, pollId, commentId) {
        try {
            const payload = {
                ...createReportedPollCommentDto,
                reportedBy: userId,
                pollId,
                commentId
            };
            validateSchema(CreateReportedPollCommentJoiSchema, payload);

            const poll: any = await this.pollService.findPollById(pollId);

            if (!poll?._id || poll?.isDeleted) {
                throw new NotFoundException('Poll not found');
            }

            const pollComment = await this.pollCommentModel.findOne({ _id: commentId, isDeleted: false });

            if (!pollComment?._id) {
                throw new NotFoundException('Comment not found');
            }

            if ((pollComment?.pollId || '').toString() !== pollId) {
                throw new UnprocessableEntityException('Comment does not belong to this poll');
            }

            const existingReportedPollComment = await this.reportedPollCommentModel.findOne({
                pollId,
                commentId,
                reportedBy: userId,
                isDeleted: false
            });

            if (existingReportedPollComment?._id) {
                throw new UnprocessableEntityException('You have already reported this comment');
            }

            const createdReportedPollComment = await this.reportedPollCommentModel.create(payload);

            return { success: !!createdReportedPollComment?._id };
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
