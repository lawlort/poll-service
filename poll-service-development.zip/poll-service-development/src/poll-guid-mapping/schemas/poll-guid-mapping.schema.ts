import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'poll_guid_mapping', versionKey: false })
export class PollGuidMapping {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    pollId: string;

    @Prop({ type: String, required: true })
    pollGuid: string;

    @Prop({ default: false })
    isDeleted: boolean;
}

export const PollGuidMappingSchema = SchemaFactory.createForClass(PollGuidMapping);

PollGuidMappingSchema.index({ pollId: 1, pollGuid: 1 }); // Unique index to avoid duplicates

export type PollGuidMappingDocument = HydratedDocument<PollGuidMapping>;

export default PollGuidMappingSchema;
