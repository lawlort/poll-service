import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import PollGuidMappingSchema, { PollGuidMapping } from './schemas/poll-guid-mapping.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: PollGuidMapping.name, schema: PollGuidMappingSchema }])]
})
export class PollCommentsModule {}
