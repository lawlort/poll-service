// eslint-disable-next-line
const newrelic = require('newrelic');
import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class NewRelicMiddleware implements NestMiddleware {
    use(req: Request, res: Response, next: NextFunction) {
        const transactionName = `${req.method} ${req.url}`;
        console.log(
            `---------------------------------------------------------------------------------------------------------------------`
        );
        console.log(`${req.method} ${req.url}`);
        console.log(
            `---------------------------------------------------------------------------------------------------------------------`
        );
        newrelic.startWebTransaction(transactionName, () => {
            res.on('finish', () => {
                newrelic.endTransaction();
            });
            next();
        });
    }
}
