import { Controller, Body } from '@nestjs/common';
import { FollowRequestsService } from './follow-requests.service';
import { MessagePattern } from '@nestjs/microservices';
import {
    CMD_CREATE_FOLLOW_REQUEST,
    CMD_GET_ALL_FOLLOW_REQUESTS,
    CMD_GET_ALL_FOLLOWERS,
    CMD_GET_ALL_FOLLOWINGS,
    CMD_UNFOLLOW_USER,
    CMD_UPDATE_FOLLOW_REQUEST
} from 'src/utils/constants/commands';

@Controller({ path: 'follows', version: '1' })
export class FollowRequestsController {
    constructor(private readonly followRequestsService: FollowRequestsService) {}

    @MessagePattern({ cmd: CMD_CREATE_FOLLOW_REQUEST })
    async create(@Body() payload) {
        const { body = {}, userId = '' } = payload;

        return await this.followRequestsService.create(body, userId);
    }

    @MessagePattern({ cmd: CMD_UPDATE_FOLLOW_REQUEST })
    async updateStatusToAccept(@Body() payload) {
        const { requestId = '', body = {}, userId = '' } = payload;
        return await this.followRequestsService.update(requestId, body, userId);
    }

    @MessagePattern({ cmd: CMD_UPDATE_FOLLOW_REQUEST })
    async updateStatusToReject(@Body() payload) {
        const { requestId = '', body = {}, userId = '' } = payload;
        return await this.followRequestsService.update(requestId, body, userId);
    }

    @MessagePattern({ cmd: CMD_UNFOLLOW_USER })
    async delete(@Body() payload) {
        const { body = {}, userId = '' } = payload;
        return await this.followRequestsService.unfollow(body, userId);
    }

    @MessagePattern({ cmd: CMD_GET_ALL_FOLLOW_REQUESTS })
    async findAll(@Body() payload) {
        const { paginateOptions, userId } = payload?.body || {};
        return await this.followRequestsService.findAll({ paginateOptions, userId });
    }

    @MessagePattern({ cmd: CMD_GET_ALL_FOLLOWERS })
    async getFollowers(@Body() payload) {
        const { paginateOptions, userId, search, currentUserId, groupId } = payload?.body || {};
        return await this.followRequestsService.getFollowers({
            paginateOptions,
            userId,
            search,
            currentUserId,
            groupId
        });
    }

    @MessagePattern({ cmd: CMD_GET_ALL_FOLLOWINGS })
    async getFollowings(@Body() payload) {
        const { paginateOptions, userId, search, currentUserId } = payload?.body || {};
        return await this.followRequestsService.getFollowings({ paginateOptions, userId, search, currentUserId });
    }
}
