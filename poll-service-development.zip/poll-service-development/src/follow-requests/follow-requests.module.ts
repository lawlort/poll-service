import { Module } from '@nestjs/common';
import { FollowRequestsService } from './follow-requests.service';
import { FollowRequestsController } from './follow-requests.controller';
import { MongooseModule } from '@nestjs/mongoose';
import FollowRequestSchema, { FollowRequest } from './schemas/follow-request.schema';
import { UsersModule } from 'src/users/users.module';
import UserSchema, { User } from 'src/users/schemas/user.schema';
import InterestSchema, { Interest } from 'src/interests/schemas/interest.schema';
import GroupMemberSchema, { GroupMember } from 'src/group-members/schemas/group-members.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: FollowRequest.name, schema: FollowRequestSchema },
            { name: User.name, schema: UserSchema },
            { name: Interest.name, schema: InterestSchema },
            { name: GroupMember.name, schema: GroupMemberSchema }
        ]),
        UsersModule
    ],
    controllers: [FollowRequestsController],
    providers: [FollowRequestsService],
    exports: [FollowRequestsService]
})
export class FollowRequestsModule {}
