import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';
import { FollowRequestStatus } from 'src/utils/constants/string';
import * as mongoosePaginate from 'mongoose-aggregate-paginate-v2';
import { User } from 'src/users/schemas/user.schema';

@Schema({ timestamps: true, collection: 'follow_requests' })
export class FollowRequest {
    @Prop({ required: true, type: mongooseSchema.Types.ObjectId, ref: User.name })
    senderId: string;

    @Prop({ required: true, type: mongooseSchema.Types.ObjectId, ref: User.name })
    receiverId: string;

    @Prop({
        type: String,
        enum: Object.values(FollowRequestStatus),
        default: FollowRequestStatus.ACCEPTED
    })
    status: string;

    @Prop({ type: Boolean, default: false })
    notificationSent: boolean;

    @Prop({ type: Boolean, default: false })
    isDeleted: boolean;
}

const FollowRequestSchema = SchemaFactory.createForClass(FollowRequest);

FollowRequestSchema.index({ senderId: 1 });
FollowRequestSchema.index({ receiverId: 1 });
FollowRequestSchema.index({ senderId: 1, receiverId: 1 });
FollowRequestSchema.index({ senderId: 1, status: 1 });
FollowRequestSchema.index({ receiverId: 1, status: 1 });

// Define virtual field for sender details
FollowRequestSchema.virtual('sender', {
    ref: User.name, // The model to use
    localField: 'senderId', // Find sender by senderId
    foreignField: '_id', // The field in the User model to match senderId
    justOne: true // If you want to return a single document instead of an array
});

// Define virtual field for receiver details
FollowRequestSchema.virtual('receiver', {
    ref: User.name, // The model to use
    localField: 'receiverId', // Find receiver by receiverId
    foreignField: '_id', // The field in the User model to match receiverId
    justOne: true // If you want to return a single document instead of an array
});

// Add pagination plugin
FollowRequestSchema.plugin(mongoosePaginate);

FollowRequestSchema.set('toJSON', { getters: true, virtuals: true });

FollowRequestSchema.method('toClient', function () {
    const obj: any = this.toObject();

    //Rename fields
    obj.id = obj._id;
    delete obj._id;
    delete obj.__v;
    return obj;
});

export type FollowRequestDocument = HydratedDocument<FollowRequest>;

export default FollowRequestSchema;
