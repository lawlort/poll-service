import * as Joi from 'joi';

export const CreateFollowRequestSchema = Joi.object({
    receiverIds: Joi.array().items(Joi.string()).required()
}).options({ abortEarly: true });
