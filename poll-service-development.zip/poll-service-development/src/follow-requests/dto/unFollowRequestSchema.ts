import * as Joi from 'joi';

export const UnFollowRequestSchema = Joi.object({
    receiverId: Joi.string().required()
}).options({ abortEarly: true });
