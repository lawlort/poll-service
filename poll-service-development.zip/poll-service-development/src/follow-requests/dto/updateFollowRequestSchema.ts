import * as Joi from 'joi';
import { FollowRequestStatus } from '../../utils/constants/string';

export const UpdateFollowRequestSchema = Joi.object({
    status: Joi.string().valid(FollowRequestStatus.ACCEPTED, FollowRequestStatus.REJECTED).required()
}).options({ abortEarly: true });
