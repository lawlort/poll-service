import { Injectable, BadRequestException, UnprocessableEntityException, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { isValidObjectId, Model } from 'mongoose';
import { FollowRequest, FollowRequestDocument } from './schemas/follow-request.schema';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreateFollowRequestSchema } from './dto/createFollowRequestSchema';
import { UpdateFollowRequestSchema } from './dto/updateFollowRequestSchema';
import { RpcException } from '@nestjs/microservices';
import { UsersService } from 'src/users/users.service';
import { FollowRequestStatus } from 'src/utils/constants/string';
import { globalErrorObj } from 'src/utils/common/globalErrorRes';
import { UnFollowRequestSchema } from './dto/unFollowRequestSchema';
import { User, UserDocument } from 'src/users/schemas/user.schema';
import { Interest } from 'src/interests/schemas/interest.schema';
import { GroupMember } from 'src/group-members/schemas/group-members.schema';

@Injectable()
export class FollowRequestsService {
    constructor(
        @InjectModel(FollowRequest.name)
        private followRequestModel: Model<FollowRequestDocument>,
        @InjectModel(GroupMember.name)
        private groupMemberModel: Model<GroupMember>,
        private readonly usersService: UsersService,
        @InjectModel(User.name)
        private userModel: Model<UserDocument>,
        @InjectModel(Interest.name)
        private interestModel: Model<Interest>
    ) {}

    async create(followRequestData, currentUserId) {
        try {
            validateSchema(CreateFollowRequestSchema, followRequestData);

            const { receiverIds } = followRequestData;
            const invalidUserId = [];
            const userNotFound = [];
            const selfRequest = [];
            const pendingOrAcceptedRequest = [];

            // Make receiverIds unique
            const uniqueReceiverIds = Array.from(new Set(receiverIds.flatMap((id) => id.split(','))));

            // Validate and check for self-requests
            uniqueReceiverIds.forEach((receiverId) => {
                if (!isValidObjectId(receiverId)) {
                    invalidUserId.push(receiverId);
                } else if (currentUserId.toString() === receiverId.toString()) {
                    selfRequest.push(receiverId);
                }
            });

            if (invalidUserId.length) {
                throw new BadRequestException(
                    globalErrorObj(`Invalid user id: [ ${invalidUserId.join(', ')} ]`, 'userId', 'string.base')
                );
            }
            if (selfRequest.length) {
                throw new BadRequestException(
                    globalErrorObj(
                        `Cannot send a follow request to yourself: [ ${selfRequest.join(', ')} ]`,
                        'receiverId',
                        'string.base'
                    )
                );
            }

            // Check if users exist and if there are pending or accepted requests
            const userChecks = uniqueReceiverIds.map(async (receiverId) => {
                // do not use getUerById function because it will throw error if user is not present in database
                const user = await this.userModel.findById(receiverId).exec();
                if (!user?._id) {
                    userNotFound.push(receiverId);
                } else {
                    const existingRequest: any = await this.followRequestModel
                        .findOne({ senderId: currentUserId, receiverId, isDeleted: false })
                        .sort({ createdAt: -1 });

                    if (
                        existingRequest &&
                        [FollowRequestStatus.PENDING, FollowRequestStatus.ACCEPTED].includes(existingRequest.status)
                    ) {
                        pendingOrAcceptedRequest.push(receiverId);
                    }
                }
            });

            await Promise.all(userChecks);

            if (userNotFound.length) {
                throw new NotFoundException(`User not found with user ID: [ ${userNotFound.join(', ')} ]`);
            }

            if (pendingOrAcceptedRequest.length) {
                throw new BadRequestException(
                    globalErrorObj(
                        `Cannot send another follow request while an existing request is pending or accepted: [ ${pendingOrAcceptedRequest.join(', ')} ]`,
                        'request',
                        'string.base'
                    )
                );
            }

            // Create follow requests
            const followRequests = uniqueReceiverIds.map((receiverId) =>
                new this.followRequestModel({
                    senderId: currentUserId,
                    receiverId
                }).save()
            );

            const createdFollowRequests = await Promise.all(followRequests);

            return { id: createdFollowRequests.map((request) => request._id) };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async update(followRequestId: string, data: any, currentUserId: string) {
        try {
            // Validate incoming data
            validateSchema(UpdateFollowRequestSchema, data);

            // Validate ObjectId format
            if (!isValidObjectId(followRequestId)) {
                throw new NotFoundException('Follow request not found');
            }

            // Find the existing follow request
            const followRequest = await this.followRequestModel.findById(followRequestId).exec();
            if (!followRequest || followRequest.isDeleted) {
                throw new NotFoundException('Follow request not found');
            }

            // Check if the current user is authorized to update the follow request
            if (followRequest.receiverId.toString() !== currentUserId) {
                throw new UnprocessableEntityException('You are not authorized to update this follow request');
            }

            // Check if the follow request status is 'Pending'
            if (followRequest.status !== FollowRequestStatus.PENDING) {
                throw new BadRequestException(
                    globalErrorObj('Only pending follow requests can be updated', 'request', 'string.base')
                );
            }

            if (data.status == FollowRequestStatus.REJECTED) {
                // Delete follow request
                await this.followRequestModel.deleteOne({
                    _id: followRequestId
                });
                return { success: true };
            }

            // Update the follow request status for accepted request
            followRequest.status = data.status;

            // Save the updated follow request
            await followRequest.save();
            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async unfollow(unfollowRequestData, currentUserId) {
        try {
            validateSchema(UnFollowRequestSchema, unfollowRequestData);

            // Ensure the receiver exists
            await this.usersService.getUserById(unfollowRequestData.receiverId);

            // Find the latest follow request from the current user to the receiver
            const followRequest = await this.followRequestModel
                .findOne({
                    senderId: currentUserId,
                    receiverId: unfollowRequestData.receiverId,
                    isDeleted: false
                })
                .sort({ createdAt: -1 }) // Sort by createdAt in descending order to get the latest request
                .exec();

            if (!followRequest) {
                throw new NotFoundException('Follow request not found');
            }

            // Check if the follow request status is 'Accepted'
            if (followRequest.status !== FollowRequestStatus.ACCEPTED) {
                throw new BadRequestException(
                    globalErrorObj('Only accepted follow requests can be unfollowed', 'request', 'string.base')
                );
            }

            // Delete all follow requests with the combination of senderId and receiverId
            await this.followRequestModel.deleteMany({
                senderId: currentUserId,
                receiverId: unfollowRequestData.receiverId,
                status: FollowRequestStatus.ACCEPTED
            });

            return { success: true };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async findAll({
        paginateOptions,
        userId
    }: {
        paginateOptions: { page: number; limit: number; paginate: boolean };
        userId: string;
    }): Promise<any> {
        try {
            // Convert userId to ObjectId
            const userObjectId = new mongoose.Types.ObjectId(userId);

            // Fetch all accepted follow requests where senderId equals userObjectId
            const acceptedFollowRequests = await this.followRequestModel
                .find({ senderId: userObjectId, status: FollowRequestStatus.ACCEPTED, isDeleted: false })
                .select('receiverId')
                .exec();

            // Extract receiverIds from the accepted follow requests
            const followingIds = acceptedFollowRequests.map((req) => req.receiverId);

            const aggregationPipeline: any[] = [
                { $match: { receiverId: userObjectId, status: FollowRequestStatus.PENDING, isDeleted: false } },
                { $sort: { createdAt: -1 } },
                {
                    $lookup: {
                        from: 'users',
                        localField: 'senderId',
                        foreignField: '_id',
                        as: 'sender'
                    }
                },
                { $unwind: '$sender' },
                {
                    $addFields: {
                        alreadyFollowing: { $in: ['$senderId', followingIds] }
                    }
                },
                {
                    $project: {
                        _id: 1,
                        senderId: 1,
                        sender: { username: 1, profilePicUrl: 1 },
                        receiverId: 1,
                        status: 1,
                        notificationSent: 1,
                        createdAt: 1,
                        updatedAt: 1,
                        alreadyFollowing: 1
                    }
                }
            ];

            // Handle pagination manually
            if (paginateOptions.paginate) {
                const countPipeline = [...aggregationPipeline, { $count: 'total' }];
                const totalResults = await this.followRequestModel.aggregate(countPipeline).exec();
                const total = totalResults[0]?.total || 0;

                const results = await this.followRequestModel
                    .aggregate(aggregationPipeline)
                    .skip((paginateOptions.page - 1) * paginateOptions.limit)
                    .limit(paginateOptions.limit)
                    .exec();

                const transformedData = results.map((request: any) => ({
                    id: request._id,
                    senderId: request.senderId,
                    sender: request.sender,
                    receiverId: request.receiverId,
                    status: request.status,
                    notificationSent: request.notificationSent,
                    createdAt: request.createdAt,
                    updatedAt: request.updatedAt,
                    alreadyFollowing: request.alreadyFollowing
                }));

                return {
                    data: transformedData,
                    total: total,
                    limit: paginateOptions.limit,
                    page: paginateOptions.page,
                    totalPages: Math.ceil(total / paginateOptions.limit),
                    pagingCounter: (paginateOptions.page - 1) * paginateOptions.limit + 1,
                    hasPrevPage: paginateOptions.page > 1,
                    hasNextPage: paginateOptions.page * paginateOptions.limit < total,
                    prevPage: paginateOptions.page > 1 ? paginateOptions.page - 1 : null,
                    nextPage: paginateOptions.page * paginateOptions.limit < total ? paginateOptions.page + 1 : null
                };
            } else {
                const results = await this.followRequestModel.aggregate(aggregationPipeline).exec();

                const transformedData = results.map((request: any) => ({
                    id: request._id,
                    senderId: request.senderId,
                    sender: request.sender,
                    receiverId: request.receiverId,
                    status: request.status,
                    notificationSent: request.notificationSent,
                    createdAt: request.createdAt,
                    updatedAt: request.updatedAt,
                    alreadyFollowing: request.alreadyFollowing
                }));

                return transformedData;
            }
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async getFollowers({ paginateOptions, userId, search, currentUserId, groupId }) {
        try {
            if (!isValidObjectId(userId)) {
                throw new BadRequestException(globalErrorObj('Invalid user id', 'userId', 'string.base'));
            }

            // Define the aggregation pipeline
            const pipeline: any[] = [
                {
                    $match: {
                        receiverId: mongoose.Types.ObjectId.createFromHexString(userId),
                        status: FollowRequestStatus.ACCEPTED
                    }
                },
                {
                    $lookup: {
                        from: 'users', // The collection name for the User model
                        localField: 'senderId',
                        foreignField: '_id',
                        as: 'sender'
                    }
                },
                {
                    $unwind: '$sender'
                },
                {
                    $project: {
                        sender: { username: 1, profilePicUrl: 1, interests: 1 },
                        status: 1,
                        notificationSent: 1,
                        createdAt: 1,
                        updatedAt: 1,
                        senderId: 1
                    }
                }
            ];

            if (search) {
                pipeline.push({
                    $match: {
                        'sender.username': { $regex: search, $options: 'i' }
                    }
                });
            }

            pipeline.push(
                {
                    $skip: (paginateOptions.page - 1) * paginateOptions.limit
                },
                {
                    $limit: paginateOptions.limit
                }
            );

            // Execute the aggregation pipeline
            const results = await this.followRequestModel.aggregate(pipeline).exec();

            // Get total count (without pagination)
            const countPipeline = pipeline.slice(0, -2); // Remove pagination stages
            const count = await this.followRequestModel.aggregate(countPipeline).exec();
            const totalResults = count.length;

            // Format the results to include only necessary information
            const formattedResults = results.map((followRequest) => {
                const obj = followRequest;
                return {
                    userId: obj?.senderId,
                    username: obj.sender.username || '',
                    profilePicUrl: obj?.sender?.profilePicUrl || '',
                    followRequestSent: false,
                    isFollowing: false,
                    interests: obj?.sender?.interests || []
                };
            });

            const userIds = formattedResults.map((followRequest) => followRequest.userId);

            // Fetch follow requests sent by the user or received by the user
            const followRequests = await this.followRequestModel
                .find({ senderId: currentUserId, receiverId: { $in: userIds }, isDeleted: false })
                .select('senderId receiverId status')
                .exec();

            formattedResults.forEach((user: any) => {
                const followRequest = followRequests.find(
                    (request) =>
                        request.senderId.toString() === currentUserId &&
                        request.receiverId.toString() === user.userId.toString()
                );

                if (followRequest) {
                    user.followRequestSent = followRequest.status === FollowRequestStatus.PENDING;
                    user.isFollowing = followRequest.status === FollowRequestStatus.ACCEPTED;
                }
            });

            const allInterests = await this.interestModel.find().exec();
            formattedResults.forEach((user: any) => {
                user.interests = user.interests.map((interestId) => {
                    const interest = allInterests.find((i) => i._id.toString() === interestId.toString());
                    return interest?.name || '';
                });
            });

            let followersList = formattedResults;

            if (groupId) {
                // Fetch group members for the users
                const groupMembers = await this.groupMemberModel
                    .find({ groupId, userId: { $in: userIds }, isDeleted: false, isActive: true })
                    .exec();

                // Create a set of userIds who are group members for easier lookup
                const groupMemberUserIds = new Set(groupMembers.map((member) => member.userId.toString()));

                // Add the `isGroupMember` flag to formatted results
                followersList = formattedResults.map((result) => ({
                    ...result,
                    isGroupMember: groupMemberUserIds.has(result.userId.toString()) // Check if user is in group
                }));
            }

            return {
                docs: followersList,
                page: paginateOptions.page,
                limit: paginateOptions.limit,
                totalPages: Math.ceil(totalResults / paginateOptions.limit),
                totalResults: totalResults
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async getFollowings({ paginateOptions, userId, search, currentUserId }) {
        try {
            if (!isValidObjectId(userId)) {
                throw new BadRequestException(globalErrorObj('Invalid user id', 'userId', 'string.base'));
            }

            // Define the aggregation pipeline
            const pipeline: any[] = [
                {
                    $match: {
                        senderId: mongoose.Types.ObjectId.createFromHexString(userId),
                        status: FollowRequestStatus.ACCEPTED,
                        isDeleted: false
                    }
                },
                {
                    $lookup: {
                        from: 'users', // The collection name for the User model
                        localField: 'receiverId',
                        foreignField: '_id',
                        as: 'receiver'
                    }
                },
                {
                    $unwind: '$receiver'
                },
                {
                    $project: {
                        receiver: { username: 1, profilePicUrl: 1, interests: 1 },
                        status: 1,
                        notificationSent: 1,
                        createdAt: 1,
                        updatedAt: 1,
                        receiverId: 1
                    }
                }
            ];

            if (search) {
                pipeline.push({
                    $match: {
                        'receiver.username': { $regex: search, $options: 'i' }
                    }
                });
            }

            pipeline.push(
                {
                    $skip: (paginateOptions.page - 1) * paginateOptions.limit
                },
                {
                    $limit: paginateOptions.limit
                }
            );

            // Execute the aggregation pipeline
            const results = await this.followRequestModel.aggregate(pipeline).exec();

            // Get total count (without pagination)
            const countPipeline = pipeline.slice(0, -2); // Remove pagination stages
            const count = await this.followRequestModel.aggregate(countPipeline).exec();
            const totalResults = count.length;

            // Format the results to include only necessary information
            const formattedResults = results.map((followRequest) => {
                const obj = followRequest;
                return {
                    userId: obj?.receiverId,
                    username: obj?.receiver?.username || '',
                    profilePicUrl: obj?.receiver?.profilePicUrl || '',
                    followRequestSent: false,
                    isFollowing: false,
                    interests: obj?.receiver?.interests || []
                };
            });

            const userIds = formattedResults.map((followRequest) => followRequest.userId);
            // Fetch follow requests sent by the user or received by the user
            const followRequests = await this.followRequestModel
                .find({ senderId: currentUserId, receiverId: { $in: userIds }, isDeleted: false })
                .select('senderId receiverId status')
                .exec();

            formattedResults.forEach((user: any) => {
                const followRequest = followRequests.find(
                    (request) =>
                        request.senderId.toString() === currentUserId &&
                        request.receiverId.toString() === user.userId.toString()
                );

                if (followRequest) {
                    user.followRequestSent = followRequest.status === FollowRequestStatus.PENDING;
                    user.isFollowing = followRequest.status === FollowRequestStatus.ACCEPTED;
                }
            });

            const allInterests = await this.interestModel.find().exec();
            formattedResults.forEach((user: any) => {
                user.interests = user.interests.map((interestId) => {
                    const interest = allInterests.find((i) => i._id.toString() === interestId.toString());
                    return interest?.name || '';
                });
            });

            return {
                docs: formattedResults,
                page: paginateOptions.page,
                limit: paginateOptions.limit,
                totalPages: Math.ceil(totalResults / paginateOptions.limit),
                totalResults: totalResults
            };
        } catch (error) {
            throw new RpcException(error);
        }
    }

    async getAllFollowers(userId: string, search: string = '') {
        try {
            // Define the aggregation pipeline for retrieving all followers
            const pipeline: any[] = [
                {
                    $match: {
                        receiverId: new mongoose.Types.ObjectId(userId), // Matching the receiver ID
                        status: FollowRequestStatus.ACCEPTED,
                        isDeleted: false
                    }
                },
                {
                    $lookup: {
                        from: 'users', // The collection name for the User model
                        localField: 'senderId',
                        foreignField: '_id',
                        as: 'sender'
                    }
                },
                {
                    $unwind: '$sender'
                },
                {
                    $project: {
                        'sender._id': 1, // Include the sender's _id
                        'sender.username': 1,
                        'sender.profilePicUrl': 1,
                        status: 1,
                        notificationSent: 1,
                        createdAt: 1,
                        updatedAt: 1
                    }
                }
            ];

            if (search) {
                pipeline.push({
                    $match: {
                        'sender.username': { $regex: search, $options: 'i' } // Search case-insensitive
                    }
                });
            }

            // Execute the aggregation pipeline to get all followers
            const results = await this.followRequestModel.aggregate(pipeline).exec();

            // Format the results to include only necessary information
            return results.map((followRequest) => ({
                userId: followRequest.sender._id.toString(), // Extract sender ID
                username: followRequest.sender.username || '',
                profilePicUrl: followRequest.sender.profilePicUrl || ''
            }));
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
