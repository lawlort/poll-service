import { Body, Controller } from '@nestjs/common';
import { MediaMappingService } from './media-mapping.service';
import { MessagePattern } from '@nestjs/microservices';
import { CMD_ADD_MEDIA_MAPPING } from 'src/utils/constants/commands';

@Controller('media-mapping')
export class MediaMappingController {
    constructor(private readonly mediaMappingService: MediaMappingService) {}

    @MessagePattern({ cmd: CMD_ADD_MEDIA_MAPPING })
    async findAll(@Body() payload) {
        const { body = {} } = payload;
        return await this.mediaMappingService.create(body);
    }
}
