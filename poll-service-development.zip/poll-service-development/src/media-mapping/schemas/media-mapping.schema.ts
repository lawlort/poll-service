import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

@Schema({ timestamps: true, collection: 'media_mapping' })
export class MediaMapping {
    @Prop({ required: true })
    originalUrl: string;

    @Prop({ required: true })
    convertedUrl: string;

    @Prop({ required: true })
    guid: string;
}

export const MediaMappingSchema = SchemaFactory.createForClass(MediaMapping);

// Define indexes to optimize query performance
MediaMappingSchema.index({ originalUrl: 1, convertedUrl: 1, guid: 1 });
MediaMappingSchema.index({ originalUrl: 1, convertedUrl: 1 });
MediaMappingSchema.index({ originalUrl: 1 });
MediaMappingSchema.index({ convertedUrl: 1 });
MediaMappingSchema.index({ guid: 1 });

export type MediaMappingDocument = HydratedDocument<MediaMapping>;

export default MediaMappingSchema;
