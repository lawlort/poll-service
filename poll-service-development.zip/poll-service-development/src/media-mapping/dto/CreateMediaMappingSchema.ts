import * as Joi from 'joi';

export const CreateMediaMappingJoiSchema = Joi.object({
    originalUrl: Joi.string().uri().required(),
    convertedUrl: Joi.string().uri().required(),
    guid: Joi.string().guid().required()
});
