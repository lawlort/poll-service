import { Module } from '@nestjs/common';
import { MediaMappingService } from './media-mapping.service';
import { MediaMappingController } from './media-mapping.controller';
import { MongooseModule } from '@nestjs/mongoose';
import MediaMappingSchema, { MediaMapping } from './schemas/media-mapping.schema';
import PollSchema, { Poll } from 'src/polls/schemas/poll.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: MediaMapping.name, schema: MediaMappingSchema },
            { name: Poll.name, schema: PollSchema }
        ])
    ],
    controllers: [MediaMappingController],
    providers: [MediaMappingService]
})
export class MediaMappingModule {}
