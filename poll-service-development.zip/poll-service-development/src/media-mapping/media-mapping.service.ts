import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { MediaMapping } from './schemas/media-mapping.schema';
import { Model } from 'mongoose';
import { RpcException } from '@nestjs/microservices';
import { validateSchema } from 'src/utils/joi/schemaValidation';
import { CreateMediaMappingJoiSchema } from './dto/CreateMediaMappingSchema';
import * as dotenv from 'dotenv';
import { Poll } from 'src/polls/schemas/poll.schema';
dotenv.config();

@Injectable()
export class MediaMappingService {
    constructor(
        @InjectModel(MediaMapping.name) private mediaMappingModel: Model<MediaMapping>,
        @InjectModel(Poll.name) private pollModel: Model<Poll>
    ) {}

    async create(payload) {
        try {
            const bucketName = process.env.S3_BUCKET_NAME; // Fetch bucket name from environment variable
            const s3BaseUrl = `https://${bucketName}.s3.eu-west-2.amazonaws.com`; // Construct the base URL

            // Replace the bucket name in the originalUrl and convertedUrl
            payload.originalUrl = payload.originalUrl.replace(`s3://${bucketName}`, s3BaseUrl);
            payload.convertedUrl = payload.convertedUrl.replace(`s3://${bucketName}`, s3BaseUrl);

            validateSchema(CreateMediaMappingJoiSchema, payload);

            const mediaMapping = await this.mediaMappingModel.create(payload);

            const { guid = '' } = mediaMapping;

            if (guid) {
                const poll = await this.pollModel.findOne({ pollGuid: guid });
                // check for poll bg image url
                if (poll?._id) {
                    if (poll.bgImageUrl === mediaMapping.originalUrl) {
                        await this.pollModel.updateOne(
                            { pollGuid: guid },
                            { convertedMediaUrl: mediaMapping.convertedUrl }
                        );
                    } else {
                        (poll?.questions || []).forEach(async (question) => {
                            (question?.options || []).forEach(async (option) => {
                                if (option.mediaUrl === mediaMapping.originalUrl) {
                                    option.convertedMediaUrl = mediaMapping.convertedUrl;
                                }
                            });
                        });
                    }
                    await poll.save();
                }
            }

            return mediaMapping;
        } catch (error) {
            throw new RpcException(error);
        }
    }
}
