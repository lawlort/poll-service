import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { PollViewsService } from './poll-views.service';
import { CreatePollViewDto } from './dto/create-poll-view.dto';
import { UpdatePollViewDto } from './dto/update-poll-view.dto';

@Controller('poll-views')
export class PollViewsController {
    constructor(private readonly pollViewsService: PollViewsService) {}

    @Post()
    create(@Body() createPollViewDto: CreatePollViewDto) {
        return this.pollViewsService.create(createPollViewDto);
    }

    @Get()
    findAll() {
        return this.pollViewsService.findAll();
    }

    @Get(':id')
    findOne(@Param('id') id: string) {
        return this.pollViewsService.findOne(+id);
    }

    @Patch(':id')
    update(@Param('id') id: string, @Body() updatePollViewDto: UpdatePollViewDto) {
        return this.pollViewsService.update(+id, updatePollViewDto);
    }

    @Delete(':id')
    remove(@Param('id') id: string) {
        return this.pollViewsService.remove(+id);
    }
}
