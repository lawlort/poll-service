import { PartialType } from '@nestjs/mapped-types';
import { CreatePollViewDto } from './create-poll-view.dto';

export class UpdatePollViewDto extends PartialType(CreatePollViewDto) {}
