export class CreatePollViewDto {}
