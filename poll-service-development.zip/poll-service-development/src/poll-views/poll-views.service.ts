import { Injectable } from '@nestjs/common';
import { CreatePollViewDto } from './dto/create-poll-view.dto';
import { UpdatePollViewDto } from './dto/update-poll-view.dto';
import { InjectModel } from '@nestjs/mongoose';
import { PollView } from './schemas/poll-view.schema';
import { Model } from 'mongoose';

@Injectable()
export class PollViewsService {
    constructor(@InjectModel(PollView.name) private pollViewModel: Model<PollView>) {}

    create(createPollViewDto: CreatePollViewDto) {
        console.log(createPollViewDto);
        return 'This action adds a new pollView';
    }

    findAll() {
        return `This action returns all pollViews`;
    }

    findOne(id: number) {
        return `This action returns a #${id} pollView`;
    }

    update(id: number, updatePollViewDto: UpdatePollViewDto) {
        console.log(updatePollViewDto);
        return `This action updates a #${id} pollView`;
    }

    remove(id: number) {
        return `This action removes a #${id} pollView`;
    }
}
