import { Module } from '@nestjs/common';
import { PollViewsService } from './poll-views.service';
import { PollViewsController } from './poll-views.controller';
import { MongooseModule } from '@nestjs/mongoose';
import PollViewSchema, { PollView } from './schemas/poll-view.schema';

@Module({
    imports: [MongooseModule.forFeature([{ name: PollView.name, schema: PollViewSchema }])],
    controllers: [PollViewsController],
    providers: [PollViewsService]
})
export class PollViewsModule {}
