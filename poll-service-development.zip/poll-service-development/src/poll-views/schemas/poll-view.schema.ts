import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as mongooseSchema } from 'mongoose';

@Schema({ timestamps: true, collection: 'poll_views' })
export class PollView {
    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    userId: string;

    @Prop({ type: mongooseSchema.Types.ObjectId, required: true })
    pollId: string;

    @Prop({ type: Date, default: Date.now })
    viewedAt: Date;
}

export const PollViewSchema = SchemaFactory.createForClass(PollView);

PollViewSchema.index({ userId: 1, pollId: 1 }, { unique: true });
PollViewSchema.index({ pollId: 1 });
PollViewSchema.index({ userId: 1 });

export type PollViewDocument = HydratedDocument<PollView>;

export default PollViewSchema;
